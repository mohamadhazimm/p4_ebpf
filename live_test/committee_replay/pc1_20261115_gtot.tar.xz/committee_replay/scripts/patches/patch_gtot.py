"""--global-totals: the 7 one-entry totals of perf/variants/gtot feed the window totals (CRLF file)."""
import sys
from pathlib import Path

p = Path("/home/admin/Desktop/hAZIM/p4_ebpf/hybrid_collector.py")
raw = p.read_bytes().decode()
assert raw.count("\n") == raw.count("\r\n"), "mixed line endings"
text = raw.replace("\r\n", "\n")

EDITS = [
# --- reader client
('''             probe_max_full: Optional[int] = None) -> Dict[str, Any]:''',
 '''             probe_max_full: Optional[int] = None, totals: bool = False) -> Dict[str, Any]:'''),
('''            if probe_max_full is not None:
                request["probe_max_full"] = int(probe_max_full)
''',
 '''            if probe_max_full is not None:
                request["probe_max_full"] = int(probe_max_full)
        if totals:
            request["totals"] = True    # the gtot build's one-entry totals (batched_reader.read_window)
'''),
# --- constants
('''# Dormant probes leave room for this many full bucket reads: the dormant buckets found changed.
DORMANT_RESUME_RESERVE = 8
''',
 '''# Dormant probes leave room for this many full bucket reads: the dormant buckets found changed.
DORMANT_RESUME_RESERVE = 8
# The one-entry global totals of the test build perf/variants/gtot (reg_g_<key>), per window as the reader sums
# them over the pipes; --global-totals takes the window totals from them (PC1.md part 4d).
GTOT_KEYS = ["pkts", "bytes", "pkts_ab", "bytes_ab", "syn", "ack", "rst"]
'''),
# --- collect_windows_live
('''    dormant_probe: bool = False,
    max_windows: int = 0,
''',
 '''    dormant_probe: bool = False,
    global_totals: bool = False,
    max_windows: int = 0,
'''),
('''    A program without reg_newconn_dst (the deployed basic_fix) answers its reads
''',
 '''    global_totals (the test build perf/variants/gtot and the batched reader):
    every read also returns the seven one-entry totals from the same snapshot
    (window["totals"]); NetSummarizer(global_totals=True) takes the window's
    packet, byte and flag totals from their differences.

    A program without reg_newconn_dst (the deployed basic_fix) answers its reads
'''),
('''    dormant_deferred_total = 0
    dst_missing = False
''',
 '''    dormant_deferred_total = 0
    dst_missing = False
    if global_totals and read_fn is None:
        print("[WARN] --global-totals needs the batched reader; the window totals come from the buckets read")
        global_totals = False
'''),
('''        if probe_now:
            extra["probe"] = probe_now
            if probe_max_full is not None:
                extra["probe_max_full"] = probe_max_full
''',
 '''        if probe_now:
            extra["probe"] = probe_now
            if probe_max_full is not None:
                extra["probe_max_full"] = probe_max_full
        if global_totals:
            extra["totals"] = True
'''),
('''            "dormant_deferred_indexes": deferred_now,
''',
 '''            "dormant_deferred_indexes": deferred_now,
            "totals": payload.get("totals") if global_totals else None,
'''),
# --- NetSummarizer
('''    def __init__(self, window_sec: float, byte_layer: str = "ipv4", duration_unit: str = "ns"):
''',
 '''    def __init__(self, window_sec: float, byte_layer: str = "ipv4", duration_unit: str = "ns",
                 global_totals: bool = False):
'''),
('''        self.window_sec = window_sec
        self.byte_layer = byte_layer
        self.duration_unit = duration_unit
''',
 '''        self.window_sec = window_sec
        self.byte_layer = byte_layer
        self.duration_unit = duration_unit
        # global_totals (PC1.md part 4d): the window's packet, byte and flag totals from the differences of the
        # gtot build's one-entry totals (window["totals"]), not from the buckets read, so a flood that keeps
        # more buckets active than a window's read can cover does not shrink them. Every row then also has
        # net_gtot_used and the bucket sums net_gtot_bucket_pkts_delta / net_gtot_bucket_bytes_delta (equal to
        # the totals in a window without overload: a check). The registers are reset at the start of the run,
        # so the first baseline is zero; after a window without totals the next one only sets the baseline.
        self.global_totals = global_totals
        self.prev_totals: Optional[Dict[str, int]] = None
        self.totals_baseline_ok = True
'''),
('''        if not rows:
            return dict(NET_ZERO, net_new_conn_dst_max=new_conn_max)
''',
 '''        if not rows and not self.global_totals:
            return dict(NET_ZERO, net_new_conn_dst_max=new_conn_max)
'''),
('''        pkts_delta = summary["net_pkts_total_delta"]
        bytes_delta = summary["net_bytes_total_delta"]

        pkts_ab_delta = summary["net_pkts_ab_delta"]
''',
 '''        if self.global_totals:
            self._apply_totals(summary, win.get("totals"), header, owned_set is None)

        pkts_delta = summary["net_pkts_total_delta"]
        bytes_delta = summary["net_bytes_total_delta"]

        pkts_ab_delta = summary["net_pkts_ab_delta"]
'''),
('''    def add(self, win: Dict[str, object]) -> Dict[str, object]:
        window_sec = self.window_sec
''',
 '''    def _apply_totals(self, summary: Dict[str, Any], totals: Any, header: int, whole_switch: bool) -> None:
        """Replace the bucket sums of the window totals with the global totals' differences (global_totals)."""
        summary["net_gtot_bucket_pkts_delta"] = summary["net_pkts_total_delta"]
        summary["net_gtot_bucket_bytes_delta"] = summary["net_bytes_total_delta"]
        used = 0
        valid = isinstance(totals, dict) and all(totals.get(k) is not None for k in GTOT_KEYS)
        if not valid:
            self.totals_baseline_ok = False          # the next window's difference would span two windows
        else:
            now = {k: int(totals[k]) for k in GTOT_KEYS}
            prev = self.prev_totals if self.prev_totals is not None else dict.fromkeys(GTOT_KEYS, 0)
            if self.totals_baseline_ok and whole_switch:
                # 32-bit registers: differences modulo 2^32
                d = {k: (now[k] - prev[k]) % (1 << 32) for k in GTOT_KEYS}
                pkts_ba, bytes_ba = max(0, d["pkts"] - d["pkts_ab"]), max(0, d["bytes"] - d["bytes_ab"])
                summary["net_pkts_total_delta"] = d["pkts"]
                summary["net_bytes_total_delta"] = d["bytes"] + header * d["pkts"]
                summary["net_pkts_ab_delta"] = d["pkts_ab"]
                summary["net_bytes_ab_delta"] = d["bytes_ab"] + header * d["pkts_ab"]
                summary["net_pkts_ba_delta"] = pkts_ba
                summary["net_bytes_ba_delta"] = bytes_ba + header * pkts_ba
                summary["net_syn_delta"] = d["syn"]
                summary["net_ack_delta"] = d["ack"]
                summary["net_rst_delta"] = d["rst"]
                used = 1
            self.prev_totals = now
            self.totals_baseline_ok = True
        summary["net_gtot_used"] = used

    def add(self, win: Dict[str, object]) -> Dict[str, object]:
        window_sec = self.window_sec
'''),
# --- CLI and wiring
('''    ap.add_argument("--byte-layer", choices=["ipv4", "frame"], default="ipv4",
''',
 '''    ap.add_argument("--global-totals", type=int, default=0, choices=[0, 1],
                    help="test build perf/variants/gtot with the batched reader: read its seven one-entry totals "
                         "every window and take the window's packet, byte and TCP-flag totals from them, so that "
                         "an overloaded read does not shrink them (PC1.md part 4d); adds net_gtot_* check columns")
    ap.add_argument("--byte-layer", choices=["ipv4", "frame"], default="ipv4",
'''),
('''    summarizer = NetSummarizer(args.window_sec, byte_layer=args.byte_layer, duration_unit=args.duration_unit)
''',
 '''    summarizer = NetSummarizer(args.window_sec, byte_layer=args.byte_layer, duration_unit=args.duration_unit,
                               global_totals=bool(args.global_totals))
'''),
('''            dormant_probe=bool(args.dormant_probe),
            max_windows=args.windows,
''',
 '''            dormant_probe=bool(args.dormant_probe),
            global_totals=bool(args.global_totals),
            max_windows=args.windows,
'''),
]

for old, new in EDITS:
    n = text.count(old)
    if n != 1:
        sys.exit("edit matched %d times:\n%s" % (n, old[:300]))
    text = text.replace(old, new)
p.write_bytes(text.replace("\n", "\r\n").encode())
print("applied", len(EDITS), "edits")
