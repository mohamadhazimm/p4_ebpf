"""Cap the dormant probe's full reads, defer the rest; learn no read cost from absent dst buckets (CRLF file)."""
import sys
from pathlib import Path

p = Path("/home/admin/Desktop/hAZIM/p4_ebpf/hybrid_collector.py")
raw = p.read_bytes().decode()
assert raw.count("\n") == raw.count("\r\n"), "mixed line endings"
text = raw.replace("\r\n", "\n")

EDITS = [
('''             clear_indexes: Optional[List[int]] = None, probe: Optional[Dict[int, int]] = None) -> Dict[str, Any]:''',
 '''             clear_indexes: Optional[List[int]] = None, probe: Optional[Dict[int, int]] = None,
             probe_max_full: Optional[int] = None) -> Dict[str, Any]:'''),
('''            request["probe"] = {str(int(k)): int(v) for k, v in probe.items()}
''',
 '''            request["probe"] = {str(int(k)): int(v) for k, v in probe.items()}
            if probe_max_full is not None:
                request["probe_max_full"] = int(probe_max_full)
'''),
# docstring
('''    only when the bucket's turn came, windows later (PC1.md part 4b). A few
    buckets' full reads (DORMANT_RESUME_RESERVE) are kept free for the resumed
    ones. Each window also records "dormant_probed_count" and
    "dormant_resumed_indexes".
''',
 '''    only when the bucket's turn came, windows later (PC1.md part 4b). A few
    buckets' full reads (DORMANT_RESUME_RESERVE) are kept free for the resumed
    ones, and the reader reads in full only as many changed buckets as the
    allowance left after the probes fits (probe_max_full); the others are
    active again and read with the active set from the next window, under its
    budget (a fan-out flood changes thousands of occupied dormant buckets at
    once: read all in full, the reads overran the window, PC1.md part 4c). Each
    window also records "dormant_probed_count", "dormant_resumed_indexes" and
    "dormant_deferred_indexes".

    A program without reg_newconn_dst (the deployed basic_fix) answers its reads
    with an error and no rows: from then on no destination bucket is requested
    (nor counted as skipped), and the cost model learns only from the rows read.
'''),
('''    dormant_probes_total = 0
    dormant_probe_resumed_total = 0
''',
 '''    dormant_probes_total = 0
    dormant_probe_resumed_total = 0
    dormant_deferred_total = 0
    dst_missing = False
'''),
('''        else:
            read_dst_idxs = active_dst_idxs
''',
 '''        else:
            read_dst_idxs = active_dst_idxs
        if dst_missing:
            read_dst_idxs = []   # the program has no reg_newconn_dst: nothing to read, and no overload
'''),
('''        probe_now: Dict[int, int] = {}
        if dormant_probe and dormant and not skipped_idxs:
            # Probe reg_pkts of as many dormant buckets as fit, oldest probed first; the reader reads the
            # changed ones in full, so a resumed flow counts in this window.
            n_probe = len(dormant)
            if allow_ms is not None:
                left_ms = (allow_ms - cost.margin_ms
                           - cost.predict_ms(len(read_idxs) + DORMANT_RESUME_RESERVE,
                                             len(clear_now) + idle_estimate, len(read_dst_idxs)))
                n_probe = max(0, min(n_probe, cost.probes_within(left_ms)))
''',
 '''        probe_now: Dict[int, int] = {}
        probe_max_full: Optional[int] = None
        if dormant_probe and dormant and not skipped_idxs:
            # Probe reg_pkts of as many dormant buckets as fit, oldest probed first; the reader reads the
            # changed ones in full, as many as the allowance still fits, so a resumed flow counts in this
            # window; the other changed ones are deferred.
            n_probe = len(dormant)
            if allow_ms is not None:
                # the allowance after the active reads (the Read RPCs' fixed part counted even without an
                # active bucket: the changed dormant ones are read the same way)
                avail_ms = (allow_ms - cost.margin_ms
                            - cost.predict_ms(len(read_idxs), len(clear_now) + idle_estimate, len(read_dst_idxs))
                            - (cost.read_fixed_ms if not read_idxs else 0.0))
                n_probe = max(0, min(n_probe, cost.probes_within(
                    avail_ms - DORMANT_RESUME_RESERVE * cost.read_ms_per_bucket)))
                left_ms = avail_ms - n_probe * cost.probe_ms_per_bucket
                probe_max_full = (max(0, int(left_ms // cost.read_ms_per_bucket)) if cost.read_ms_per_bucket > 0
                                  else DORMANT_RESUME_RESERVE)
'''),
('''        if probe_now:
            extra["probe"] = probe_now
''',
 '''        if probe_now:
            extra["probe"] = probe_now
            if probe_max_full is not None:
                extra["probe_max_full"] = probe_max_full
'''),
('''        resumed_now = sorted(safe_int(i) for i in (payload.get("resumed") or []))
        dormant_probe_resumed_total += len(resumed_now)
''',
 '''        resumed_now = sorted(safe_int(i) for i in (payload.get("resumed") or []))
        deferred_now = sorted(safe_int(i) for i in (payload.get("deferred") or []))
        dormant_probe_resumed_total += len(resumed_now)
        dormant_deferred_total += len(deferred_now)
        dst_rows_read = len(payload.get("dst_rows") or [])
        if (read_dst_idxs and not dst_rows_read
                and any("reg_newconn_dst" in str(e) and "missing" in str(e).lower() for e in (payload.get("errors") or []))):
            dst_missing = True
            print("[INFO] the program has no reg_newconn_dst: destination buckets are not read from now on")
'''),
('''                if dormant_probe:
                    fields.update(dormant_probed=len(probe_now), dormant_probe_resumed=len(resumed_now))
''',
 '''                if dormant_probe:
                    fields.update(dormant_probed=len(probe_now), dormant_probe_resumed=len(resumed_now),
                                  dormant_probe_deferred=len(deferred_now))
'''),
('''        cost.update(len(request_idxs) + len(resumed_now), len(payload.get("cleared") or []),
                    payload_timing_ms(payload, wall_ms), n_dst=len(read_dst_idxs), n_probe=len(probe_now))
''',
 '''        cost.update(len(request_idxs) + len(resumed_now), len(payload.get("cleared") or []),
                    payload_timing_ms(payload, wall_ms), n_dst=dst_rows_read, n_probe=len(probe_now))
'''),
('''            "net_overload": int(bool(skipped_idxs) or len(read_dst_idxs) < len(active_dst_idxs)
                                or len(clear_now) < len(pending_clear)),
''',
 '''            "net_overload": int(bool(skipped_idxs) or dst_skipped > 0 or len(clear_now) < len(pending_clear)),
'''),
('''            "net_dst_buckets_skipped": len(active_dst_idxs) - len(read_dst_idxs),
''',
 '''            "net_dst_buckets_skipped": dst_skipped,
'''),
('''        overrun = read_end > win_end_abs + window_sec
''',
 '''        overrun = read_end > win_end_abs + window_sec
        dst_skipped = 0 if dst_missing else len(active_dst_idxs) - len(read_dst_idxs)
'''),
('''        # The active set once this read's changes are known (before this read's clears take effect:
        # a bucket cleared after this read still counts in this window).
        active_after_read = sorted(active_idx_last_seen)
''',
 '''        # Dormant buckets the probe found changed but could not read in full within the allowance: active
        # again (they are), read with the active set from the next window on, under its budget.
        for idx in deferred_now:
            active_idx_last_seen[idx] = w
            if idx in dormant:
                del dormant[idx]
                dormant_resumed += 1
        # The active set once this read's changes are known (before this read's clears take effect:
        # a bucket cleared after this read still counts in this window).
        active_after_read = sorted(active_idx_last_seen)
'''),
('''            "dormant_resumed_indexes": resumed_now,
''',
 '''            "dormant_resumed_indexes": resumed_now,
            "dormant_deferred_indexes": deferred_now,
'''),
('''        how = (f"{dormant_probes_total} dormant probes (reg_pkts), {dormant_probe_resumed_total} of them changed and "
               f"read in full" if dormant_probe else f"{dormant_reads_total} dormant reads")
''',
 '''        how = (f"{dormant_probes_total} dormant probes (reg_pkts), {dormant_probe_resumed_total} of them changed and "
               f"read in full, {dormant_deferred_total} changed and deferred to the active set"
               if dormant_probe else f"{dormant_reads_total} dormant reads")
'''),
]

for old, new in EDITS:
    n = text.count(old)
    if n != 1:
        sys.exit("edit matched %d times:\n%s" % (n, old[:300]))
    text = text.replace(old, new)
p.write_bytes(text.replace("\n", "\r\n").encode())
print("applied", len(EDITS), "edits")
