#!/usr/bin/env python3
"""Part 4d: the gtot build with --global-totals (runs_gtot/) against basic_fix with the same collector code and box
sums (runs_probe2/), per capture: packets seen against packets sent, overload/overrun, and the 95 dataset columns of
the 19 total-based features (5 summaries each) against the published row (dataset/features.csv). Writes
gtot_compare.csv."""
import csv
import json
import statistics as st
from pathlib import Path

R = Path(__file__).resolve().parent.parent
DATASET = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection/dataset/features.csv")
TOTAL_FEATURES = ["net_pkts_total_delta", "net_bytes_total_delta", "net_pkts_ab_delta", "net_bytes_ab_delta",
                  "net_pkts_ba_delta", "net_bytes_ba_delta", "net_avg_pkt_size_delta", "net_avg_pkt_size_ab_delta",
                  "net_avg_pkt_size_ba_delta", "net_bytes_per_sec_delta", "net_pkts_per_sec_delta",
                  "net_down_up_ratio_delta", "net_ab_ratio_pkt_delta", "net_ba_ratio_pkt_delta",
                  "net_ab_ratio_byte_delta", "net_ba_ratio_byte_delta", "net_syn_delta", "net_ack_delta", "net_rst_delta"]
AGGS = ["mean", "max", "sum", "std", "active_windows"]
COLS = ["%s__%s" % (f, a) for f in TOTAL_FEATURES for a in AGGS]

published = {r["execution_id"]: r for r in csv.DictReader(open(DATASET))}


def rows_of(d):
    return {r["execution_id"]: r for r in csv.DictReader(open(d / "rows.csv"))} if (d / "rows.csv").exists() else {}


def run_stats(run):
    s = json.loads((run / "summary.json").read_text())
    w = list(csv.DictReader(open(run / "windows.csv")))[4:44]
    recs = [r for r in map(json.loads, open(run / "timing.jsonl")) if "window" in r and r.get("wall_ms") is not None]
    f = lambda r, k: int(float(r.get(k) or 0))
    out = dict(pkts=sum(f(r, "net_pkts_total_delta") for r in w), sent=s["self_check"]["sent_pkts_total"],
               overload=sum(f(r, "net_overload") for r in w), overrun=sum(f(r, "net_read_overrun") for r in w),
               wall_max=max(r["wall_ms"] for r in recs), inside=s["self_check"]["windows_inside_bounds"],
               checked=s["self_check"]["windows_checked"])
    if "net_gtot_used" in w[0]:
        out["bucket_pkts"] = sum(f(r, "net_gtot_bucket_pkts_delta") for r in w)
        out["gtot_used"] = sum(f(r, "net_gtot_used") for r in w)
    return out


def agreement(row, ref):
    exact, errs = 0, []
    for c in COLS:
        a, b = float(row[c]), float(ref[c])
        exact += abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))
        errs.append(abs(a - b) / max(abs(b), 1e-9) if b else (0.0 if a == 0 else 1.0))
    return exact, st.median(errs)


g_rows, p_rows = rows_of(R / "runs_gtot"), rows_of(R / "runs_probe2")
out = []
for run in sorted(p for p in (R / "runs_gtot").iterdir() if (p / "windows.csv").exists()):
    eid = run.name
    g = run_stats(run)
    p = run_stats(R / "runs_probe2" / eid)
    ge, gm = agreement(g_rows[eid], published[eid])
    pe, pm = agreement(p_rows[eid], published[eid])
    out.append(dict(execution_id=eid, sent=g["sent"], gtot_pkts=g["pkts"], gtot_bucket_pkts=g.get("bucket_pkts"),
                    basic_fix_pkts=p["pkts"], gtot_used=g.get("gtot_used"), overload_gtot=g["overload"],
                    overload_basic_fix=p["overload"], overrun_gtot=g["overrun"], overrun_basic_fix=p["overrun"],
                    wall_max_gtot=g["wall_max"], wall_max_basic_fix=p["wall_max"],
                    exact95_gtot=ge, exact95_basic_fix=pe, mrel95_gtot=gm, mrel95_basic_fix=pm))
with open(R / "gtot_compare.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(out[0]))
    wr.writeheader()
    wr.writerows(out)

print("%-16s %8s | %15s %15s | %9s %9s | %9s %9s | %12s %12s" % (
    "capture", "sent", "seen gtot", "seen basic_fix", "ovl g/b", "ovr g/b", "wall g/b", "", "exact of 95", "med rel err"))
for r in out:
    print("%-16s %8d | %8d %5.1f%% %8d %5.1f%% | %4d %4d | %4d %4d | %5.0f %5.0f ms | %5d %5d | %5.3f %5.3f" % (
        r["execution_id"][:16], r["sent"], r["gtot_pkts"], 100.0 * r["gtot_pkts"] / max(r["sent"], 1),
        r["basic_fix_pkts"], 100.0 * r["basic_fix_pkts"] / max(r["sent"], 1), r["overload_gtot"], r["overload_basic_fix"],
        r["overrun_gtot"], r["overrun_basic_fix"], r["wall_max_gtot"], r["wall_max_basic_fix"],
        r["exact95_gtot"], r["exact95_basic_fix"], r["mrel95_gtot"], r["mrel95_basic_fix"]))
