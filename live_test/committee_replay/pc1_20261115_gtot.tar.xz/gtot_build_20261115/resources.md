# Phase 1: compile-time resources

Usage over the whole pipe (all MAU stages; ingress and egress share them). MAU latency is the compiler's estimate in pipeline clock cycles.

| variant | status | -D flags | stages ig/eg | crit. path | sram | map ram | tcam | stateful alu | hash bit | gateway | logical table | PHV normal | PHV tagalong | parser TCAM ig/eg | MAU latency ig/eg | power ig/eg (W) | compile wall s | peak RSS MiB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| basic_fix | ok | – | 5/1 | 4 | 197/960 (20.5%) | 196/576 (34.0%) | 3/288 (1.0%) | 14/48 (29.2%) | 172/4992 (3.4%) | 19/192 (9.9%) | 22/192 (11.5%) | 8/64×8b, 13/96×16b, 5/64×32b | 4/32×8b, 10/48×16b, 6/32×32b | 9/1 | 131/170 | 7.49/0.00 | 20.756 | 183 |
| basic_gtot | ok | – | 6/1 | 4 | 211/960 (22.0%) | 210/576 (36.5%) | 3/288 (1.0%) | 21/48 (43.8%) | 206/4992 (4.1%) | 22/192 (11.5%) | 29/192 (15.1%) | 8/64×8b, 13/96×16b, 5/64×32b | 4/32×8b, 10/48×16b, 6/32×32b | 9/1 | 135/170 | 10.23/0.00 | 21.893 | 191 |

## basic_fix: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 42 (52%) | 41 (85%) | 3 (12%) | 3 (75%) | 1 (25%) | 42 (10%) | 2 (33%) | 4 (25%) | 3 (9%) | 24 (19%) | 7 (44%) |
| 1 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 16 (4%) | 1 (17%) | 2 (12%) | 1 (3%) | 14 (11%) | 2 (12%) |
| 2 | 44 (55%) | 44 (92%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 21 (16%) | 6 (38%) |
| 3 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 25 (20%) | 5 (31%) |
| 4 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_fix: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 4 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 2 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 4 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_gtot: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 29 (36%) | 28 (58%) | 3 (12%) | 4 (100%) | 1 (25%) | 42 (10%) | 2 (33%) | 3 (19%) | 3 (9%) | 22 (17%) | 8 (50%) |
| 1 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 16 (4%) | 1 (17%) | 4 (25%) | 1 (3%) | 15 (12%) | 4 (25%) |
| 2 | 37 (46%) | 37 (77%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 19 (15%) | 6 (38%) |
| 3 | 35 (44%) | 35 (73%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 29 (23%) | 5 (31%) |
| 4 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 19 (15%) | 4 (25%) |
| 5 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_gtot: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 4 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 3 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 1 | 2 | 2 | 1 |
| Ingress.reg_g_bytes | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts | 0 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 1 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 2 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 3 | 9 | 9 | 1 |
| Ingress.reg_pkts | 4 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

