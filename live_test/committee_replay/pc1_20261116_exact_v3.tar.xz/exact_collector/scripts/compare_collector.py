#!/usr/bin/env python3
"""PC1.md part 6b: the 109 captures through hybrid_collector.py on perf/variants/exact (runs/, rows.csv) against the
published rows and against part 6's rows from live_test/exact_replay.py (exact_replay/replay_rows_exact.csv), and the
replays' exact self-check (every window against the frames the replayer sent between its markers). Writes
collector_compare.csv and replay_rows_exact_collector.csv (in replay_rows_v3.csv's order).

    compare_collector.py [RUNS_DIR (default runs_follow, the final code)] [-v]"""
import csv
import json
import statistics as st
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
RES = HERE.parent
DATASET = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection/dataset/features.csv")
published = {r["execution_id"]: r for r in csv.DictReader(open(DATASET))}
v3_list = list(csv.DictReader(open(RES / "committee_replay" / "replay_rows_v3.csv")))
NET = [c for c in v3_list[0] if c.startswith("net_")]
NODUR = [c for c in NET if "duration" not in c]
RUNS = HERE / next((a for a in sys.argv[1:] if not a.startswith("-")), "runs_follow")
coll = {r["execution_id"]: r for r in csv.DictReader(open(RUNS / "rows.csv"))}
drv = {r["execution_id"]: r for r in csv.DictReader(open(RES / "exact_replay" / "replay_rows_exact.csv"))}
prog = {}
for line in open(RUNS / "progress.jsonl"):
    r = json.loads(line)
    prog[r["execution_id"]] = r
group = {r["execution_id"]: r for r in csv.DictReader(open(RES / "committee_replay" / "gtot_ba_all_compare.csv"))}


def eq(a, b):
    a, b = float(a), float(b)
    return abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))


out = []
for eid in [r["execution_id"] for r in v3_list]:
    if eid not in coll:
        continue
    c, p, d, pr = coll[eid], published[eid], drv.get(eid), prog[eid]
    out.append(dict(
        execution_id=eid, rc=pr.get("rc"), windows_exact=pr.get("windows_exact"), windows_checked=pr.get("windows_checked"),
        pkts_switch=pr.get("switch_pkts_total"), pkts_sent=pr.get("sent_pkts_total"), untracked=pr.get("untracked_pkts"),
        lost=pr.get("windows_lost"),
        exact135_published=sum(eq(c[k], p[k]) for k in NODUR),
        exact135_driver=sum(eq(c[k], d[k]) for k in NODUR) if d else None,
        exact135_driver_vs_published=sum(eq(d[k], p[k]) for k in NODUR) if d else None))
with open(HERE / "collector_compare.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0]))
    w.writeheader()
    w.writerows(out)
with open(HERE / "replay_rows_exact_collector.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(v3_list[0]))
    w.writeheader()
    for r in v3_list:
        if r["execution_id"] in coll:
            w.writerow(dict({k: v for k, v in r.items() if not k.startswith("net_")},
                            **{k: coll[r["execution_id"]][k] for k in NET}))
print("wrote collector_compare.csv and replay_rows_exact_collector.csv (%d captures)" % len(out))
ovl = {e for e, g in group.items() if int(g["overload_bf"]) > 0}
for name, grp in (("calm", [r for r in out if r["execution_id"] not in ovl and not r["execution_id"].startswith("bulkup")]),
                  ("overloaded on basic_fix", [r for r in out if r["execution_id"] in ovl]),
                  ("bulkup_200/400", [r for r in out if r["execution_id"].startswith("bulkup")]), ("all", out)):
    if not grp:
        continue
    print("\n== %s: %d captures" % (name, len(grp)))
    print("  replays' exact check: %d of %d windows; packets switch %d / sent %d; untracked %d; lost %d; collector rc != 0: %d" % (
        sum(r["windows_exact"] or 0 for r in grp), sum(r["windows_checked"] or 0 for r in grp),
        sum(r["pkts_switch"] or 0 for r in grp), sum(r["pkts_sent"] or 0 for r in grp),
        sum(r["untracked"] or 0 for r in grp), sum(r["lost"] or 0 for r in grp), sum(1 for r in grp if r["rc"])))
    print("  rows with all 135 non-duration columns equal to the published row: %d (part 6's driver: %d); mean %.1f" % (
        sum(r["exact135_published"] == 135 for r in grp),
        sum(r["exact135_driver_vs_published"] == 135 for r in grp if r["exact135_driver_vs_published"] is not None),
        st.mean(r["exact135_published"] for r in grp)))
    print("  rows whose 135 columns equal part 6's driver row: %d" % sum(r["exact135_driver"] == 135 for r in grp))
if "-v" in sys.argv:
    print()
    for r in out:
        if r["exact135_published"] != 135 or r["exact135_driver"] != 135 or r["windows_exact"] != r["windows_checked"]:
            print(r)
