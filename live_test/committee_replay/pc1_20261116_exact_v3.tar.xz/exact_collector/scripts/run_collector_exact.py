#!/usr/bin/env python3
"""PC1.md part 6b: the dataset captures through hybrid_collector.py on perf/variants/exact, resumably:
live_test/replay_capture.py --exact --profile dataset --align-window 4 (the collector with --switch-program exact
--window-markers inband; the replayer's markers at the collector's window boundaries), then
live_test/dataset_row.py --skip-windows 4. Per run: the exact self-check (every window against the frames sent
between its markers), the row in OUT_DIR/rows.csv, a line in OUT_DIR/progress.jsonl.

    run_collector_exact.py OUT_DIR [--only ID,ID] [--skip ID,ID]
"""
import csv
import json
import subprocess
import sys
import tarfile
import time
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = REPO.parent / "p4-ebpf-malware-detection"
CAPS = REPO / "live_test" / "captures"
ASROOT = REPO / "perf" / "results" / "committee_replay" / "scripts" / "asroot.sh"
SHM = Path("/dev/shm/hz_exact_collector")


def log(out, msg):
    line = "%s %s" % (time.strftime("%H:%M:%S"), msg)
    print(line, flush=True)
    with open(out / "driver.log", "a") as f:
        f.write(line + "\n")


def main():
    out = Path(sys.argv[1]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    opts = dict(zip(sys.argv[2::2], sys.argv[3::2]))
    only = set(opts.get("--only", "").split(",")) - {""}
    skip = set(opts.get("--skip", "").split(",")) - {""}
    done = set()
    if (out / "progress.jsonl").exists():
        done = {json.loads(l)["execution_id"] for l in open(out / "progress.jsonl") if l.strip()}
    items = [dict(eid=r["execution_id"], offset=r["anchor_offset_s"], cat=r["category"], label=r["label"],
                  path=CAPS / "cohort" / r["capture"], member=None)
             for r in csv.DictReader(open(CAPS / "cohort" / "manifest.csv"))]
    man = subprocess.run(["tar", "xzf", str(CAPS / "cohort-extra.tar.gz"), "-O", "cohort-extra/manifest.csv"],
                         check=True, capture_output=True, text=True).stdout
    extra = list(csv.DictReader(man.splitlines(True)))
    extra = [r for r in extra if r["expect_overload"] == "0"] + [r for r in extra if r["expect_overload"] == "1"]
    items += [dict(eid=r["execution_id"], offset=r["anchor_offset_s"], cat=r["category"], label=r["label"],
                   path=SHM / r["capture"], member="cohort-extra/" + r["capture"]) for r in extra]
    todo = [it for it in items if it["eid"] not in done and it["eid"] not in skip and (not only or it["eid"] in only)]
    log(out, "%d captures to run (%d done before)" % (len(todo), len(done)))
    SHM.mkdir(exist_ok=True)
    for n, it in enumerate(todo, 1):
        if it["member"]:
            with tarfile.open(CAPS / "cohort-extra.tar.gz", "r:gz") as tar:
                with tar.extractfile(tar.getmember(it["member"])) as src, open(it["path"], "wb") as dst:
                    dst.write(src.read())
        run = out / it["eid"]
        t0 = time.time()
        p = subprocess.run([str(ASROOT), sys.executable, str(REPO / "live_test" / "replay_capture.py"), str(it["path"]),
                            "--out", str(run), "--profile", "dataset", "--anchor-offset", it["offset"],
                            "--align-window", "4", "--exact"], cwd=str(REPO), capture_output=True, text=True)
        if it["member"]:
            it["path"].unlink()
        res = {"execution_id": it["eid"], "rc": p.returncode, "wall_s": round(time.time() - t0, 1)}
        d = subprocess.run([sys.executable, str(REPO / "live_test" / "dataset_row.py"), str(run / "windows.csv"),
                            "--execution-id", it["eid"], "--category", it["cat"], "--label", it["label"],
                            "--skip-windows", "4", "--release", str(RELEASE), "--out", str(out / "rows.csv")],
                           cwd=str(REPO), capture_output=True, text=True)
        res["row_rc"] = d.returncode
        try:
            ec = json.loads((run / "summary.json").read_text())["exact_check"]
            res.update({k: ec[k] for k in ("windows_checked", "windows_exact", "switch_pkts_total", "sent_pkts_total",
                                           "switch_bytes_total", "sent_bytes_total", "untracked_pkts", "windows_lost",
                                           "sent_before_first_marker_or_after_last")})
        except Exception as error:
            res["error"] = "%s; %s" % (error, (p.stdout + p.stderr)[-600:])
        tx = run / "tx.pcap"
        if tx.exists():
            subprocess.run([str(ASROOT), "gzip", "-6", str(tx)])
        with open(out / "progress.jsonl", "a") as f:
            f.write(json.dumps(res) + "\n")
        log(out, "[%d/%d] %s rc %d row %d: %s/%s windows exact, pkts %s/%s, untracked %s, lost %s (%.0f s)" % (
            n, len(todo), it["eid"][:16], p.returncode, d.returncode, res.get("windows_exact"),
            res.get("windows_checked"), res.get("switch_pkts_total"), res.get("sent_pkts_total"),
            res.get("untracked_pkts"), res.get("windows_lost"), res["wall_s"]))
        time.sleep(2)


if __name__ == "__main__":
    main()
