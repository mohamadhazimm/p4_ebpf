#!/usr/bin/env python3
"""p4_perf 5.7: the line-rate matrix of the exact build (exact_*.json) against basic_fix's of 31 October (det_*.json
of linerate_gtot_20261115/runs, p4_perf 5.5), and the window totals' exactness (no markers, so every packet in
window 0): pipe 1 (the generator's) must grow by the generated packets, pipe 0 by the looped-back ones (the sink's
RX), the bytes by the packets' IPv4 length (frame - 18 B), and every packet belongs to a tracked flow (one flow).
    summarize.py DIR"""
import glob
import json
import os
import statistics as st
import sys

d = sys.argv[1]
BF = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "linerate_gtot_20261115", "runs")
SIZES = [64, 128, 256, 512, 1024, 1280, 1518]
M32 = (1 << 32) - 1


def load(root, pattern):
    return [json.load(open(p)) for p in sorted(glob.glob(os.path.join(root, pattern)))]


runs, problems, total_pkts = [], [], 0
for size in SIZES:
    kinds = [("max", "exact_64_max_r*.json", "det_64_max_r*.json")] if size == 64 else [
        ("paced", "exact_%d_paced_r*.json" % size, "det_%d_paced_r*.json" % size),
        ("max", "exact_%d_max.json" % size, "det_%d_max.json" % size)]
    for kind, gp, bp in kinds:
        g, b = load(d, gp), load(BF, bp)
        for o in g:
            name = "%d %s" % (size, kind)
            if o["errors"]:
                problems.append((name, "errors", o["errors"]))
            gen, tx, rx = o["generated"], o["sink_tx_frames"], o["sink_rx_frames"]
            drops = (o.get("tm_eg_delta") or {}).get("drop_count_packets")
            wd = o["window_delta"]
            checks = {
                "window pkts pipe 1 = generated": wd["w_pkts"][1] == gen & M32,
                "window pkts pipe 0 = looped back": wd["w_pkts"][0] == rx & M32,
                "window bytes = packets x IPv4 length": wd["w_bytes"] == [(p * (size - 18)) & M32 for p in wd["w_pkts"]],
                "every packet tracked": wd["w_tracked"] == wd["w_pkts"],
                "tx = rx": tx == rx,
                "lossless or drops = excess": (drops == 0 and gen == tx) if kind == "paced" or size == 64
                                              else (drops == gen - tx),
            }
            for k, ok in checks.items():
                if not ok:
                    problems.append((name, k, {"generated": gen, "tx": tx, "rx": rx, "drops": drops,
                                               "window": wd}))
            total_pkts += gen
        gp_ = [o["pct_of_line_rate"] for o in g]
        bp_ = [o["pct_of_line_rate"] for o in b]
        offered = [100.0 * o["gen_mpps"] / o["line_rate_mpps"] for o in g]
        runs.append((size, kind, len(g), gp_, bp_, offered))

print("| Frame (B) | run | exact: % of line rate | basic_fix (31 Oct) | exact offered |")
print("|---|---|---|---|---|")
for size, kind, n, gp_, bp_, offered in runs:
    print("| %d | %s x%d | %s | %s | %.0f%% |" % (size, kind, n, " / ".join("%.2f%%" % x for x in gp_),
                                                  " / ".join("%.2f%%" % x for x in bp_), st.mean(offered)))
print()
print("runs: %d; packets generated: %d (%.1f billion)" % (sum(r[2] for r in runs), total_pkts, total_pkts / 1e9))
print("checks failed: %d" % len(problems))
for p in problems[:20]:
    print("  ", p)
