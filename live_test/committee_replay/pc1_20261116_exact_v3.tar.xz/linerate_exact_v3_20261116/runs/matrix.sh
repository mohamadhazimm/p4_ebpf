#!/bin/bash
# p4_perf 3.2 / 5.5 matrix on the exact build (perf/variants/exact, p4_perf 5.7), with its window totals counted
# (--window-totals; the build has no per-flow packet counters, so no --flow-index)
cd /root/hazim_perf/runs/linerate_exact_v3_20261116
T=/root/hazim_perf/tools/sw_pktgen_run.py
run() { out=$1; shift; python2.7 $T $out --prog basic --seconds 10 --window-totals "$@" > ${out%.json}.log 2>&1; }
for r in 1 2 3; do run exact_64_max_r$r.json --size 64; done
for s in 128 256 512 1024 1280 1518; do
    for r in 1 2 3; do run exact_${s}_paced_r$r.json --size $s --rate-pct 99.9; done
    run exact_${s}_max.json --size $s
done
python2.7 $T cleanup.json --prog basic --cleanup > cleanup.log 2>&1
date -u +%FT%TZ > matrix.done
