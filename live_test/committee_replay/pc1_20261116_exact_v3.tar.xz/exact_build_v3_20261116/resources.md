# Phase 1: compile-time resources

Usage over the whole pipe (all MAU stages; ingress and egress share them). MAU latency is the compiler's estimate in pipeline clock cycles.

| variant | status | -D flags | stages ig/eg | crit. path | sram | map ram | tcam | stateful alu | hash bit | gateway | logical table | PHV normal | PHV tagalong | parser TCAM ig/eg | MAU latency ig/eg | power ig/eg (W) | compile wall s | peak RSS MiB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| basic_exact_v3 | ok | – | 11/1 | 9 | 122/960 (12.7%) | 119/576 (20.7%) | 7/288 (2.4%) | 23/48 (47.9%) | 328/4992 (6.6%) | 43/192 (22.4%) | 55/192 (28.6%) | 7/64×8b, 18/96×16b, 12/64×32b | 8/32×8b, 18/48×16b, 12/32×32b | 49/1 | 260/170 | 0.56/0.00 | 55.295 | 263 |
| basic_exact_v3_timer | ok | TIMER_LOCAL_PORT=68 | 11/1 | 9 | 122/960 (12.7%) | 119/576 (20.7%) | 7/288 (2.4%) | 23/48 (47.9%) | 328/4992 (6.6%) | 43/192 (22.4%) | 55/192 (28.6%) | 7/64×8b, 18/96×16b, 12/64×32b | 8/32×8b, 18/48×16b, 12/32×32b | 49/1 | 260/170 | 0.56/0.00 | 55.439 | 260 |
| basic_hwl_exact_v3 | ok | – | 11/2 | 9 | 122/960 (12.7%) | 119/576 (20.7%) | 7/288 (2.4%) | 23/48 (47.9%) | 328/4992 (6.6%) | 44/192 (22.9%) | 57/192 (29.7%) | 10/64×8b, 24/96×16b, 15/64×32b | 15/32×8b, 27/48×16b, 17/32×32b | 50/7 | 260/172 | 0.56/0.73 | 55.233 | 280 |

## basic_exact_v3: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 8 (10%) | 6 (12%) | 5 (21%) | 1 (25%) | 2 (50%) | 42 (10%) | 2 (33%) | 6 (38%) | 6 (19%) | 24 (19%) | 11 (69%) |
| 1 | 1 (1%) | 0 | 2 (8%) | 0 | 0 | 0 | 0 | 0 | 3 (9%) | 0 | 3 (19%) |
| 2 | 7 (9%) | 7 (15%) | 0 | 2 (50%) | 0 | 71 (17%) | 6 (100%) | 5 (31%) | 3 (9%) | 36 (28%) | 5 (31%) |
| 3 | 9 (11%) | 9 (19%) | 0 | 3 (75%) | 0 | 19 (5%) | 3 (50%) | 4 (25%) | 2 (6%) | 11 (9%) | 5 (31%) |
| 4 | 5 (6%) | 5 (10%) | 0 | 1 (25%) | 0 | 14 (3%) | 1 (17%) | 2 (12%) | 2 (6%) | 7 (5%) | 2 (12%) |
| 5 | 5 (6%) | 5 (10%) | 0 | 1 (25%) | 0 | 14 (3%) | 1 (17%) | 2 (12%) | 2 (6%) | 7 (5%) | 2 (12%) |
| 6 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 64 (15%) | 4 (67%) | 8 (50%) | 5 (16%) | 16 (12%) | 8 (50%) |
| 7 | 23 (29%) | 23 (48%) | 0 | 3 (75%) | 0 | 64 (15%) | 3 (50%) | 6 (38%) | 4 (12%) | 9 (7%) | 8 (50%) |
| 8 | 11 (14%) | 11 (23%) | 0 | 4 (100%) | 0 | 21 (5%) | 3 (50%) | 4 (25%) | 2 (6%) | 19 (15%) | 5 (31%) |
| 9 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 16 (4%) | 4 (67%) | 5 (31%) | 1 (3%) | 17 (13%) | 5 (31%) |
| 10 | 2 (2%) | 2 (4%) | 0 | 1 (25%) | 0 | 3 (1%) | 1 (17%) | 1 (6%) | 1 (3%) | 5 (4%) | 1 (6%) |

### basic_exact_v3: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ba | 8 | 5 | 5 | 1 |
| Ingress.reg_epoch | 0 | 2 | 2 | 1 |
| Ingress.reg_first | 6 | 17 | 17 | 1 |
| Ingress.reg_last | 6 | 17 | 17 | 1 |
| Ingress.reg_max | 6 | 9 | 9 | 1 |
| Ingress.reg_min | 7 | 9 | 9 | 1 |
| Ingress.reg_ref | 7 | 5 | 5 | 1 |
| Ingress.reg_seen | 7 | 9 | 9 | 1 |
| Ingress.reg_w_carry_dur | 8 | 2 | 2 | 1 |
| Ingress.reg_w_carry_len | 9 | 2 | 2 | 1 |
| Ingress.reg_w_chg_dur | 8 | 2 | 2 | 1 |
| Ingress.reg_w_chg_len | 9 | 2 | 2 | 1 |
| Ingress.reg_w_cnt | 9 | 2 | 2 | 1 |
| Ingress.reg_w_flags | 3 | 2 | 2 | 1 |
| Ingress.reg_w_pa | 9 | 2 | 2 | 1 |
| Ingress.reg_w_pb | 2 | 2 | 2 | 1 |
| Ingress.reg_w_pd | 8 | 2 | 2 | 1 |
| Ingress.reg_w_rst | 3 | 2 | 2 | 1 |
| Ingress.reg_w_tot | 10 | 2 | 2 | 1 |
| Ingress.reg_way1 | 2 | 5 | 5 | 1 |
| Ingress.reg_way2 | 3 | 5 | 5 | 1 |
| Ingress.reg_way3 | 4 | 5 | 5 | 1 |
| Ingress.reg_way4 | 5 | 5 | 5 | 1 |

## basic_exact_v3_timer: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 8 (10%) | 6 (12%) | 5 (21%) | 1 (25%) | 2 (50%) | 42 (10%) | 2 (33%) | 6 (38%) | 6 (19%) | 24 (19%) | 11 (69%) |
| 1 | 1 (1%) | 0 | 2 (8%) | 0 | 0 | 0 | 0 | 0 | 3 (9%) | 0 | 3 (19%) |
| 2 | 7 (9%) | 7 (15%) | 0 | 2 (50%) | 0 | 71 (17%) | 6 (100%) | 5 (31%) | 3 (9%) | 36 (28%) | 5 (31%) |
| 3 | 9 (11%) | 9 (19%) | 0 | 3 (75%) | 0 | 19 (5%) | 3 (50%) | 4 (25%) | 2 (6%) | 11 (9%) | 5 (31%) |
| 4 | 5 (6%) | 5 (10%) | 0 | 1 (25%) | 0 | 14 (3%) | 1 (17%) | 2 (12%) | 2 (6%) | 7 (5%) | 2 (12%) |
| 5 | 5 (6%) | 5 (10%) | 0 | 1 (25%) | 0 | 14 (3%) | 1 (17%) | 2 (12%) | 2 (6%) | 7 (5%) | 2 (12%) |
| 6 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 64 (15%) | 4 (67%) | 8 (50%) | 5 (16%) | 16 (12%) | 8 (50%) |
| 7 | 23 (29%) | 23 (48%) | 0 | 3 (75%) | 0 | 64 (15%) | 3 (50%) | 6 (38%) | 4 (12%) | 9 (7%) | 8 (50%) |
| 8 | 11 (14%) | 11 (23%) | 0 | 4 (100%) | 0 | 21 (5%) | 3 (50%) | 4 (25%) | 2 (6%) | 19 (15%) | 5 (31%) |
| 9 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 16 (4%) | 4 (67%) | 5 (31%) | 1 (3%) | 17 (13%) | 5 (31%) |
| 10 | 2 (2%) | 2 (4%) | 0 | 1 (25%) | 0 | 3 (1%) | 1 (17%) | 1 (6%) | 1 (3%) | 5 (4%) | 1 (6%) |

### basic_exact_v3_timer: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ba | 8 | 5 | 5 | 1 |
| Ingress.reg_epoch | 0 | 2 | 2 | 1 |
| Ingress.reg_first | 6 | 17 | 17 | 1 |
| Ingress.reg_last | 6 | 17 | 17 | 1 |
| Ingress.reg_max | 6 | 9 | 9 | 1 |
| Ingress.reg_min | 7 | 9 | 9 | 1 |
| Ingress.reg_ref | 7 | 5 | 5 | 1 |
| Ingress.reg_seen | 7 | 9 | 9 | 1 |
| Ingress.reg_w_carry_dur | 8 | 2 | 2 | 1 |
| Ingress.reg_w_carry_len | 9 | 2 | 2 | 1 |
| Ingress.reg_w_chg_dur | 8 | 2 | 2 | 1 |
| Ingress.reg_w_chg_len | 9 | 2 | 2 | 1 |
| Ingress.reg_w_cnt | 9 | 2 | 2 | 1 |
| Ingress.reg_w_flags | 3 | 2 | 2 | 1 |
| Ingress.reg_w_pa | 9 | 2 | 2 | 1 |
| Ingress.reg_w_pb | 2 | 2 | 2 | 1 |
| Ingress.reg_w_pd | 8 | 2 | 2 | 1 |
| Ingress.reg_w_rst | 3 | 2 | 2 | 1 |
| Ingress.reg_w_tot | 10 | 2 | 2 | 1 |
| Ingress.reg_way1 | 2 | 5 | 5 | 1 |
| Ingress.reg_way2 | 3 | 5 | 5 | 1 |
| Ingress.reg_way3 | 4 | 5 | 5 | 1 |
| Ingress.reg_way4 | 5 | 5 | 5 | 1 |

## basic_hwl_exact_v3: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 8 (10%) | 6 (12%) | 5 (21%) | 1 (25%) | 2 (50%) | 42 (10%) | 2 (33%) | 6 (38%) | 6 (19%) | 24 (19%) | 12 (75%) |
| 1 | 1 (1%) | 0 | 2 (8%) | 0 | 0 | 0 | 0 | 1 (6%) | 3 (9%) | 2 (2%) | 4 (25%) |
| 2 | 7 (9%) | 7 (15%) | 0 | 2 (50%) | 0 | 71 (17%) | 6 (100%) | 5 (31%) | 3 (9%) | 36 (28%) | 5 (31%) |
| 3 | 9 (11%) | 9 (19%) | 0 | 3 (75%) | 0 | 19 (5%) | 3 (50%) | 4 (25%) | 2 (6%) | 11 (9%) | 5 (31%) |
| 4 | 5 (6%) | 5 (10%) | 0 | 1 (25%) | 0 | 14 (3%) | 1 (17%) | 2 (12%) | 2 (6%) | 7 (5%) | 2 (12%) |
| 5 | 5 (6%) | 5 (10%) | 0 | 1 (25%) | 0 | 14 (3%) | 1 (17%) | 2 (12%) | 2 (6%) | 7 (5%) | 2 (12%) |
| 6 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 64 (15%) | 4 (67%) | 8 (50%) | 5 (16%) | 16 (12%) | 8 (50%) |
| 7 | 23 (29%) | 23 (48%) | 0 | 3 (75%) | 0 | 64 (15%) | 3 (50%) | 6 (38%) | 4 (12%) | 9 (7%) | 8 (50%) |
| 8 | 11 (14%) | 11 (23%) | 0 | 4 (100%) | 0 | 21 (5%) | 3 (50%) | 4 (25%) | 2 (6%) | 19 (15%) | 5 (31%) |
| 9 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 16 (4%) | 4 (67%) | 5 (31%) | 1 (3%) | 17 (13%) | 5 (31%) |
| 10 | 2 (2%) | 2 (4%) | 0 | 1 (25%) | 0 | 3 (1%) | 1 (17%) | 1 (6%) | 1 (3%) | 5 (4%) | 1 (6%) |

### basic_hwl_exact_v3: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ba | 8 | 5 | 5 | 1 |
| Ingress.reg_epoch | 0 | 2 | 2 | 1 |
| Ingress.reg_first | 6 | 17 | 17 | 1 |
| Ingress.reg_last | 6 | 17 | 17 | 1 |
| Ingress.reg_max | 6 | 9 | 9 | 1 |
| Ingress.reg_min | 7 | 9 | 9 | 1 |
| Ingress.reg_ref | 7 | 5 | 5 | 1 |
| Ingress.reg_seen | 7 | 9 | 9 | 1 |
| Ingress.reg_w_carry_dur | 8 | 2 | 2 | 1 |
| Ingress.reg_w_carry_len | 9 | 2 | 2 | 1 |
| Ingress.reg_w_chg_dur | 8 | 2 | 2 | 1 |
| Ingress.reg_w_chg_len | 9 | 2 | 2 | 1 |
| Ingress.reg_w_cnt | 9 | 2 | 2 | 1 |
| Ingress.reg_w_flags | 3 | 2 | 2 | 1 |
| Ingress.reg_w_pa | 9 | 2 | 2 | 1 |
| Ingress.reg_w_pb | 2 | 2 | 2 | 1 |
| Ingress.reg_w_pd | 8 | 2 | 2 | 1 |
| Ingress.reg_w_rst | 3 | 2 | 2 | 1 |
| Ingress.reg_w_tot | 10 | 2 | 2 | 1 |
| Ingress.reg_way1 | 2 | 5 | 5 | 1 |
| Ingress.reg_way2 | 3 | 5 | 5 | 1 |
| Ingress.reg_way3 | 4 | 5 | 5 | 1 |
| Ingress.reg_way4 | 5 | 5 | 5 | 1 |

