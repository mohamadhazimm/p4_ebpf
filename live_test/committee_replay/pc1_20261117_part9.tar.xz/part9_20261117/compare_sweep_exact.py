#!/usr/bin/env python3
"""PC1.md part 9b/9F: the sweep build's 109 replays against the exact build's (part 6) and the bucket-table builds'.

    compare_sweep_exact.py SWEEP_DIR EXACT_COMPARE_CSV [OUT_PREFIX]

SWEEP_DIR is run_sweep_replays.py's output (runs.csv, <id>/summary.json); EXACT_COMPARE_CSV is
perf/results/exact_replay/exact_compare.csv (per capture: columns equal to the published row, of 135 non-duration
columns, for basic_fix "_bf", basic_gtot_ba "_ba" and the exact build "_ex"). Prints a summary and the captures where
the builds differ; writes OUT_PREFIX.csv (one line per capture) and OUT_PREFIX.json (the summary).
"""
import csv
import json
import statistics as st
import sys
from pathlib import Path

sweep_dir, exact_csv = Path(sys.argv[1]), sys.argv[2]
out = sys.argv[3] if len(sys.argv) > 3 else str(sweep_dir / "compare_exact")
ex = {r["execution_id"]: r for r in csv.DictReader(open(exact_csv))}
rows = []
for r in csv.DictReader(open(sweep_dir / "runs.csv")):
    eid = r["execution_id"]
    s_path = sweep_dir / eid / "summary.json"
    s = json.loads(s_path.read_text()) if s_path.exists() else {}
    e = ex.get(eid, {})
    num = lambda v: int(v) if v not in (None, "") else None
    rows.append(dict(
        execution_id=eid, status=r["status"], failed_checks=r.get("failed_checks", ""),
        sweep=num(r.get("exact_nodur")), model=s.get("model_exact_nodur"), switch_eq_model=s.get("equal_model_nodur"),
        exact=num(e.get("exact135_ex")), gtot_ba=num(e.get("exact135_ba")), basic_fix=num(e.get("exact135_bf")),
        exact_untracked=num(e.get("untracked")), pkts=s.get("pkts"), pkts_model=s.get("pkts_model"),
        probes=s.get("switch_probes"), exports=s.get("switch_exported"), frames_failed=s.get("frames_failed"),
        tcpdump_drops=(s.get("tcpdump") or {}).get("dropped_by_kernel")))
both = [x for x in rows if x["sweep"] is not None and x["exact"] is not None]
summ = {
    "captures": len(rows), "in_both": len(both),
    "checks_ok": sum(1 for x in rows if x["status"] == "ok"),
    "switch_equal_model_135": sum(1 for x in rows if x["switch_eq_model"] == 135),
    "equal_published_135": {k: sum(1 for x in both if x[k] == 135) for k in ("sweep", "exact", "gtot_ba", "basic_fix")},
    "mean_135": {k: round(st.mean(x[k] for x in both), 1) for k in ("sweep", "exact", "gtot_ba", "basic_fix")},
    "sweep_better": [x["execution_id"] for x in both if x["sweep"] > x["exact"]],
    "exact_better": [x["execution_id"] for x in both if x["exact"] > x["sweep"]],
    "sweep_vs_model_prediction_differs": [x["execution_id"] for x in rows if x["model"] is not None and
                                          x["sweep"] != x["model"]],
    "not_ok": [(x["execution_id"], x["status"], x["failed_checks"]) for x in rows if x["status"] != "ok"],
}
with open(out + ".csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)
Path(out + ".json").write_text(json.dumps(summ, indent=1))
print(json.dumps({k: v for k, v in summ.items() if k not in ("sweep_better", "exact_better")}, indent=1))
print("\n| Capture | sweep | exact | basic_gtot_ba | basic_fix | exact untracked |")
print("|---|---|---|---|---|---|")
for x in both:
    if x["sweep"] != x["exact"] or x["sweep"] != 135:
        print("| %s | %s | %s | %s | %s | %s |" % (x["execution_id"][:16], x["sweep"], x["exact"], x["gtot_ba"],
                                                    x["basic_fix"], x["exact_untracked"]))
