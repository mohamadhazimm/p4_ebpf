/* Forwarding-only baseline for the hardware benchmarks; not part of the
 * detector. The forwarding table, its actions and its default are copied from
 * thesis-hybrid-ebpf-p4/ingress.p4, with the same control names, so one
 * control-plane script programs both (pipe.Ingress.forwarding). The parsers
 * extract intrinsic metadata only and egress is empty, so every byte of the
 * packet passes through unparsed.
 *
 *   bf-p4c --target tofino --arch tna baseline.p4
 *
 * This copy (perf/variants/hwl) adds the ASIC latency report of the detector's
 * hwl variant: the same headers, bridge, egress parser and report logic.
 */
#include <core.p4>
#include <tna.p4>

const bit<16> ETHERTYPE_IPV4 = 0x0800;
const bit<8>  IP_PROTO_UDP   = 17;

header ethernet_t {
    bit<48> dst;
    bit<48> src;
    bit<16> eth_type;
}

header ipv4_t {
    bit<4>  version;
    bit<4>  ihl;
    bit<8>  diffserv;
    bit<16> totalLen;
    bit<16> identification;
    bit<3>  flags;
    bit<13> fragOffset;
    bit<8>  ttl;
    bit<8>  protocol;
    bit<16> hdrChecksum;
    bit<32> srcAddr;
    bit<32> dstAddr;
}

/* ASIC latency report, the measurement of reference_evaluation/P4_Code
 * (perf/variants/hwl): ingress puts its parser timestamp into a bridge header,
 * and egress inserts the 20-byte report after Ethernet of IPv4/UDP packets and
 * sets EtherType 0x88BC. Decoded by that package's scripts/probe_format.py. */
const bit<32> HW_LATENCY_MAGIC     = 0x48574C31;   /* "HWL1" */
const bit<16> ETHERTYPE_HW_LATENCY = 0x88BC;
const PortId_t HW_LATENCY_CPU_PORT = 192;          /* mirrored CPU reports: no bridge */

header hw_latency_bridge_h {
    bit<48> ingress_ns;
    bit<8>  score;
    bit<8>  tier;
}

header hw_latency_report_h {
    bit<32> magic;
    bit<16> original_ether_type;
    bit<48> ingress_ns;
    bit<48> egress_ns;
    bit<8>  score;
    bit<8>  tier;
}

struct my_headers_t {
    hw_latency_bridge_h hw_bridge;
}
struct my_ingress_metadata_t {}
struct my_egress_headers_t {
    hw_latency_bridge_h hw_bridge;
    ethernet_t ethernet;
    hw_latency_report_h hw_report;
    ipv4_t     ipv4;
}
struct my_egress_metadata_t {}

parser IngressParser(
    packet_in pkt,
    out my_headers_t hdr,
    out my_ingress_metadata_t meta,
    out ingress_intrinsic_metadata_t ig_intr_md
) {
    state start {
        pkt.extract(ig_intr_md);
        pkt.advance(PORT_METADATA_SIZE);
        transition accept;
    }
}

control Ingress(
    inout my_headers_t hdr,
    inout my_ingress_metadata_t meta,
    in    ingress_intrinsic_metadata_t               ig_intr_md,
    in    ingress_intrinsic_metadata_from_parser_t   ig_prsr_md,
    inout ingress_intrinsic_metadata_for_deparser_t  ig_dprsr_md,
    inout ingress_intrinsic_metadata_for_tm_t        ig_tm_md)
{
    action send_using_port(PortId_t port) {
        ig_tm_md.ucast_egress_port = port;
        ig_tm_md.bypass_egress     = 0;
    }

    action drop() {
        ig_dprsr_md.drop_ctl       = 3w1;
        ig_tm_md.bypass_egress     = 1w1;
    }

    table forwarding {
        key = {
            ig_intr_md.ingress_port : exact;
        }
        actions = {
            send_using_port;
            drop;
        }
        const default_action = drop();
        size = 256;
    }

    apply {
        hdr.hw_bridge.setValid();
        hdr.hw_bridge.ingress_ns = ig_prsr_md.global_tstamp;
        hdr.hw_bridge.score      = 0;
        hdr.hw_bridge.tier       = 0;

        forwarding.apply();
    }
}

control IngressDeparser(
    packet_out pkt,
    inout my_headers_t hdr,
    in    my_ingress_metadata_t meta,
    in    ingress_intrinsic_metadata_for_deparser_t ig_dprsr_md)
{
    apply {
        pkt.emit(hdr);
    }
}

parser EgressParser(
    packet_in pkt,
    out my_egress_headers_t         hdr,
    out my_egress_metadata_t        meta,
    out egress_intrinsic_metadata_t eg_intr_md)
{
    state start {
        pkt.extract(eg_intr_md);
        transition select(eg_intr_md.egress_port) {
            HW_LATENCY_CPU_PORT: accept;
            default: parse_hw_bridge;
        }
    }

    state parse_hw_bridge {
        pkt.extract(hdr.hw_bridge);
        pkt.extract(hdr.ethernet);
        transition select(hdr.ethernet.eth_type) {
            ETHERTYPE_IPV4: parse_ipv4;
            default: accept;
        }
    }

    state parse_ipv4 {
        pkt.extract(hdr.ipv4);
        transition accept;
    }
}

control Egress(
    inout my_egress_headers_t                          hdr,
    inout my_egress_metadata_t                         meta,
    in    egress_intrinsic_metadata_t                  eg_intr_md,
    in    egress_intrinsic_metadata_from_parser_t      eg_prsr_md,
    inout egress_intrinsic_metadata_for_deparser_t     eg_dprsr_md,
    inout egress_intrinsic_metadata_for_output_port_t  eg_oport_md)
{
    apply {
        if (hdr.ipv4.isValid() && hdr.ipv4.protocol == IP_PROTO_UDP) {
            hdr.hw_report.setValid();
            hdr.hw_report.magic               = HW_LATENCY_MAGIC;
            hdr.hw_report.original_ether_type = hdr.ethernet.eth_type;
            hdr.hw_report.ingress_ns          = hdr.hw_bridge.ingress_ns;
            hdr.hw_report.egress_ns           = eg_prsr_md.global_tstamp;
            hdr.hw_report.score               = hdr.hw_bridge.score;
            hdr.hw_report.tier                = hdr.hw_bridge.tier;
            hdr.ethernet.eth_type             = ETHERTYPE_HW_LATENCY;
        }
        hdr.hw_bridge.setInvalid();
    }
}

control EgressDeparser(packet_out pkt,
    inout my_egress_headers_t                       hdr,
    in    my_egress_metadata_t                      meta,
    in    egress_intrinsic_metadata_for_deparser_t  eg_dprsr_md)
{
    apply {
        pkt.emit(hdr);
    }
}

Pipeline(
    IngressParser(),
    Ingress(),
    IngressDeparser(),
    EgressParser(),
    Egress(),
    EgressDeparser()
) pipe;
Switch(pipe) main;
