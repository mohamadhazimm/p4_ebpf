parser EgressParser(
    packet_in pkt,
    /* User */
    out my_egress_headers_t         hdr,
    out my_egress_metadata_t        meta,
    /* Intrinsic */
    out egress_intrinsic_metadata_t eg_intr_md)
{
    state start {
        pkt.extract(eg_intr_md);
        transition select(eg_intr_md.egress_port) {
            HW_LATENCY_CPU_PORT: accept;
            default: parse_hw_bridge;
        }
    }

    state parse_hw_bridge {
        pkt.extract(hdr.hw_bridge);
        pkt.extract(hdr.ethernet);
        transition select(hdr.ethernet.eth_type) {
            ETHERTYPE_IPV4: parse_ipv4;
            default: accept;
        }
    }

    state parse_ipv4 {
        pkt.extract(hdr.ipv4);
        transition accept;
    }
}