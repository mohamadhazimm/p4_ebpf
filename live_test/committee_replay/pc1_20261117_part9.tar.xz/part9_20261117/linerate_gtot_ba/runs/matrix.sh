#!/bin/bash
# PC1.md part 9A: p4_perf 3.2 matrix on basic_gtot_ba (gtot -DP4_GLOBAL_TOTALS_SPLIT=1), its split totals counted
cd /root/hazim_perf/runs/part9_linerate_gtot_ba_20261117
T=/root/hazim_perf/tools/sw_pktgen_run.py
run() { out=$1; shift; python2.7 $T $out --prog basic --seconds 10 --flow-index 44993 --global-totals "$@" > ${out%.json}.log 2>&1; }
for r in 1 2 3; do run gtot_ba_64_max_r$r.json --size 64; done
for s in 128 256 512 1024 1280 1518; do
    for r in 1 2 3; do run gtot_ba_${s}_paced_r$r.json --size $s --rate-pct 99.9; done
    run gtot_ba_${s}_max.json --size $s
done
python2.7 $T cleanup.json --prog basic --cleanup > cleanup.log 2>&1
date -u +%FT%TZ > matrix.done
