# Phase 1: compile-time resources

Usage over the whole pipe (all MAU stages; ingress and egress share them). MAU latency is the compiler's estimate in pipeline clock cycles.

| variant | status | -D flags | stages ig/eg | crit. path | sram | map ram | tcam | stateful alu | hash bit | gateway | logical table | PHV normal | PHV tagalong | parser TCAM ig/eg | MAU latency ig/eg | power ig/eg (W) | compile wall s | peak RSS MiB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| basic_gtot_ba | ok | P4_GLOBAL_TOTALS_SPLIT=1 | 6/1 | 4 | 211/960 (22.0%) | 210/576 (36.5%) | 3/288 (1.0%) | 21/48 (43.8%) | 208/4992 (4.2%) | 22/192 (11.5%) | 29/192 (15.1%) | 8/64×8b, 13/96×16b, 5/64×32b | 4/32×8b, 10/48×16b, 6/32×32b | 9/1 | 133/170 | 10.51/0.00 | 21.903 | 193 |
| basic_sweep_ctrl | ok | P4_ENABLE_SWEEP=0 P4_FRAME_LEN=0 | 6/1 | 4 | 211/960 (22.0%) | 210/576 (36.5%) | 3/288 (1.0%) | 21/48 (43.8%) | 208/4992 (4.2%) | 22/192 (11.5%) | 29/192 (15.1%) | 8/64×8b, 13/96×16b, 5/64×32b | 4/32×8b, 10/48×16b, 6/32×32b | 9/1 | 133/170 | 10.51/0.00 | 22.503 | 198 |
| basic_sweep_noprobe | ok | P4_ENABLE_SWEEP=0 | 6/1 | 4 | 212/960 (22.1%) | 210/576 (36.5%) | 5/288 (1.7%) | 21/48 (43.8%) | 208/4992 (4.2%) | 22/192 (11.5%) | 30/192 (15.6%) | 8/64×8b, 14/96×16b, 5/64×32b | 2/32×8b, 10/48×16b, 6/32×32b | 9/1 | 133/170 | 10.80/0.00 | 22.101 | 195 |
| basic_hwl_gtot_ba | ok | P4_GLOBAL_TOTALS_SPLIT=1 | 6/2 | 4 | 211/960 (22.0%) | 210/576 (36.5%) | 3/288 (1.0%) | 21/48 (43.8%) | 208/4992 (4.2%) | 23/192 (12.0%) | 31/192 (16.1%) | 11/64×8b, 19/96×16b, 8/64×32b | 7/32×8b, 20/48×16b, 11/32×32b | 9/8 | 133/172 | 10.51/0.73 | 26.453 | 209 |
| basic_sweep | **failed** | – | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 71.015 | 273 |
| basic_sweep_si | **failed** | SWEEP_SHARED_INDEX=1 | – | – | – | – | – | – | – | – | – | – | – | – | – | – | 71.442 | 278 |

## basic_gtot_ba: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 44 (55%) | 43 (90%) | 3 (12%) | 4 (100%) | 1 (25%) | 42 (10%) | 2 (33%) | 5 (31%) | 3 (9%) | 25 (20%) | 8 (50%) |
| 1 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 16 (4%) | 1 (17%) | 4 (25%) | 1 (3%) | 14 (11%) | 4 (25%) |
| 2 | 44 (55%) | 44 (92%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 20 (16%) | 6 (38%) |
| 3 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 25 (20%) | 5 (31%) |
| 4 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 36 (9%) | 0 | 0 | 1 (3%) | 8 (6%) | 4 (25%) |
| 5 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_gtot_ba: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 1 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 1 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 2 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_sweep_ctrl: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 44 (55%) | 43 (90%) | 3 (12%) | 4 (100%) | 1 (25%) | 42 (10%) | 2 (33%) | 5 (31%) | 3 (9%) | 25 (20%) | 8 (50%) |
| 1 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 16 (4%) | 1 (17%) | 4 (25%) | 1 (3%) | 14 (11%) | 4 (25%) |
| 2 | 44 (55%) | 44 (92%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 20 (16%) | 6 (38%) |
| 3 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 25 (20%) | 5 (31%) |
| 4 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 36 (9%) | 0 | 0 | 1 (3%) | 8 (6%) | 4 (25%) |
| 5 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_sweep_ctrl: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 1 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 1 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 2 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_sweep_noprobe: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 45 (56%) | 43 (90%) | 5 (21%) | 4 (100%) | 1 (25%) | 42 (10%) | 2 (33%) | 5 (31%) | 3 (9%) | 25 (20%) | 9 (56%) |
| 1 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 16 (4%) | 1 (17%) | 4 (25%) | 1 (3%) | 14 (11%) | 4 (25%) |
| 2 | 44 (55%) | 44 (92%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 20 (16%) | 6 (38%) |
| 3 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 25 (20%) | 5 (31%) |
| 4 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 36 (9%) | 0 | 0 | 1 (3%) | 8 (6%) | 4 (25%) |
| 5 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_sweep_noprobe: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 1 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 1 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 2 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_hwl_gtot_ba: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 44 (55%) | 43 (90%) | 3 (12%) | 4 (100%) | 1 (25%) | 42 (10%) | 2 (33%) | 5 (31%) | 3 (9%) | 25 (20%) | 9 (56%) |
| 1 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 16 (4%) | 1 (17%) | 5 (31%) | 1 (3%) | 16 (12%) | 5 (31%) |
| 2 | 44 (55%) | 44 (92%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 20 (16%) | 6 (38%) |
| 3 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 25 (20%) | 5 (31%) |
| 4 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 36 (9%) | 0 | 0 | 1 (3%) | 8 (6%) | 4 (25%) |
| 5 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_hwl_gtot_ba: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 1 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 1 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 2 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## Failed compiles

**basic_sweep** (exit 3):
```
error: Table placement cannot make any more progress.  Though some tables have not yet been placed, dependency analysis has found that no more tables are placeable.  This may be due to shared attachments on partly placed tables; may be able to avoid the problem with @stage on those tables
Number of errors exceeded set maximum of 1
```

Table-placement rounds before the failure: round 1 (INITIAL): 4 ingress / 1 egress stages; round 2 (NOCC_TRY1): 4 ingress / 1 egress stages; round 3 (REDO_PHV1): 4 ingress / 1 egress stages; round 4 (NOCC_TRY2): 4 ingress / 1 egress stages; round 5 (REDO_PHV2): 4 ingress / 1 egress stages.

**basic_sweep_si** (exit 3):
```
error: Table placement cannot make any more progress.  Though some tables have not yet been placed, dependency analysis has found that no more tables are placeable.  This may be due to shared attachments on partly placed tables; may be able to avoid the problem with @stage on those tables
Number of errors exceeded set maximum of 1
```

Table-placement rounds before the failure: round 1 (INITIAL): 4 ingress / 1 egress stages; round 2 (NOCC_TRY1): 4 ingress / 1 egress stages; round 3 (REDO_PHV1): 4 ingress / 1 egress stages; round 4 (NOCC_TRY2): 4 ingress / 1 egress stages; round 5 (REDO_PHV2): 4 ingress / 1 egress stages.

