#!/bin/bash
# part 9 compiles (PC1.md part 9B, 9A/9E latency builds), one after another
H=/root/hazim_perf
C=$H/tools/sw_compile.sh
bash $C $H/src/basic_sweep basic.p4 $H/build/basic_sweep
bash $C $H/src/basic_sweep basic.p4 $H/build/basic_sweep_ctrl -DP4_ENABLE_SWEEP=0 -DP4_FRAME_LEN=0
bash $C $H/src/basic_sweep basic.p4 $H/build/basic_sweep_noprobe -DP4_ENABLE_SWEEP=0
bash $C $H/src/basic_hwl_gtot_ba basic.p4 $H/build/basic_hwl_gtot_ba -DP4_GLOBAL_TOTALS_SPLIT=1
bash $C $H/src/basic_hwl_sweep basic.p4 $H/build/basic_hwl_sweep
touch $H/build/part9_compiles.done
#!/bin/bash
# part 9B fallback: the default sweep build failed table placement (two index sources per register)
H=/root/hazim_perf
bash $H/tools/sw_compile.sh $H/src/basic_sweep basic.p4 $H/build/basic_sweep_si -DSWEEP_SHARED_INDEX=1
bash $H/tools/sw_compile.sh $H/src/basic_hwl_sweep basic.p4 $H/build/basic_hwl_sweep_si -DSWEEP_SHARED_INDEX=1
touch $H/build/part9_si.done
