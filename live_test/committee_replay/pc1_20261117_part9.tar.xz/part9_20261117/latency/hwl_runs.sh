#!/bin/bash
# PC1.md part 9A: ASIC latency of basic_gtot_ba (gtot -DP4_GLOBAL_TOTALS_SPLIT=1) against basic_fix and the baseline, with p4_perf.md
# section 4.1's method as section 5.5 ran it: the HWL1 instrumentation (perf/variants/hwl), hairpin
# PC1 -> 1/0 -> switch -> 1/0 -> PC1, reference_evaluation/P4_Code/scripts/send_probes.py (1010 probes,
# 100 pkt/s) and collect_reports.py --pcap (10 warm-up probes excluded), 3 runs per program.
#   hwl_runs.sh ASROOT OUT_DIR
set -u
ASROOT=$1; OUT=$2
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
SC=$REPO/reference_evaluation/P4_Code/scripts
T=/root/hazim_perf/tools/sw_switchd.sh
sw() { ssh -o BatchMode=yes root@172.168.1.2 "$@"; }
mkdir -p "$OUT"
for spec in baseline_hwl_nonewconn:baseline_hwl:baseline_hwl.conf basic_hwl_nonewconn:basic:basic.conf \
            basic_hwl_gtot_ba:basic:basic.conf; do
    IFS=: read -r build prog conf <<< "$spec"
    echo "== $build ($(date +%T))"
    sw "bash $T stop; bash $T start /root/hazim_perf/build/$build/$conf /root/hazim_perf/runs/part9_latency_20261117 \
        && bash $T ready 180" 2>&1 | grep -E 'stopped|listeners up|SAFETY|ready|exited|timeout|refusing'
    "$REPO/perf/tools/run_bfrt.sh" "$OUT/setup_$build" setup setup --prog "$prog" --ports 132,140 --fwd 132:132 \
        --mirror-sid 1 2>&1 | grep -E 'setup\] (added|forwarding|mirror)|refusing|failed'
    for r in 1 2 3; do
        d=$OUT/${build}_hairpin_r$r
        mkdir -p "$d"
        "$ASROOT" timeout -s INT 25 tcpdump -i eth1 -Q in -c 1010 -s 256 -w "$d/capture.pcap" ether proto 0x88bc \
            > "$d/tcpdump.log" 2>&1 &
        cap=$!
        sleep 2
        (cd "$d" && "$ASROOT" python3 "$SC/send_probes.py" --iface eth1 --dst-mac 02:00:00:00:00:02 --count 1010 \
            --rate 100 --log "$d/sent_probes.jsonl") > "$d/send.log" 2>&1
        wait "$cap"
        python3 "$SC/collect_reports.py" --pcap "$d/capture.pcap" --out "$d/result" --expected-count 1010 \
            --warmup 10 > "$d/collect.log" 2>&1
        python3 -c "
import json, sys
s = json.load(open('$d/result/summary.json'))
print('  r$r: reports %s, missing %s, malformed %s; min %s median %s mean %s p99 %s max %s ns' % (s['unique_reports'],
      s['missing_reports'], s['capture_counts']['malformed_reports'], s['min_ns'], s['median_ns'], s['mean_ns'],
      s['p99_ns'], s['max_ns']))" 2>&1 || tail -3 "$d/collect.log"
    done
done
echo "== done ($(date +%T)); the switch runs the last build"
