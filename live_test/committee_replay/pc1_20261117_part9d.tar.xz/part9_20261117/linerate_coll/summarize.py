#!/usr/bin/env python3
"""PC1.md part 9d: the line-rate matrix of the sweep build with the collision counter (coll_*.json, DIR) against the
sweep build without it (sweepB_*.json, REF_DIR, part 9b), and the global totals' exactness: pipe 1 (the generator's) must grow by the generated packets, pipe 0
by the looped-back ones (the sink's RX), the byte totals as the flow's reg_bytes (mod 2^32), pkts_ab as pkts, the
TCP flags not at all (UDP).
    summarize.py DIR REF_DIR"""
import glob
import json
import os
import statistics as st
import sys

d, ref = sys.argv[1], sys.argv[2]
SIZES = [64, 128, 256, 512, 1024, 1280, 1518]


def load(pattern, where=None):
    return [json.load(open(p)) for p in sorted(glob.glob(os.path.join(where or d, pattern)))]


runs, problems, total_pkts = [], [], 0
for size in SIZES:
    kinds = [("max", "coll_64_max_r*.json", "sweepB_64_max_r*.json")] if size == 64 else [
        ("paced", "coll_%d_paced_r*.json" % size, "sweepB_%d_paced_r*.json" % size),
        ("max", "coll_%d_max.json" % size, "sweepB_%d_max.json" % size)]
    for kind, gp, bp in kinds:
        g, b = load(gp), load(bp, ref)
        for o in g:
            name = "%d %s" % (size, kind)
            if o["errors"]:
                problems.append((name, "errors", o["errors"]))
            gen, tx, rx = o["generated"], o["sink_tx_frames"], o["sink_rx_frames"]
            drops = (o.get("tm_eg_delta") or {}).get("drop_count_packets")
            gd, flow_p, flow_b = o["global_delta"], o["reg_pkts_delta"], o["reg_bytes_delta"]
            checks = {
                "flow pkts pipe 1 = generated": flow_p[1] == gen,
                "global pkts pipe 1 = generated": gd["pkts"][1] == gen,
                "global pkts pipe 0 = looped back": gd["pkts"][0] == rx,
                "global bytes = flow bytes": gd["bytes"] == flow_b,
                "pkts_ab = pkts, bytes_ab = bytes": gd["pkts_ab"] == gd["pkts"] and gd["bytes_ab"] == gd["bytes"],
                "no TCP flags": gd["syn"] == gd["ack"] == gd["rst"] == [0, 0],
                "B->A = 0 (one-way flow)": gd["pkts_ba"] == gd["bytes_ba"] == [0, 0],
                "tx = rx": tx == rx,
                "lossless or drops = excess": (drops == 0 and gen == tx) if kind == "paced" or size == 64
                                              else (drops == gen - tx),
            }
            for k, ok in checks.items():
                if not ok:
                    problems.append((name, k, {"generated": gen, "tx": tx, "rx": rx, "drops": drops,
                                               "global_pkts": gd["pkts"], "flow_pkts": flow_p}))
            total_pkts += gen
        gp_ = [o["pct_of_line_rate"] for o in g]
        bp_ = [o["pct_of_line_rate"] for o in b]
        offered = [100.0 * o["gen_mpps"] / o["line_rate_mpps"] for o in g]
        runs.append((size, kind, len(g), gp_, bp_, offered))

print("| Frame (B) | run | sweep with collision counter: % of line rate | sweep without it (part 9b) | offered |")
print("|---|---|---|---|---|")
for size, kind, n, gp_, bp_, offered in runs:
    print("| %d | %s x%d | %s | %s | %.0f%% |" % (size, kind, n, " / ".join("%.2f%%" % x for x in gp_),
                                                  " / ".join("%.2f%%" % x for x in bp_), st.mean(offered)))
print()
print("runs: %d; packets generated: %d (%.1f billion)" % (sum(r[2] for r in runs), total_pkts, total_pkts / 1e9))
print("checks failed: %d" % len(problems))
for p in problems[:20]:
    print("  ", p)
