#!/bin/bash
# PC1.md part 9E, second form: line-rate traffic from pipe 0's generator, looped back by sink dev_port 148 (3/0, pipe 1,
# MAC near loopback) into pipe 1, where the sweep generator (pipe 1, local port 68) probes the same registers.
cd /root/hazim_perf/runs/part9_9e2_20261117
SR="python2.7 /root/hazim_perf/tools/sweep_reader.py"
T=/root/hazim_perf/tools/sw_pktgen_run.py
export SDE_INSTALL=/root/bf-sde-9.6.0/install; export LD_LIBRARY_PATH=/usr/local/lib:$SDE_INSTALL/lib
run() { out=$1; shift; python2.7 $T $out --prog basic --seconds 10 --flow-index 44993 --global-totals --pipe 0 --sink-port 148 "$@" > ${out%.json}.log 2>&1; }
$SR --setup --reset --sweep-ports 132 --export-port 132 > setup.json 2>setup.log
run alone_1518.json --size 1518 --rate-pct 100
run alone_64.json --size 64
$SR --generator start --period-ns 500000000 --ipg-ns 2000 --pipes 1 --local-port 68 --app 0 > gen_start.json 2>gen_start.log
sleep 1
$SR --state --pipes 1 > state_before.json 2>/dev/null
run sweep_1518.json --size 1518 --rate-pct 100
$SR --state --pipes 1 > state_mid.json 2>/dev/null
run sweep_64.json --size 64
$SR --state --pipes 1 > state_after.json 2>/dev/null
$SR --generator stop --pipes 1 > gen_stop.json 2>gen_stop.log
$SR --state --pipes 1 > state_stopped.json 2>/dev/null
python2.7 $T cleanup.json --prog basic --cleanup --pipe 0 --sink-port 148 > cleanup.log 2>&1
date -u +%FT%TZ > done
