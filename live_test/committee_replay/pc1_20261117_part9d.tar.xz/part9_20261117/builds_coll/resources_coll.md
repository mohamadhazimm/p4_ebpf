# Phase 1: compile-time resources

Usage over the whole pipe (all MAU stages; ingress and egress share them). MAU latency is the compiler's estimate in pipeline clock cycles.

| variant | status | -D flags | stages ig/eg | crit. path | sram | map ram | tcam | stateful alu | hash bit | gateway | logical table | PHV normal | PHV tagalong | parser TCAM ig/eg | MAU latency ig/eg | power ig/eg (W) | compile wall s | peak RSS MiB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| basic_sweep_coll | ok | – | 7/1 | 5 | 245/960 (25.5%) | 221/576 (38.4%) | 20/288 (6.9%) | 23/48 (47.9%) | 358/4992 (7.2%) | 10/192 (5.2%) | 39/192 (20.3%) | 8/64×8b, 21/96×16b, 24/64×32b | 3/32×8b, 8/48×16b, 5/32×32b | 24/1 | 164/170 | 15.81/0.00 | 73.979 | 324 |
| basic_sweep_coll_ctrl | ok | P4_ENABLE_SWEEP=0 P4_FRAME_LEN=0 | 6/1 | 4 | 211/960 (22.0%) | 210/576 (36.5%) | 3/288 (1.0%) | 21/48 (43.8%) | 208/4992 (4.2%) | 22/192 (11.5%) | 29/192 (15.1%) | 8/64×8b, 13/96×16b, 5/64×32b | 4/32×8b, 10/48×16b, 6/32×32b | 9/1 | 133/170 | 10.51/0.00 | 23.65 | 197 |
| basic_hwl_sweep_coll | ok | – | 7/1 | 5 | 245/960 (25.5%) | 221/576 (38.4%) | 20/288 (6.9%) | 23/48 (47.9%) | 358/4992 (7.2%) | 11/192 (5.7%) | 41/192 (21.4%) | 12/64×8b, 27/96×16b, 27/64×32b | 6/32×8b, 18/48×16b, 10/32×32b | 24/8 | 164/170 | 15.81/0.19 | 90.133 | 335 |
| basic_sweep_final | ok | – | 6/1 | 5 | 239/960 (24.9%) | 216/576 (37.5%) | 20/288 (6.9%) | 22/48 (45.8%) | 314/4992 (6.3%) | 10/192 (5.2%) | 38/192 (19.8%) | 8/64×8b, 25/96×16b, 21/64×32b | 3/32×8b, 8/48×16b, 5/32×32b | 24/1 | 158/170 | 15.52/0.00 | 40.267 | 275 |

## basic_sweep_coll: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 16 (20%) | 12 (25%) | 11 (46%) | 4 (100%) | 2 (50%) | 16 (4%) | 1 (17%) | 4 (25%) | 7 (22%) | 18 (14%) | 10 (62%) |
| 1 | 42 (52%) | 39 (81%) | 0 | 3 (75%) | 0 | 62 (15%) | 2 (33%) | 0 | 4 (12%) | 11 (9%) | 3 (19%) |
| 2 | 48 (60%) | 44 (92%) | 3 (12%) | 4 (100%) | 0 | 58 (14%) | 3 (50%) | 2 (12%) | 6 (19%) | 21 (16%) | 6 (38%) |
| 3 | 34 (42%) | 31 (65%) | 0 | 3 (75%) | 0 | 80 (19%) | 3 (50%) | 2 (12%) | 5 (16%) | 15 (12%) | 6 (38%) |
| 4 | 42 (52%) | 38 (79%) | 4 (17%) | 4 (100%) | 0 | 34 (8%) | 1 (17%) | 0 | 5 (16%) | 6 (5%) | 4 (25%) |
| 5 | 42 (52%) | 38 (79%) | 2 (8%) | 4 (100%) | 0 | 72 (17%) | 1 (17%) | 0 | 5 (16%) | 10 (8%) | 4 (25%) |
| 6 | 21 (26%) | 19 (40%) | 0 | 1 (25%) | 1 (25%) | 36 (9%) | 1 (17%) | 2 (12%) | 5 (16%) | 8 (6%) | 6 (38%) |

### basic_sweep_coll: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 4 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_coll | 3 | 5 | 5 | 1 |
| Ingress.reg_dir_valid | 1 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 1 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 5 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 5 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 0 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 0 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 1 | 17 | 17 | 1 |
| Ingress.reg_max_len | 2 | 9 | 9 | 1 |
| Ingress.reg_min_len | 3 | 9 | 9 | 1 |
| Ingress.reg_pkts | 6 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 4 | 17 | 17 | 1 |
| Ingress.reg_sweep_seq | 0 | 2 | 2 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_sweep_coll_ctrl: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 44 (55%) | 43 (90%) | 3 (12%) | 4 (100%) | 1 (25%) | 42 (10%) | 2 (33%) | 5 (31%) | 3 (9%) | 25 (20%) | 8 (50%) |
| 1 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 16 (4%) | 1 (17%) | 4 (25%) | 1 (3%) | 14 (11%) | 4 (25%) |
| 2 | 44 (55%) | 44 (92%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 20 (16%) | 6 (38%) |
| 3 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 25 (20%) | 5 (31%) |
| 4 | 8 (10%) | 8 (17%) | 0 | 4 (100%) | 0 | 36 (9%) | 0 | 0 | 1 (3%) | 8 (6%) | 4 (25%) |
| 5 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_sweep_coll_ctrl: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 4 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 1 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 1 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 2 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_hwl_sweep_coll: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 16 (20%) | 12 (25%) | 11 (46%) | 4 (100%) | 2 (50%) | 16 (4%) | 1 (17%) | 5 (31%) | 7 (22%) | 20 (16%) | 12 (75%) |
| 1 | 42 (52%) | 39 (81%) | 0 | 3 (75%) | 0 | 62 (15%) | 2 (33%) | 0 | 4 (12%) | 11 (9%) | 3 (19%) |
| 2 | 48 (60%) | 44 (92%) | 3 (12%) | 4 (100%) | 0 | 58 (14%) | 3 (50%) | 2 (12%) | 6 (19%) | 21 (16%) | 6 (38%) |
| 3 | 34 (42%) | 31 (65%) | 0 | 3 (75%) | 0 | 80 (19%) | 3 (50%) | 2 (12%) | 5 (16%) | 15 (12%) | 6 (38%) |
| 4 | 42 (52%) | 38 (79%) | 4 (17%) | 4 (100%) | 0 | 34 (8%) | 1 (17%) | 0 | 5 (16%) | 6 (5%) | 4 (25%) |
| 5 | 42 (52%) | 38 (79%) | 2 (8%) | 4 (100%) | 0 | 72 (17%) | 1 (17%) | 0 | 5 (16%) | 10 (8%) | 4 (25%) |
| 6 | 21 (26%) | 19 (40%) | 0 | 1 (25%) | 1 (25%) | 36 (9%) | 1 (17%) | 2 (12%) | 5 (16%) | 8 (6%) | 6 (38%) |

### basic_hwl_sweep_coll: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 4 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_coll | 3 | 5 | 5 | 1 |
| Ingress.reg_dir_valid | 1 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 1 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 5 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 5 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 0 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 0 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 1 | 17 | 17 | 1 |
| Ingress.reg_max_len | 2 | 9 | 9 | 1 |
| Ingress.reg_min_len | 3 | 9 | 9 | 1 |
| Ingress.reg_pkts | 6 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 4 | 17 | 17 | 1 |
| Ingress.reg_sweep_seq | 0 | 2 | 2 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_sweep_final: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 16 (20%) | 12 (25%) | 11 (46%) | 4 (100%) | 2 (50%) | 16 (4%) | 1 (17%) | 4 (25%) | 7 (22%) | 18 (14%) | 10 (62%) |
| 1 | 42 (52%) | 39 (81%) | 0 | 3 (75%) | 0 | 62 (15%) | 2 (33%) | 0 | 4 (12%) | 11 (9%) | 3 (19%) |
| 2 | 48 (60%) | 44 (92%) | 3 (12%) | 4 (100%) | 0 | 58 (14%) | 3 (50%) | 2 (12%) | 6 (19%) | 21 (16%) | 6 (38%) |
| 3 | 46 (58%) | 43 (90%) | 0 | 3 (75%) | 0 | 62 (15%) | 2 (33%) | 2 (12%) | 5 (16%) | 15 (12%) | 6 (38%) |
| 4 | 42 (52%) | 38 (79%) | 4 (17%) | 4 (100%) | 0 | 34 (8%) | 1 (17%) | 0 | 5 (16%) | 6 (5%) | 4 (25%) |
| 5 | 45 (56%) | 40 (83%) | 2 (8%) | 4 (100%) | 1 (25%) | 82 (20%) | 1 (17%) | 2 (12%) | 8 (25%) | 15 (12%) | 9 (56%) |

### basic_sweep_final: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 4 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 1 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 1 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ba | 5 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ba | 5 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 0 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 0 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 1 | 17 | 17 | 1 |
| Ingress.reg_max_len | 2 | 9 | 9 | 1 |
| Ingress.reg_min_len | 3 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 4 | 17 | 17 | 1 |
| Ingress.reg_sweep_seq | 0 | 2 | 2 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

