#!/bin/bash
# PC1.md part 9E: line rate alone (the app on local port 68) and beside the sweep generator (sweep on 68, line rate on 69), basic_sweep_coll
cd /root/hazim_perf/runs/part9_9e_20261117
SR="python2.7 /root/hazim_perf/tools/sweep_reader.py"
T=/root/hazim_perf/tools/sw_pktgen_run.py
export SDE_INSTALL=/root/bf-sde-9.6.0/install; export LD_LIBRARY_PATH=/usr/local/lib:$SDE_INSTALL/lib
run() { out=$1; shift; python2.7 $T $out --prog basic --seconds 10 --flow-index 44993 --global-totals --first-local-port 69 --buffer-offset 4096 "$@" > ${out%.json}.log 2>&1; }
$SR --setup --reset --sweep-ports 132 --export-port 132 > setup.json 2>setup.log
run alone_1518.json --size 1518 --rate-pct 100 --first-local-port 68
run alone_64.json --size 64 --first-local-port 68
$SR --generator start --period-ns 500000000 --ipg-ns 2000 --pipes 1 --local-port 68 --app 0 > gen_start.json 2>gen_start.log
sleep 1
run sweep_1518.json --size 1518 --rate-pct 100
$SR --state --pipes 1 > state_mid.json 2>/dev/null
run sweep_64.json --size 64
$SR --state --pipes 1 > state_after.json 2>/dev/null
$SR --generator stop --pipes 1 > gen_stop.json 2>gen_stop.log
$SR --state --pipes 1 > state_stopped.json 2>/dev/null
python2.7 $T cleanup.json --prog basic --cleanup --first-local-port 69; python2.7 $T cleanup68.json --prog basic --cleanup --first-local-port 68 > cleanup68.log 2>&1 > cleanup.log 2>&1
date -u +%FT%TZ > done
