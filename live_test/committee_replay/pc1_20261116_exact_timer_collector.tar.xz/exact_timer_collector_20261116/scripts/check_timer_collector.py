#!/usr/bin/env python3
"""Check a run_timer_collector.sh run: hybrid_collector.py --window-markers timer against the frames sent.

    check_timer_collector.py RUN_DIR CAPTURE

- every window read, none lost, no unclocked / untracked packet, both pipes combined (timing.jsonl);
- the switch's packets over the windows = the frames sent that it counts (IPv4 TCP/UDP first fragments; the
  capture in order, less refused frames, with the send log's times);
- where the windows cut the sent stream: the cut after collector window w comes from the tick that ends it,
  due at the collector's boundary E_w (timing.jsonl t_window_end). It falls between the last frame of window w
  and the next frame, so tick - E_w lies in [send(last) - E_w, send(next) - E_w]. One offset d0 and one rate r,
  tick_w - E_w = d0 + r (E_w - E_0), must fit every cut: r is scanned over +-100 ppm, d0's feasible range is
  reported (the ticks' lag behind the collector's boundaries, and its drift).
Writes RUN_DIR/check.json.
"""
import csv
import json
import sys
from pathlib import Path

sys.path.insert(0, "/home/admin/Desktop/hAZIM/p4_ebpf/live_test")
from replay_absolute import read_pcap_us  # noqa: E402
from replay_capture import ipv4_l4_len  # noqa: E402

run, cap = Path(sys.argv[1]), sys.argv[2]
rows = list(csv.DictReader(open(run / "windows.csv")))
timing = [json.loads(l) for l in open(run / "timing.jsonl") if l.strip()]
sent = [None if x.strip() == "-" else float(x) for x in open(run / "send.log")]
frames = read_pcap_us(cap)
assert len(frames) == len(sent), (len(frames), len(sent))
pk = [s for (_t, f), s in zip(frames, sent) if s is not None and ipv4_l4_len(f) is not None]
num = lambda r, k: int(float(r.get(k) or 0))
counts = [num(r, "net_pkts_total_delta") for r in rows]
res = {"run": str(run), "windows": len(rows), "timing_lines": len(timing),
       "lost": sum(num(r, "net_window_lost") for r in rows), "unclocked": sum(num(r, "net_unclocked_pkts") for r in rows),
       "untracked": sum(num(r, "net_untracked_pkts") for r in rows),
       "rejected_markers": sum(num(r, "net_rejected_markers") for r in rows),
       "clocked_pipes": sorted({tuple(t["clocked_pipes"]) for t in timing}),
       "read_ms_max": max(t["read_ms"] for t in timing), "switch_pkts": sum(counts), "sent_counted": len(pk),
       "sent_refused": sum(1 for s in sent if s is None)}
res["all_counted"] = res["switch_pkts"] == res["sent_counted"]
ends = {t["window"]: t["t_window_end"] for t in timing}
cuts, cum = [], 0
for w, c in enumerate(counts):
    cum += c
    if 0 < cum < len(pk) and w in ends:
        cuts.append((ends[w], pk[cum - 1] - ends[w], pk[cum] - ends[w]))
first = pk[0] - (ends[0] - float(rows[0].get("net_window_duration_sec") or 0)) if pk else None
best = None
E0 = ends[0]
for ppm in range(-100, 101):
    r = ppm * 1e-6
    lo = max(b - r * (E - E0) for E, b, _a in cuts)
    hi = min(a - r * (E - E0) for E, _b, a in cuts)
    if best is None or hi - lo > best[1]:
        best = (ppm, hi - lo, lo, hi)
ppm, margin, lo, hi = best
res["cuts"] = len(cuts)
res["tick_lag_ms"] = {"rate_ppm": ppm, "d0_range_ms": [round(lo * 1e3, 3), round(hi * 1e3, 3)],
                      "fits": margin >= 0, "margin_ms": round(margin * 1e3, 3),
                      "lag_at_last_cut_ms": [round((lo + ppm * 1e-6 * (cuts[-1][0] - E0)) * 1e3, 3),
                                             round((hi + ppm * 1e-6 * (cuts[-1][0] - E0)) * 1e3, 3)] if cuts else None}
# without drift: the tightest per-cut bounds
res["tick_lag_no_drift_ms"] = [round(max(b for _E, b, _a in cuts) * 1e3, 3), round(min(a for _E, _b, a in cuts) * 1e3, 3)]
res["first_frame_after_window0_start_s"] = round(first, 4) if first is not None else None
res["timer"] = next((l.strip() for l in open(run / "collector.log") if "window timer" in l), None)
res["collector_rc"] = next((l.strip() for l in open(run / "collector.log") if l.startswith("collector rc")), None)
(run / "check.json").write_text(json.dumps(res, indent=1))
print(json.dumps(res, indent=1))
