#!/bin/bash
# hybrid_collector.py --switch-program exact --window-markers timer on basic_exact_v3_timer (as root).
#   A: a plain replay of bulk2000, --profile switch, 1 s windows, the stub host monitor (27 windows)
#   B: session_1000 under the dataset profile, 0.5 s windows, the eBPF host monitor in its cgroup (start_mono path)
# Each replay writes its send log (replay_absolute.py --send-log) for check_timer_collector.py.
set -u
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
OUT=$REPO/perf/results/exact_timer_collector_20261116
cd $REPO
COMMON="--switch-ssh root@172.168.1.2 --forward-int-port 132 --forward-ext-port 140 --cpu-iface enp5s0
  --p4-reader thesis-hybrid-ebpf-p4/python/read_registers_with_index.py
  --p4-forwarder thesis-hybrid-ebpf-p4/python/program_forwarding.py --switch-program exact --window-markers timer"
case "$1" in
A)
    D=$OUT/A_bulk2000; mkdir -p $D
    printf '#!/bin/sh\nexec sleep 86400\n' > $D/hostmon_stub; chmod +x $D/hostmon_stub
    python3 hybrid_collector.py --profile switch --mode command --scenario-name timer_bulk2000 --label test \
      --command "exec python3 $REPO/live_test/replay_absolute.py --iface eth1 --align-window 2 --anchor-offset 1.0 --window-sec 1.0 --send-log $D/send.log $REPO/live_test/captures/bulk2000.pcap" \
      --out-csv $D/windows.csv --hostmon $D/hostmon_stub --hostmon-log $D/hostmon.log $COMMON \
      --windows 27 --reader-timing-file $D/timing.jsonl > $D/collector.log 2>&1
    echo "collector rc $?" >> $D/collector.log ;;
B)
    D=$OUT/B_session1000; mkdir -p $D
    python3 hybrid_collector.py --profile dataset --mode command --scenario-name timer_session1000 --label benign \
      --hostmon ebpf_perf/build/hostmon_agg --hostmon-cgroup /sys/fs/cgroup/unified/hazim_collect \
      --hostmon-log $D/hostmon.log \
      --command "python3 $REPO/live_test/replay_absolute.py --iface eth1 --align-window 2 --anchor-offset 1.0 --window-sec 0.5 --send-log $D/send.log /dev/shm/hz_timer2/cohort-extra/session_1000.pcap" \
      --out-csv $D/windows.csv --reader-timing-file $D/timing.jsonl $COMMON > $D/collector.log 2>&1
    echo "collector rc $?" >> $D/collector.log ;;
esac
chown -R admin:admin $OUT
