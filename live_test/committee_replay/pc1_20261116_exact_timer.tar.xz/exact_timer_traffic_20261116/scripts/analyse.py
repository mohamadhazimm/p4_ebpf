#!/usr/bin/env python3
"""Check a run_timer.py run (timer windows with traffic).

    analyse.py RUN_DIR CAPTURE [--pipe0]

The switch's windows (reads.jsonl through window_features.py) against the frames this host sent (the capture in
order, less the frames the interface refused, send.log): the frames the switch counts (IPv4 TCP/UDP first
fragments) in sending order, cut where the windows' cumulative packet counts say.
 - cut points: tick k must fall between the send times of the last frame before it and the first after it. A
   tick every P s from a phase f fits all cut points if max_k(before_k - kP) <= min_k(after_k - kP); P is
   scanned around 0.5 s (this host's clock against the switch's) and the margin reported;
 - features: features/switch_model.py's windows (the unit tests' reference_windows) on the frames so cut,
   against the switch's, every non-duration feature exactly (only without pipe-0 traffic);
 - with --pipe0: all packets counted in the windows = the replay's + the ones pipe 0 counted (pktgen.json's
   window_delta), none unclocked.
Writes RUN_DIR/analysis.json.
"""
import json
import socket
import struct
import sys
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
sys.path.insert(0, str(REPO / "thesis-hybrid-ebpf-p4" / "python"))
sys.path.insert(0, str(REPO / "thesis-hybrid-ebpf-p4" / "python" / "tests"))
sys.path.insert(0, str(REPO / "live_test"))
from window_features import FEATURES, WindowFeatures  # noqa: E402
from replay_absolute import read_pcap_us  # noqa: E402
from test_exact_windows import reference_windows  # noqa: E402

HOST = "10.0.0.10"
DUR = {"net_flow_duration_mean", "net_flow_duration_max"}


def parse(frame):
    """(src, dst, proto, sport, dport, flags, total_len) of a frame the switch counts, else None."""
    if len(frame) < 34 or frame[12:14] != b"\x08\x00" or frame[14] >> 4 != 4:
        return None
    if frame[23] not in (6, 17) or struct.unpack("!H", frame[20:22])[0] & 0x1FFF:
        return None
    ihl = (frame[14] & 15) * 4
    l4 = 14 + ihl
    sp, dp = struct.unpack("!HH", frame[l4:l4 + 4])
    flags = frame[l4 + 13] if frame[23] == 6 else 0
    return (socket.inet_ntoa(frame[26:30]), socket.inet_ntoa(frame[30:34]), frame[23], sp, dp, flags,
            struct.unpack("!H", frame[16:18])[0])


def main():
    run, cap = Path(sys.argv[1]), sys.argv[2]
    pipe0 = "--pipe0" in sys.argv
    lines = [json.loads(l) for l in open(run / "reads.jsonl") if l.strip()]
    reads = [l for l in lines if "regs" in l]
    errors = [l for l in lines if "error" in l]
    wf = WindowFeatures(window_sec=0.5)
    feats = {}
    for l in reads:
        feats[l["epoch"]] = wf.add(l)
    epochs = sorted(feats)
    sent_at = [None if x.strip() == "-" else float(x) for x in open(run / "send.log")]
    frames = read_pcap_us(cap)
    assert len(frames) == len(sent_at), (len(frames), len(sent_at))
    pk = []          # (send time, parsed) of the counted frames in sending order
    for (_t, f), s in zip(frames, sent_at):
        if s is None:
            continue
        p = parse(f)
        if p is not None:
            pk.append((s, p))
    res = {"run": str(run), "reads": len(reads), "epochs": [epochs[0], epochs[-1]] if epochs else None,
           "read_errors": len(errors), "lost": sum(feats[e]["net_window_lost"] for e in epochs),
           "lost_epochs": [e for e in epochs if feats[e]["net_window_lost"]],
           "unclocked_pkts": sum(feats[e]["net_unclocked_pkts"] for e in epochs),
           "untracked_pkts": sum(feats[e]["net_untracked_pkts"] for e in epochs),
           "rejected_markers": sum(feats[e]["net_rejected_markers"] for e in epochs),
           "clocked_pipes": sorted({tuple(l["clocked_pipes"]) for l in reads}),
           "clocked_pipes_per_epoch": {str(l["epoch"]): l["clocked_pipes"] for l in reads
                                       if tuple(l["clocked_pipes"]) != tuple(reads[-1]["clocked_pipes"])},
           "read_ms_max": max(l["read_ms"] for l in reads), "sent_counted": len(pk),
           "switch_pkts": sum(feats[e]["net_pkts_total_delta"] for e in epochs)}
    last = lines[-1] if lines else {}
    res["last_line"] = {k: last.get(k) for k in ("epoch", "pipe_epochs", "clocked_pipes")}
    if pipe0:
        pg = json.loads((run / "pktgen.json").read_text())
        res["pipe0_counted"] = pg["window_delta"]["w_pkts"][0]
        res["pipe1_counted_during_pktgen"] = pg["window_delta"]["w_pkts"][1]
        res["generated"] = pg.get("generated")
        res["sink_rx_frames"] = pg.get("sink_rx_frames")
        res["totals_ok"] = res["switch_pkts"] == len(pk) + res["pipe0_counted"] and res["unclocked_pkts"] == 0
        (run / "analysis.json").write_text(json.dumps(res, indent=1))
        print(json.dumps(res, indent=1))
        return
    # cut points: window e holds frames cum[e-1] .. cum[e]-1
    counts = [int(feats[e]["net_pkts_total_delta"]) for e in epochs]
    res["counts_match_sent"] = sum(counts) == len(pk)
    window_of, i = [], 0
    for e, c in zip(epochs, counts):
        window_of += [e] * c
    cuts = []        # (tick k = start of epoch e, send time of the last frame before, of the first at/after)
    cum = 0
    for e, c in zip(epochs, counts):
        if 0 < cum < len(pk):
            cuts.append((e, pk[cum - 1][0], pk[cum][0]))
        cum += c
    best = None
    for ppm10 in range(-2000, 2001):
        P = 0.5 * (1 + ppm10 * 1e-7)
        lo = max(b - e * P for e, b, _a in cuts)
        hi = min(a_ - e * P for e, _b, a_ in cuts)
        if best is None or hi - lo > best[1]:
            best = (P, hi - lo, lo, hi)
    P, margin, lo, hi = best
    res["tick_fit"] = {"cuts": len(cuts), "period_s": P, "ppm_vs_0.5": round((P / 0.5 - 1) * 1e6, 1),
                       "margin_us": round(margin * 1e6, 1), "phase_window_us": [round(lo * 1e6, 1), round(hi * 1e6, 1)],
                       "fits": margin >= 0}
    # per tick: where in the gap it falls under the fit (midpoint of the phase window)
    f = (lo + hi) / 2
    res["tick_fit"]["tightest_gap_us"] = round(min(a_ - b for _e, b, a_ in cuts) * 1e6, 1)
    # features
    ref_in = []
    for (s, p), e in zip(pk, window_of):
        src, dst, proto, sp, dp, flags, total = p
        length = (max(total, 46) if dst == HOST else total) + 14
        ref_in.append((e, s, src, dst, proto, sp, dp, flags, length))
    ref = reference_windows(ref_in, epochs[-1] + 1)
    bad = []
    for e in epochs:
        r, g = ref[e], feats[e]
        for k in FEATURES:
            if k in DUR:
                continue
            if abs(float(r[k]) - float(g[k])) > 1e-9 * max(1.0, abs(float(r[k]))):
                bad.append((e, k, r[k], g[k]))
    res["features"] = {"windows": len(epochs), "nondur_features": len(FEATURES) - len(DUR),
                       "windows_exact": len(epochs) - len({b[0] for b in bad}), "mismatches": bad[:20],
                       "active_windows": sum(1 for e in epochs if feats[e]["net_flow_count_seen"])}
    (run / "analysis.json").write_text(json.dumps(res, indent=1))
    print(json.dumps(res, indent=1))


if __name__ == "__main__":
    main()
