#!/usr/bin/env python3
"""A second pipe on perf/variants/exact (basic_exact_v3): window markers in band from port 132 clock pipe 1 only,
while the generator of pipe 0 sends a UDP flow into pipe 0.

    run_pipe0.py OUT_DIR EXECUTION_ID [--rate-pct 0.01]

live_test/exact_replay.py replays the capture as in part 6 (reset, marker port 132, follow, replay with markers);
once its reader follows, sw_pktgen_run.py --pipe 0 --first-local-port 68 runs for 8 s (unbound: the reader owns the
program), its copies looped back into pipe 0 by the sink port. Expected: pipe 0's clock stays at 0; every one of
pipe 0's packets is reported as unclocked (the sum over the windows = pipe 0's count over the generator's run,
pktgen.json window_delta), none counted in a window, no window lost, and the capture's row as in part 6.
"""
import csv
import json
import subprocess
import sys
import tarfile
import time
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
sys.path.insert(0, str(REPO / "live_test"))
from exact_replay import remote_cmd  # noqa: E402

ASROOT = REPO / "perf" / "results" / "committee_replay" / "scripts" / "asroot.sh"
SSH = ["ssh", "-o", "BatchMode=yes", "-T", "root@172.168.1.2"]
RRES = "/root/hazim_perf/results/exact_timer_traffic_20261116"
SHM = Path("/dev/shm/hz_timer")


def main():
    out, eid = Path(sys.argv[1]), sys.argv[2]
    rate = sys.argv[sys.argv.index("--rate-pct") + 1] if "--rate-pct" in sys.argv else "0.01"
    out.mkdir(parents=True, exist_ok=True)
    caps = REPO / "live_test" / "captures"
    man = subprocess.run(["tar", "xzf", str(caps / "cohort-extra.tar.gz"), "-O", "cohort-extra/manifest.csv"],
                         check=True, capture_output=True, text=True).stdout
    row = {r["execution_id"]: r for r in csv.DictReader(man.splitlines(True))}[eid]
    cap = SHM / "cohort-extra" / row["capture"]
    if not cap.exists():
        with tarfile.open(caps / "cohort-extra.tar.gz", "r:gz") as tar:
            tar.extract("cohort-extra/" + row["capture"], str(SHM))
    drv = subprocess.Popen([sys.executable, str(REPO / "live_test" / "exact_replay.py"), str(cap), "--anchor-us",
                            row["anchor_us"], "--execution-id", eid, "--out", str(out / "replay"), "--asroot",
                            str(ASROOT)], stdout=open(out / "exact_replay.log", "w"), stderr=subprocess.STDOUT)
    t0 = time.time()
    while time.time() - t0 < 60:
        r = subprocess.run(SSH + ["ps -eo cmd | grep -c '[w]indow_reader_.*--follow'"], capture_output=True, text=True)
        if r.stdout.strip() not in ("", "0"):
            break
        time.sleep(0.3)
    t_follow = time.time()
    time.sleep(4.0)       # the replay starts 3 s after the reader; window 0 is read at the first marker
    t_gen = time.time()
    g = subprocess.run(SSH + [remote_cmd("/root/hazim_perf/tools/sw_pktgen_run.py", [
        "%s/pipe0_pktgen.json" % RRES, "--pipe", "0", "--first-local-port", "68", "--buffer-offset", "1024",
        "--rate-pct", rate, "--seconds", "8", "--warmup", "1", "--window-totals", "--client-id", "11"])],
        capture_output=True, text=True, timeout=300)
    (out / "pktgen.log").write_text(g.stdout + g.stderr)
    subprocess.run(SSH + [remote_cmd("/root/hazim_perf/tools/sw_pktgen_run.py", [
        "%s/pipe0_cleanup.json" % RRES, "--pipe", "0", "--first-local-port", "68", "--cleanup", "--client-id", "11"])],
        capture_output=True, timeout=120)
    t_gen_end = time.time()
    drv.wait(600)
    pg = json.loads(subprocess.run(SSH + ["cat %s/pipe0_pktgen.json" % RRES], capture_output=True, text=True).stdout)
    (out / "pktgen.json").write_text(json.dumps(pg, indent=1))
    lines = [json.loads(l) for l in open(out / "replay" / "reads.jsonl") if l.strip()]
    reads = [l for l in lines if "regs" in l]
    summ = json.loads((out / "replay" / "summary.json").read_text())
    res = dict(execution_id=eid, rate_pct=rate, follow_seen_s=round(t_follow - t0, 2), gen_started_s=round(t_gen - t0, 2),
               gen_ended_s=round(t_gen_end - t0, 2), reads=len(reads),
               clocked_pipes=sorted({tuple(l["clocked_pipes"]) for l in reads}),
               pipe_epochs_last=reads[-1]["pipe_epochs"],
               unclocked_sum=sum(l["unclocked_pkts"] for l in reads),
               unclocked_windows=[l["epoch"] for l in reads if l["unclocked_pkts"]],
               pipe0_counted=pg["window_delta"]["w_pkts"][0], generated=pg.get("generated"),
               sink_rx_frames=pg.get("sink_rx_frames"), pktgen_errors=pg.get("errors"),
               lost=summ.get("windows_lost"), untracked=summ.get("untracked_pkts"), pkts=summ.get("pkts"),
               exact_nodur=summ.get("exact_nodur"), mismatch_nodur=summ.get("mismatch_nodur"),
               epoch0_pkts=summ.get("epoch0_pkts"))
    res["unclocked_ok"] = res["unclocked_sum"] == res["pipe0_counted"]
    (out / "analysis.json").write_text(json.dumps(res, indent=1))
    print(json.dumps(res))


if __name__ == "__main__":
    main()
