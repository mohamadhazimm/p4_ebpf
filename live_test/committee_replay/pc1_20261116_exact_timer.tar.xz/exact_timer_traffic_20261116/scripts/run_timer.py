#!/usr/bin/env python3
"""Timer windows with traffic on perf/variants/exact (basic_exact_v3_timer, -DTIMER_LOCAL_PORT=68).

    run_timer.py OUT_DIR CAPTURE [--pipes 0,1] [--pipe0-traffic PCT] [--windows-tail 6]

The switch must run the timer build with its ports set up. Steps:
 1. window_reader.py --reset --marker-ports '' --frame-min 10.0.0.10/32 (no marker counts: the timer is the clock);
 2. window_reader.py --follow on the switch, its lines into OUT/reads.jsonl as they come;
 3. sw_window_timer.py --pipes P: each pipe's generator ticks that pipe's clock every 0.5 s;
 4. optionally (--pipe0-traffic PCT) sw_pktgen_run.py --pipe 0 --first-local-port 69: a UDP flow into pipe 0 at
    PCT % of line rate for 8 s, its copies looped back into pipe 0 by the sink port (both counted in pipe 0);
 5. live_test/replay_absolute.py (no markers) as root, --send-log: the capture's frames at their recorded times
    into port 132 (pipe 1), this host's send time of each.
Then analyse.py OUT_DIR CAPTURE.
"""
import argparse
import json
import shlex
import subprocess
import sys
import time
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
sys.path.insert(0, str(REPO / "live_test"))
from exact_replay import remote_cmd  # noqa: E402

ASROOT = REPO / "perf" / "results" / "committee_replay" / "scripts" / "asroot.sh"
SSH = ["ssh", "-o", "BatchMode=yes", "-T", "root@172.168.1.2"]
RTOOLS = "/root/hazim_perf/tools"
RREADER = "/tmp/hz_timer_window_reader.py"
RRES = "/root/hazim_perf/results/exact_timer_traffic_20261116"


def log(out, msg):
    line = "%s %s" % (time.strftime("%H:%M:%S"), msg)
    print(line, flush=True)
    with open(out / "driver.log", "a") as f:
        f.write(line + "\n")


def capture_seconds(path):
    sys.path.insert(0, str(REPO / "live_test"))
    from replay_absolute import read_pcap_us
    fr = read_pcap_us(path)
    return (fr[-1][0] - fr[0][0]) / 1e6


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("capture")
    ap.add_argument("--pipes", default="0,1")
    ap.add_argument("--pipe0-traffic", type=float, default=0.0)
    ap.add_argument("--lead-s", type=float, default=4.0)
    ap.add_argument("--tail-s", type=float, default=4.0)
    ap.add_argument("--reader-args", default="", help="extra window_reader.py --follow arguments")
    a = ap.parse_args()
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)
    tag = out.name
    subprocess.run(SSH + ["cat > %s" % RREADER], input=(REPO / "thesis-hybrid-ebpf-p4" / "python" /
                                                         "window_reader.py").read_bytes(), check=True)
    subprocess.run(SSH + ["mkdir -p %s" % RRES], check=True)
    dur = capture_seconds(a.capture)
    timer_s = a.lead_s + dur + a.tail_s + (10.0 if a.pipe0_traffic else 0.0)
    meta = dict(capture=a.capture, pipes=a.pipes, pipe0_traffic=a.pipe0_traffic, capture_s=dur, timer_s=timer_s,
                reader_args=a.reader_args, start=time.time())
    log(out, "reset (no marker ports, frame-min 10.0.0.10/32)")
    r = subprocess.run(SSH + [remote_cmd(RREADER, ["--reset", "--marker-ports", "", "--frame-min", "10.0.0.10/32"])],
                       capture_output=True, text=True, timeout=300)
    (out / "reset.log").write_text(r.stdout + r.stderr)
    if r.returncode != 0:
        raise SystemExit("reset failed")
    reads = open(out / "reads.jsonl", "w")
    until = int(2 * timer_s) - 3      # the follower ends by itself before the timer stops
    meta["until_epoch"] = until
    follow = subprocess.Popen(SSH + [remote_cmd(RREADER, ["--follow", "--until-epoch", str(until)] +
                                                shlex.split(a.reader_args))],
                              stdout=reads, stderr=open(out / "reader.log", "w"))
    t0 = time.time()
    while time.time() - t0 < 30 and not (out / "reads.jsonl").read_text().strip():
        time.sleep(0.1)
    first = (out / "reads.jsonl").read_text().splitlines()[0]
    log(out, "reader: %s" % first)
    timer = subprocess.Popen(SSH + [remote_cmd("%s/sw_window_timer.py" % RTOOLS, [
        "%s/%s_timer.json" % (RRES, tag), "--pipes", a.pipes, "--seconds", "%.1f" % timer_s, "--client-id", "12"])],
        stdout=open(out / "timer.log", "w"), stderr=subprocess.STDOUT)
    log(out, "timer started for %.1f s on pipes %s" % (timer_s, a.pipes))
    gen = None
    if a.pipe0_traffic:
        time.sleep(1.0)
        gen = subprocess.Popen(SSH + [remote_cmd("%s/sw_pktgen_run.py" % RTOOLS, [
            "%s/%s_pktgen.json" % (RRES, tag), "--pipe", "0", "--first-local-port", "69", "--buffer-offset", "1024",
            "--rate-pct", str(a.pipe0_traffic), "--seconds", "8", "--warmup", "1", "--window-totals",
            "--client-id", "11"])], stdout=open(out / "pktgen.log", "w"), stderr=subprocess.STDOUT)
        log(out, "pipe-0 generator at %.3f %% of line rate" % a.pipe0_traffic)
    start_at = time.time() + a.lead_s
    send_log = "/dev/shm/hz_timer_send_%s.log" % tag
    log(out, "replay at %.3f" % start_at)
    rp = subprocess.run([str(ASROOT), sys.executable, str(REPO / "live_test" / "replay_absolute.py"), a.capture,
                         "--iface", "eth1", "--start-at", "%.6f" % start_at, "--send-log", send_log],
                        capture_output=True, text=True, timeout=3600)
    (out / "replay.log").write_text(rp.stdout + rp.stderr)
    meta["replay"] = (rp.stdout.strip().splitlines() or [""])[-1]
    meta["start_at"] = start_at
    log(out, meta["replay"])
    subprocess.run(["cp", send_log, str(out / "send.log")], check=True)
    subprocess.run([str(ASROOT), "rm", "-f", send_log])
    if gen is not None:
        gen.wait(120)
        subprocess.run(SSH + [remote_cmd("%s/sw_pktgen_run.py" % RTOOLS, [
            "%s/%s_cleanup.json" % (RRES, tag), "--pipe", "0", "--first-local-port", "69", "--cleanup",
            "--client-id", "11"])], capture_output=True, timeout=120)
        log(out, "pipe-0 generator done, cleaned up")
    timer.wait(timer_s + 120)
    log(out, "timer done")
    time.sleep(1.5)
    follow.terminate()
    try:
        follow.wait(10)
    except subprocess.TimeoutExpired:
        follow.kill()
    reads.close()
    # a follower whose ssh went away keeps waiting for the clock: stop it by PID
    subprocess.run(SSH + ["for p in $(ps -eo pid,cmd | grep '[h]z_timer_window_reader' | awk '{print $1}'); do "
                          "kill $p; echo killed leftover reader $p; done"])
    for name in ("timer", "pktgen") if gen is not None else ("timer",):
        r = subprocess.run(SSH + ["cat %s/%s_%s.json" % (RRES, tag, name)], capture_output=True, text=True)
        (out / ("%s.json" % name)).write_text(r.stdout)
    meta["end"] = time.time()
    (out / "meta.json").write_text(json.dumps(meta, indent=1))
    log(out, "done")


if __name__ == "__main__":
    main()
