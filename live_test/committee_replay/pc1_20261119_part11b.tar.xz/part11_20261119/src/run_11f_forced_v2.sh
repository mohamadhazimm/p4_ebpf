#!/bin/bash
# PC1.md part 11F on basic_exact_block_v2, the forced run: http_poll in the collector's cgroup with the alarm forced at window 8 (threshold 2:
# no real verdict first), beside tcp_beacon looping in its own cgroup hazim_bg (part 10B's background). As root.
set -u
R=/home/admin/Desktop/hAZIM/p4_ebpf/perf/results/part11_20261119
REL=/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection
OUT=$R/11f_v2
mkdir -p /sys/fs/cgroup/unified/hazim_bg
sh -c "echo \$\$ > /sys/fs/cgroup/unified/hazim_bg/cgroup.procs; exec runuser -u admin -- sh -c 'while true; do python3 $REL/validation/hybrid/workloads.py tcp_beacon --server 192.168.0.2; done'" > $OUT/bg.log 2>&1 < /dev/null &
BG=$!
sleep 3
echo "background pid $BG, cgroup procs: $(cat /sys/fs/cgroup/unified/hazim_bg/cgroup.procs | tr '\n' ' ')"
bash $R/src/run_11f.sh $OUT poll http_poll --block-force-alarm-window 8 --block-threshold 2
echo 1 > /sys/fs/cgroup/unified/hazim_bg/cgroup.kill; sleep 1; rmdir /sys/fs/cgroup/unified/hazim_bg && echo "background stopped"
