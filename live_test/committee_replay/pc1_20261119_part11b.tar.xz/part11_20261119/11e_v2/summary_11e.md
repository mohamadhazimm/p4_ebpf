| Capture | first frame from 10.0.0.10 | alarm (dataset window, p) | alarm after its window's end | block t_request / t_reply | last frame from 10.0.0.10 through | from 10.0.0.10: sent / through / dropped (switch) | share dropped | frames to 10.0.0.10 through |
|---|---|---|---|---|---|---|---|---|
| udp_sink_60k | 0.003 s | 0, p=0.982 | 255.2 ms | 0.755 / 0.760 s (no_flow_identities) | 0.758 s | 60000 / 35250 / 24750 | 41.2% | 7 / 7 |
| syn_sink_40k | 0.004 s | 0, p=0.871 | 315.7 ms | 0.869 / 0.878 s (flood) | 0.872 s | 82332 / 34321 / 48011 | 58.3% | 42334 / 42334 |
| syn_fan_40k | 0.004 s | 0, p=0.983 | 259.9 ms | 0.760 / 0.764 s (flood) | 0.742 s | 39846 / 39846 / 0 | 0.0% | 1 / 1 |
| goldeneye_p10 | 0.184 s | 0, p=0.911 | 200.6 ms | 0.701 / 0.705 s (flood) | 0.703 s | 19674 / 12611 / 7063 | 35.9% | 17943 / 17943 |
| bulk2000 | 0.004 s | no alarm (max p=0.132 over 40 windows) | | | | 12000 / 12000 / 0 | 0% | 12000 / 12000 |
| session_1000 | 0.004 s | no alarm (max p=0.044 over 40 windows) | | | | 6000 / 6000 / 0 | 0% | 6000 / 6000 |
| dns_10k | 0.003 s | 0, p=0.700 | 366.7 ms | 0.867 / 0.875 s (no_flow_identities) | 0.869 s | 10000 / 6828 / 3172 | 31.7% | 10000 / 10000 |
