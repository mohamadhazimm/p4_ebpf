| Block table | Frame (B) | run | exact_block: % of line rate | exact v3 (16 Nov) | offered |
|---|---|---|---|---|---|
| empty | 64 | max x3 | 91.09% / 91.09% / 91.09% | 91.09% / 91.09% / 91.09% | 91% |
| empty | 128 | paced x3 | 99.88% / 99.88% / 99.88% | 99.88% / 99.88% / 99.88% | 100% |
| empty | 128 | max x1 | 100.00% | 100.00% | 111% |
| empty | 256 | paced x3 | 99.89% / 99.89% / 99.89% | 99.89% / 99.89% / 99.89% | 100% |
| empty | 256 | max x1 | 100.00% | 100.00% | 128% |
| empty | 512 | paced x3 | 99.87% / 99.87% / 99.87% | 99.87% / 99.87% / 99.87% | 100% |
| empty | 512 | max x1 | 100.00% | 100.00% | 140% |
| empty | 1024 | paced x3 | 99.89% / 99.90% / 99.89% | 99.89% / 99.89% / 99.89% | 100% |
| empty | 1024 | max x1 | 100.00% | 100.00% | 148% |
| empty | 1280 | paced x3 | 99.88% / 99.88% / 99.88% | 99.88% / 99.88% / 99.88% | 100% |
| empty | 1280 | max x1 | 100.00% | 100.00% | 149% |
| empty | 1518 | paced x3 | 99.88% / 99.88% / 99.88% | 99.89% / 99.88% / 99.88% | 100% |
| empty | 1518 | max x1 | 100.00% | 100.00% | 150% |
| 1,024 entries | 64 | max x3 | 91.09% / 91.09% / 91.09% | 91.09% / 91.09% / 91.09% | 91% |
| 1,024 entries | 1518 | paced x3 | 99.88% / 99.88% / 99.88% | 99.89% / 99.88% / 99.88% | 100% |
| 1,024 entries | 1518 | max x1 | 100.00% | 100.00% | 150% |

runs: 34; packets generated: 18016200068 (18.0 billion)
block_list_before: [{"block": "list", "blocked_pkts": 0, "entries": 0}]
block_add_1024: []
block_list_1024: [{"block": "list", "blocked_pkts": 0, "entries": 1023}]
block_list_after: [{"block": "list", "blocked_pkts": 0, "entries": 1023}]
block_clear: [{"block_cleared": true}, {"block": "list", "blocked_pkts": 0, "entries": 0}]
checks failed: 0
