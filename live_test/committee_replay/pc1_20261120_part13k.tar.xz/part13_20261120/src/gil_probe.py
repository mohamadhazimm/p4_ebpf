#!/usr/bin/env python3
"""PC1.md part 13K: does the stacked detector's scoring, in a thread, delay another thread's wake-ups?

The detector the live runs use (stacked, 0.25 s, the live benign runs added, wl-null's group held out) scores the
rows of a live run (st-null) every 250 ms, as the collector's window thread does; a clock thread wakes every 250 ms,
as the thread that sends the CPU markers, and records how late each wake-up is. Three ways: the clock alone, the
scorer in a thread of the same process, the scorer in a forked process. No switch.

    gil_probe.py RUN_CSV            (the .venv; about 2 minutes, 1 of them training)
"""
import csv
import multiprocessing as mp
import statistics
import sys
import threading
import time

REPO = "/home/admin/Desktop/hAZIM/p4_ebpf"
sys.path.insert(0, REPO)
import block_policy  # noqa: E402

score = block_policy.load_scorer("stacked", ["live::wl-null"], None, window_sec=0.25,
                                 extra_windows=[REPO + "/live_test/streaming/live_benign_windows_0.25s.csv.gz"])
rows = list(csv.DictReader(open(sys.argv[1])))
print("trained; %d rows" % len(rows), flush=True)


def busy(stop):
    """A score of the run so far every 250 ms."""
    k = 0
    while not stop.is_set():
        t = time.time()
        score(rows[: (k % len(rows)) + 1])
        k += 1
        rest = 0.25 - (time.time() - t)
        if rest > 0:
            time.sleep(rest)


def clock(n=60, period=0.25):
    late = []
    t0 = time.time() + period
    for k in range(n):
        target = t0 + k * period
        d = target - time.time()
        if d > 0:
            time.sleep(d)
        late.append((time.time() - target) * 1e3)
    return late


def report(name, late):
    s = sorted(late)
    print("%-22s wake-ups late: median %6.2f ms, p95 %6.2f ms, max %6.2f ms" % (
        name, statistics.median(s), s[int(0.95 * len(s))], s[-1]), flush=True)


t = time.time()
score(rows)
print("one score of all %d rows: %.0f ms" % (len(rows), (time.time() - t) * 1e3), flush=True)
report("alone", clock())
stop = threading.Event()
th = threading.Thread(target=busy, args=(stop,), daemon=True)
th.start()
report("scorer in a thread", clock())
stop.set()
th.join()
ctx = mp.get_context("fork")
ev = ctx.Event()
p = ctx.Process(target=busy, args=(ev,), daemon=True)
p.start()
report("scorer in a process", clock())
ev.set()
p.join()
