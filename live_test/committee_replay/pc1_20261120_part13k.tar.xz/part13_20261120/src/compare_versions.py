#!/usr/bin/env python3
"""PC1.md part 13K: the 0.25 s live runs of each collector version, side by side (from summarize_stacked.py's
summary.json in each run directory): the markers, the switch's windows, the scores' delay, the floods.
    compare_versions.py LABEL:RUN_DIR [...]"""
import json
import statistics
import sys


def main():
    for spec in sys.argv[1:]:
        label, d = spec.split(":", 1)
        s = json.load(open(d + "/summary.json"))
        runs = list(s.values())
        def agg(k, f):
            v = [r[k] for r in runs if r.get(k) is not None]
            return f(v) if v else None
        att = {i: r for i, r in s.items() if r.get("sent")}
        benign_alarms = sum(1 for i, r in s.items() if not r.get("sent") and r.get("alarm_window") is not None)
        print("%-28s %2d runs | markers late: median %s, max %s ms | switch windows: median %s, max %s ms | "
              "score after its window: median %s, max %s ms | benign alarmed %d of %d" % (
                  label, len(runs), agg("marker_late_ms_median", statistics.median), agg("marker_late_ms_max", max),
                  agg("switch_window_ms_median", statistics.median), agg("switch_window_ms_max", max),
                  agg("score_after_window_end_ms_median", statistics.median),
                  agg("score_after_window_end_ms_max", max), benign_alarms, len(runs) - len(att)))
        for i, r in sorted(att.items()):
            print("    %-14s alarm window %s, %s ms after its end; dropped %d of %d (%.1f%%); reached PC2 %d" % (
                i, r["alarm_window"], r["alarm_after_window_end_ms"], r["dropped"], r["sent"],
                100.0 * r["dropped"] / r["sent"], r["sent"] - r["dropped"]))


if __name__ == "__main__":
    main()
