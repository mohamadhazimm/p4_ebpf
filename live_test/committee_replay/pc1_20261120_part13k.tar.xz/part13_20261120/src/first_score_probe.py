#!/usr/bin/env python3
"""PC1.md part 13K: the time of the first scores of block_policy.ScorerProcess (the live runs' stacked detector at
0.25 s), against the same detector in this process. No switch.   first_score_probe.py RUN_CSV   (the .venv)"""
import csv
import sys
import time

REPO = "/home/admin/Desktop/hAZIM/p4_ebpf"
sys.path.insert(0, REPO)
import block_policy  # noqa: E402


def main():
    rows = list(csv.DictReader(open(sys.argv[1])))
    kw = dict(window_sec=0.25, extra_windows=[REPO + "/live_test/streaming/live_benign_windows_0.25s.csv.gz"])
    for process in (True, False):
        t = time.time()
        f = block_policy.load_scorer("stacked", ["live::wl-null"], None, process=process, **kw)
        print("process=%s: trained in %.1f s" % (process, time.time() - t), flush=True)
        time.sleep(3)                          # the collector starts the monitor and the program meanwhile
        ms = []
        for k in range(6):
            t = time.time()
            f(rows[: k + 1])
            ms.append(round((time.time() - t) * 1e3, 1))
        print("process=%s: the first six scores take %s ms" % (process, ms), flush=True)
        if process:
            f.close()


if __name__ == "__main__":        # ScorerProcess starts a new interpreter, which imports this file
    main()
