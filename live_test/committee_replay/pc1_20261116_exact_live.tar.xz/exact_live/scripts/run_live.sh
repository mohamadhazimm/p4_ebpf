#!/bin/bash
# PC1.md part 6c: live hybrid runs on perf/variants/exact. Each of the release's network workloads runs on PC1 in the
# collector's cgroup for the dataset profile's 40 x 0.5 s windows, with the eBPF host monitor (hostmon_agg), the
# exact build read by window_reader.py, and the window markers sent from the switch's CPU port at the collector's
# boundaries; servers.py runs on PC2 behind port 140. eth1 is captured in both directions for the packet check.
#   run_live.sh NAME [NAME ...]        (as root; the .env sudo wrapper)
set -u
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
REL=/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection
OUT=$REPO/perf/results/exact_live
cd $REPO
for NAME in "$@"; do
    tcpdump -i eth1 -s 96 -w $OUT/$NAME.eth1.pcap 2> $OUT/$NAME.tcpdump.log &
    TD=$!
    sleep 2
    python3 hybrid_collector.py --profile dataset --mode command \
        --switch-ssh root@172.168.1.2 --forward-int-port 132 --forward-ext-port 140 --cpu-iface enp5s0 \
        --p4-reader thesis-hybrid-ebpf-p4/python/read_registers_with_index.py \
        --p4-forwarder thesis-hybrid-ebpf-p4/python/program_forwarding.py \
        --switch-program exact --window-markers cpu --frame-min 192.168.0.1/32 \
        --scenario-name $NAME --label benign --hostmon ebpf_perf/build/hostmon_agg \
        --hostmon-cgroup /sys/fs/cgroup/unified/hazim_collect \
        --hostmon-log $OUT/$NAME.hostmon.log \
        --command "python3 $REL/validation/hybrid/workloads.py $NAME --server 192.168.0.2" \
        --out-csv $OUT/$NAME.csv --reader-timing-file $OUT/$NAME.timing.jsonl > $OUT/$NAME.collector.log 2>&1
    echo "collector rc $?" >> $OUT/$NAME.collector.log
    sleep 1; kill -INT $TD; wait $TD
    echo "$NAME: $(tail -1 $OUT/$NAME.collector.log); $(grep -o 'HOSTMON_HEALTH.*' $OUT/$NAME.hostmon.log | tail -1)"
done
chown -R admin:admin $OUT
