#!/usr/bin/env python3
"""PC1.md part 6c: per live run on perf/variants/exact, the switch's window totals against eth1's capture (both
directions) between the window's two markers. The markers' times come from the reader (switch clock) and are mapped
onto this host's clock by the offset from the requests' round trips (NTP method, shortest quarter); a window's
packets must lie between those surely inside it and those possibly inside it (margin: half the shortest round
trip + 2 ms). Bytes as the build counts them: IPv4 length, at least 46 toward 192.168.0.1, + 14.
    check_live.py NAME [NAME ...]"""
import bisect
import csv
import json
import socket
import statistics as st
import sys
from pathlib import Path

sys.path.insert(0, "/home/admin/Desktop/hAZIM/p4_ebpf/live_test")
from replay_capture import read_pcap, ipv4_l4_len  # noqa: E402

OUT = Path(__file__).resolve().parent.parent
PC1 = socket.inet_aton("192.168.0.1")
for name in sys.argv[1:]:
    recs = [json.loads(l) for l in open(OUT / (name + ".timing.jsonl")) if l.strip()]
    rows = list(csv.DictReader(open(OUT / (name + ".csv"))))
    samp = []
    for r in recs:
        for m in (r, r.get("marked") or {}):
            t0, t1, t2, t3 = (m.get(k) for k in ("collector_t_sent", "reader_t_recv", "reader_t_send", "collector_t_reply"))
            if None not in (t0, t1, t2, t3):
                samp.append((((t1 - t0) + (t2 - t3)) / 2, (t3 - t0) - (t2 - t1)))
    samp.sort(key=lambda x: x[1])
    best = samp[:max(3, len(samp) // 4)]
    theta, u = st.median(x[0] for x in best), best[0][1] / 2 + 0.002
    cuts = {r["marked"]["marked"]: r["marked"]["t_sent"] - theta for r in recs if r.get("marked")}
    for r in recs:
        if r.get("marked_first"):
            cuts[1] = r["marked_first"]["t_sent"] - theta
    pk = []
    for t, f in read_pcap(OUT / (name + ".eth1.pcap")):
        n = ipv4_l4_len(f)
        if n is not None:
            pk.append((t, (max(n, 46) if f[30:34] == PC1 else n) + 14))
    pk.sort()
    times = [t for t, _ in pk]
    cum = [0]
    for _, b in pk:
        cum.append(cum[-1] + b)

    def between(lo, hi):
        a, b = bisect.bisect_left(times, lo), bisect.bisect_left(times, hi)
        return b - a, cum[b] - cum[a]

    inside = checked = 0
    for w, r in enumerate(rows):
        e = w + 1
        if e not in cuts and e != 1:
            continue
        a = cuts.get(e)
        b = cuts.get(e + 1)
        if a is None or b is None:
            continue
        sw = (int(float(r["net_pkts_total_delta"])), int(float(r["net_bytes_total_delta"])))
        lo, hi = between(a + u, b - u), between(a - u, b + u)
        checked += 1
        inside += lo[0] <= sw[0] <= hi[0] and lo[1] <= sw[1] <= hi[1]
    first, last = cuts.get(1), cuts.get(41)
    tot = between(first, last) if first and last else (None, None)
    sw_p = sum(int(float(r["net_pkts_total_delta"])) for r in rows)
    sw_b = sum(int(float(r["net_bytes_total_delta"])) for r in rows)
    aligned = all(r["host_window_start_sec"] == r["net_window_start_sec"] for r in rows)
    flags = {k: sum(int(float(r[k])) for r in rows) for k in ("net_window_lost", "net_untracked_pkts",
                                                            "net_unclocked_pkts", "net_rejected_markers")}
    mk = [(r["marked"]["t_seen"] - r["marked"]["t_sent"]) * 1e3 for r in recs if r.get("marked")]
    print("%-12s %2d rows, host/net aligned %s | windows inside bounds %d/%d | packets switch %d / eth1 between "
          "markers 1 and 41 %s, bytes %d / %s | %s | marker->clock median %.1f ms | round trip %.1f ms" % (
              name, len(rows), aligned, inside, checked, sw_p, tot[0], sw_b, tot[1], flags, st.median(mk),
              2 * (u - 0.002) * 1e3))
