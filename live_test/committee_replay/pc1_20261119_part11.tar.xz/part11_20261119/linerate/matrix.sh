#!/bin/bash
# PC1.md part 11C: p4_perf 3.2's 27-run matrix on basic_exact_block (perf/variants/exact_block, -DBLOCK_DIRECT_COUNTER=0)
# with the block table empty, as linerate_exact_v3_20261116 ran it on basic_exact_v3 (--window-totals); then
# 1,024 entries that match nothing (src 203.0.0.0-203.0.3.255, dport 9; the generator's flow is 10.99.7.1 -> 10.99.7.2
# UDP 7000 -> 7001) and the 1518 B paced and max and 64 B max runs again; the entries listed (blocked_pkts must stay 0)
# and cleared.
D=/root/hazim_perf/runs/part11_20261119/linerate
mkdir -p $D && cd $D
export SDE_INSTALL=/root/bf-sde-9.6.0/install LD_LIBRARY_PATH=/usr/local/lib:/root/bf-sde-9.6.0/install/lib
T=/root/hazim_perf/tools/sw_pktgen_run.py
W=/root/hazim_perf/runs/part11_20261119/window_reader.py
run() { out=$1; shift; python2.7 $T $out --prog basic --seconds 10 --window-totals "$@" > ${out%.json}.log 2>&1; }
python2.7 $W --block-list > block_list_before.json 2> block_list_before.log
for r in 1 2 3; do run blk_64_max_r$r.json --size 64; done
for s in 128 256 512 1024 1280 1518; do
    for r in 1 2 3; do run blk_${s}_paced_r$r.json --size $s --rate-pct 99.9; done
    run blk_${s}_max.json --size $s
done
args=""
for i in $(seq 0 1023); do args="$args --block-add src=203.0.$((i/256)).$((i%256)),dport=9"; done
python2.7 $W $args > block_add_1024.json 2> block_add_1024.log
python2.7 $W --block-list > block_list_1024.json 2> block_list_1024.log
for r in 1 2 3; do run blk1024_1518_paced_r$r.json --size 1518 --rate-pct 99.9; done
run blk1024_1518_max.json --size 1518
for r in 1 2 3; do run blk1024_64_max_r$r.json --size 64; done
python2.7 $W --block-list > block_list_after.json 2> block_list_after.log
python2.7 $W --block-clear --block-list > block_clear.json 2> block_clear.log
python2.7 $T cleanup.json --prog basic --cleanup > cleanup.log 2>&1
date -u +%FT%TZ > matrix.done
