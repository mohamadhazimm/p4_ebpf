#!/usr/bin/env python3
"""PC1.md part 11C: the line-rate matrix of basic_exact_block (blk_*.json, the block table empty; blk1024_*.json, 1,024
entries that match nothing) against basic_exact_v3's of 16 November (exact_*.json of linerate_exact_v3_20261116/runs),
and the window totals' exactness as linerate_exact_v3_20261116/summarize.py checks them (no markers, so every packet
in window 0): pipe 1 (the generator's) grows by the generated packets, pipe 0 by the looped-back ones (the sink's RX),
the bytes by the packets' IPv4 length (frame - 18 B), every packet tracked (one flow); and no packet blocked.
    summarize.py DIR"""
import glob
import json
import os
import statistics as st
import sys

d = sys.argv[1]
V3 = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "linerate_exact_v3_20261116", "runs")
SIZES = [64, 128, 256, 512, 1024, 1280, 1518]
M32 = (1 << 32) - 1


def load(root, pattern):
    return [json.load(open(p)) for p in sorted(glob.glob(os.path.join(root, pattern)))]


def check(o, size, kind, name, problems):
    if o["errors"]:
        problems.append((name, "errors", o["errors"]))
    gen, tx, rx = o["generated"], o["sink_tx_frames"], o["sink_rx_frames"]
    drops = (o.get("tm_eg_delta") or {}).get("drop_count_packets")
    wd = o["window_delta"]
    checks = {
        "window pkts pipe 1 = generated": wd["w_pkts"][1] == gen & M32,
        "window pkts pipe 0 = looped back": wd["w_pkts"][0] == rx & M32,
        "window bytes = packets x IPv4 length": wd["w_bytes"] == [(p * (size - 18)) & M32 for p in wd["w_pkts"]],
        "every packet tracked": wd["w_tracked"] == wd["w_pkts"],
        "tx = rx": tx == rx,
        "lossless or drops = excess": (drops == 0 and gen == tx) if kind == "paced" or size == 64
                                      else (drops == gen - tx),
    }
    for k, ok in checks.items():
        if not ok:
            problems.append((name, k, {"generated": gen, "tx": tx, "rx": rx, "drops": drops, "window": wd}))
    return gen


rows, problems, total_pkts = [], [], 0
for prefix, label in (("blk", "empty"), ("blk1024", "1,024 entries")):
    for size in SIZES:
        kinds = [("max", "%s_64_max_r*.json" % prefix, "exact_64_max_r*.json")] if size == 64 else [
            ("paced", "%s_%d_paced_r*.json" % (prefix, size), "exact_%d_paced_r*.json" % size),
            ("max", "%s_%d_max.json" % (prefix, size), "exact_%d_max.json" % size)]
        for kind, gp, vp in kinds:
            g, v = load(d, gp), load(V3, vp)
            if not g:
                continue
            for o in g:
                total_pkts += check(o, size, kind, "%s %d %s" % (label, size, kind), problems)
            rows.append((label, size, kind, len(g), [o["pct_of_line_rate"] for o in g],
                         [o["pct_of_line_rate"] for o in v],
                         st.mean(100.0 * o["gen_mpps"] / o["line_rate_mpps"] for o in g)))

print("| Block table | Frame (B) | run | exact_block: % of line rate | exact v3 (16 Nov) | offered |")
print("|---|---|---|---|---|---|")
for label, size, kind, n, gp_, vp_, offered in rows:
    print("| %s | %d | %s x%d | %s | %s | %.0f%% |" % (label, size, kind, n, " / ".join("%.2f%%" % x for x in gp_),
                                                       " / ".join("%.2f%%" % x for x in vp_), offered))
print()
print("runs: %d; packets generated: %d (%.1f billion)" % (sum(r[3] for r in rows), total_pkts, total_pkts / 1e9))
for name in ("block_list_before", "block_add_1024", "block_list_1024", "block_list_after", "block_clear"):
    p = os.path.join(d, name + ".json")
    if os.path.exists(p):
        lines = [json.loads(l) for l in open(p) if l.strip().startswith("{")]
        brief = [{k: (len(v) if k == "entries" else v) for k, v in l.items()} for l in lines]
        print("%s: %s" % (name, json.dumps(brief, sort_keys=True)))
print("checks failed: %d" % len(problems))
for p in problems[:20]:
    print("  ", p)
