| Capture | first frame from 10.0.0.10 | alarm (dataset window, p) | alarm after its window's end | block t_request / t_reply | last frame from 10.0.0.10 through | from 10.0.0.10: sent / through / dropped (switch) | share dropped | frames to 10.0.0.10 through |
|---|---|---|---|---|---|---|---|---|
| udp_sink_60k | 0.003 s | 0, p=0.982 | 282.3 ms | 0.782 / 0.786 s (no_flow_identities) | 0.784 s | 60000 / 36657 / 23343 | 38.9% | 7 / 7 |
| syn_sink_40k | 0.004 s | 0, p=0.871 | 299.0 ms | 0.839 / 0.842 s (flood) | 0.841 s | 82332 / 37153 / 45179 | 54.9% | 42334 / 42334 |
| syn_fan_40k | 0.004 s | 0, p=0.983 | 260.8 ms | 0.761 / 0.764 s (flood) | 0.727 s | 39846 / 39846 / 0 | 0.0% | 1 / 1 |
| goldeneye_p10 | 0.184 s | 0, p=0.911 | 212.2 ms | 0.712 / 0.718 s (flood) | 0.711 s | 19674 / 12615 / 7059 | 35.9% | 17943 / 17943 |
| bulk2000 | 0.004 s | no alarm (max p=0.132 over 40 windows) | | | | 12000 / 12000 / 0 | 0% | 12000 / 12000 |
| session_1000 | 0.004 s | no alarm (max p=0.044 over 40 windows) | | | | 6000 / 6000 / 0 | 0% | 6000 / 6000 |
| dns_10k | 0.003 s | 0, p=0.700 | 305.4 ms | 0.805 / 0.809 s (no_flow_identities) | 0.807 s | 10000 / 6354 / 3646 | 36.5% | 10000 / 10000 |
