#!/bin/bash
# PC1.md part 11C: ASIC latency of the exact build with the block table (basic_hwl_exact_block, -DBLOCK_DIRECT_COUNTER=0)
# against basic_hwl_exact_v3 and the baseline of the same day, with p4_perf.md section 4.1's method as part 6b and 9
# ran it: the HWL1 instrumentation (perf/variants/hwl, make_hwl_exact.sh), hairpin PC1 -> 1/0 -> switch -> 1/0 -> PC1,
# reference_evaluation/P4_Code/scripts/send_probes.py (1010 probes, 100 pkt/s) and collect_reports.py --pcap
# (10 warm-up probes excluded), 3 runs per program. Extra builds can be given as BUILD arguments (prog basic).
# At the end the switch runs basic_exact_block again (forwarding 132 <-> 140, enp5s0 up).
#   hwl_runs.sh ASROOT OUT_DIR [BUILD ...]
set -u
ASROOT=$1; OUT=$2; shift 2
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
SC=$REPO/reference_evaluation/P4_Code/scripts
T=/root/hazim_perf/tools/sw_switchd.sh
LOGD=/root/hazim_perf/runs/part11_20261119
sw() { ssh -o BatchMode=yes root@172.168.1.2 "$@"; }
mkdir -p "$OUT"
specs="baseline_hwl_nonewconn:baseline_hwl:baseline_hwl.conf basic_hwl_exact_v3:basic:basic.conf basic_hwl_exact_block:basic:basic.conf"
for b in "$@"; do specs="$specs $b:basic:basic.conf"; done
for spec in $specs; do
    IFS=: read -r build prog conf <<< "$spec"
    echo "== $build ($(date +%T))"
    sw "bash $T stop; bash $T start /root/hazim_perf/build/$build/$conf $LOGD && bash $T ready 180" 2>&1 \
        | grep -E 'stopped|listeners up|SAFETY|ready|exited|timeout|refusing'
    "$REPO/perf/tools/run_bfrt.sh" "$OUT/setup_$build" setup setup --prog "$prog" --ports 132,140 --fwd 132:132 \
        --mirror-sid 1 2>&1 | grep -E 'setup\] (added|forwarding|mirror)|refusing|failed'
    for r in 1 2 3; do
        d=$OUT/${build}_hairpin_r$r
        mkdir -p "$d"
        "$ASROOT" timeout -s INT 25 tcpdump -i eth1 -Q in -c 1010 -s 256 -w "$d/capture.pcap" ether proto 0x88bc \
            > "$d/tcpdump.log" 2>&1 &
        cap=$!
        sleep 2
        (cd "$d" && "$ASROOT" python3 "$SC/send_probes.py" --iface eth1 --dst-mac 02:00:00:00:00:02 --count 1010 \
            --rate 100 --log "$d/sent_probes.jsonl") > "$d/send.log" 2>&1
        wait "$cap"
        python3 "$SC/collect_reports.py" --pcap "$d/capture.pcap" --out "$d/result" --expected-count 1010 \
            --warmup 10 > "$d/collect.log" 2>&1
        python3 -c "
import json, sys
s = json.load(open('$d/result/summary.json'))
print('  r$r: reports %s, missing %s, malformed %s; min %s median %s mean %s p99 %s max %s ns' % (s['unique_reports'],
      s['missing_reports'], s['capture_counts']['malformed_reports'], s['min_ns'], s['median_ns'], s['mean_ns'],
      s['p99_ns'], s['max_ns']))" 2>&1 || tail -3 "$d/collect.log"
    done
done
echo "== restore basic_exact_block ($(date +%T))"
sw "bash $T stop; bash $T start /root/hazim_perf/build/basic_exact_block/basic.conf $LOGD && bash $T ready 180" 2>&1 \
    | grep -E 'stopped|listeners up|SAFETY|ready|exited|timeout'
"$REPO/perf/tools/run_bfrt.sh" "$OUT/setup_basic_exact_block_restored" setup setup --prog basic --ports 132,140 \
    --fwd 132:140,140:132 --mirror-sid 1 2>&1 | grep -E 'setup\] (added|forwarding|mirror)|refusing|failed'
sw "ip link set enp5s0 up; sleep 5; pgrep -a -x bf_switchd | cut -c1-140; ip -br link show enp5s0"
echo "== done ($(date +%T))"
