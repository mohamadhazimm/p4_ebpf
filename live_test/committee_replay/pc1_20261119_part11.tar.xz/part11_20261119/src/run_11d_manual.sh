#!/bin/bash
# PC1.md part 11D, the check by hand: while a replay runs (the collector's window_reader.py --serve owns the program),
# window_reader.py --block-add src=10.0.0.10 from a second client on the switch, once the collector has scored window 12.
# The collector's own (forced) block comes at window 30 and finds the entry there.
set -u
R=/home/admin/Desktop/hAZIM/p4_ebpf/perf/results/part11_20261119
D=$1
$R/src/run_block_replay.sh $D /dev/shm/hz_p11/bulk2000.pcap -0.00359 --block-detector network --block-host 10.0.0.10 \
    --block-force-alarm-window 30 --block-skip-windows 4 --block-threshold 2 > $D.console 2>&1 &
RP=$!
for i in $(seq 1 600); do
    grep -q '"event": "score".*"window": 12[,}]' $D/windows.block.jsonl 2>/dev/null && break
    sleep 0.05
done
t0=$(date +%s.%N)
ssh -o BatchMode=yes root@172.168.1.2 "CLIENT_ID=${CLIENT_ID:-9}; "'cd /root/hazim_perf/runs/part11_20261119 && export SDE_INSTALL=/root/bf-sde-9.6.0/install LD_LIBRARY_PATH=/usr/local/lib:/root/bf-sde-9.6.0/install/lib && python2.7 window_reader.py --client-id ${CLIENT_ID:-9} --block-add src=10.0.0.10' > $D.manual_add.out 2> $D.manual_add.err
rc=$?
t1=$(date +%s.%N)
echo "{\"manual_add_rc\": $rc, \"t_before_ssh\": $t0, \"t_after_ssh\": $t1}" > $D.manual_add.json
wait $RP
cat $D.console
