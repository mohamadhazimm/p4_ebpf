#!/bin/bash
# PC1.md part 11D/11E: one replay through basic_exact_block (perf/variants/exact_block, -DBLOCK_DIRECT_COUNTER=0) with
# hybrid_collector.py --block-on-alarm. The switch forwards 132 -> 132 (a hairpin, set before), so every frame the
# switch lets through comes back to eth1, where tcpdump -Q in records it (rx.pcap): it stands for a capture on PC2,
# which needs root there (PC2's dumpcap is root:wireshark 0754 and sudo asks for a password). replay_capture.py runs
# under the dataset construction's .venv (Python 3.11, scikit-learn 1.9.1: the detectors are trained in the
# collector), --align-window 4 as part 6b, with the send log; the collector without its forwarding step.
#   run_block_replay.sh OUT_DIR CAPTURE ANCHOR_OFFSET_S [hybrid_collector.py options ...]
set -u
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
ASROOT=/tmp/claude-1000/-home-admin-Desktop-hAZIM/dd29711f-6d0a-47d6-8c92-d2a98cd93247/scratchpad/asroot.sh
V=/home/admin/Desktop/hAZIM/p4_ebpf-dataset-construction/.venv/bin/python
OUT=$1; CAP=$2; OFF=$3; shift 3
if [ -e "$OUT/windows.csv" ]; then echo "$OUT already holds a run" >&2; exit 1; fi
mkdir -p "$OUT"
"$ASROOT" tcpdump -i eth1 -Q in -s 128 -B 65536 -w "$OUT/rx.pcap" ip > "$OUT/rx.tcpdump.log" 2>&1 &
sleep 2
cd "$REPO"
"$ASROOT" "$V" live_test/replay_capture.py "$CAP" --exact --profile dataset --anchor-offset "$OFF" --align-window 4 \
    --send-log --out "$OUT" -- --skip-p4-forwarding --block-on-alarm "$@" > "$OUT/replay_capture.console" 2>&1
rc=$?
sleep 1
"$ASROOT" pkill -INT -f "^tcpdump -i eth1 -Q in -s 128 -B 65536 -w $OUT/rx.pcap"
wait
"$ASROOT" chown -R admin:admin "$OUT"
echo "replay_capture rc $rc; $(grep -c . "$OUT/send_log.txt" 2>/dev/null) frames in the send log; $(tail -2 "$OUT/rx.tcpdump.log" | tr '\n' ' ')"
grep -E '^\[BLOCK\]|^\[INFO\] block rules' "$OUT/collector.log" | head -12
