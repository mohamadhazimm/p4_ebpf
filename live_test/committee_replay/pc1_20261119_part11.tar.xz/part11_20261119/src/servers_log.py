#!/usr/bin/env python3
"""The release's validation/hybrid/servers.py (same files, ports and replies), plus a log on stdout of what reached
this host: one line per accepted connection (the TCP handshake completed here), per HTTP request and per finished echo
session, with this host's clock. PC1.md part 11F runs it on PC2 in place of a capture there (a capture needs root on
PC2): a connection the switch blocks from its first packet is never accepted, and one blocked later stops sending.

    servers_log.py --bind 192.168.0.2 --www DIR [--http-port 8089] [--echo-port 9100]

ACCEPT t port client_ip client_port | HTTP t client_ip client_port "request line" status | ECHO_END t client_ip
client_port lines reason
"""
import argparse
import functools
import http.server
import os
import socketserver
import sys
import threading
import time

LOCK = threading.Lock()


def say(*fields):
    with LOCK:
        sys.stdout.write(" ".join(str(f) for f in fields) + "\n")
        sys.stdout.flush()


class QuietHandler(http.server.SimpleHTTPRequestHandler):
    def log_message(self, format, *args):
        pass

    def log_request(self, code="-", size="-"):
        say("HTTP", "%.6f" % time.time(), self.client_address[0], self.client_address[1],
            '"%s"' % self.requestline.replace('"', "'"), code)


class EchoHandler(socketserver.StreamRequestHandler):
    def handle(self):
        self.request.settimeout(30.0)
        lines, reason = 0, "closed"
        try:
            for line in self.rfile:
                self.wfile.write(line)
                lines += 1
        except OSError as error:
            reason = type(error).__name__
        say("ECHO_END", "%.6f" % time.time(), self.client_address[0], self.client_address[1], lines, reason)


class LogAccept:
    def get_request(self):
        conn, addr = super().get_request()
        say("ACCEPT", "%.6f" % time.time(), self.server_address[1], addr[0], addr[1])
        return conn, addr


class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class LogEchoServer(LogAccept, ThreadingTCPServer):
    pass


class LogHTTPServer(LogAccept, http.server.ThreadingHTTPServer):
    allow_reuse_address = True


def make_files(www):
    os.makedirs(www, exist_ok=True)
    files = {"small.html": b"<html><body>ok</body></html>\n", "page_4k.html": b"x" * 4096,
             "bulk_100k.bin": bytes(range(256)) * 400}
    for name, data in files.items():
        path = os.path.join(www, name)
        if not os.path.exists(path):
            with open(path, "wb") as f:
                f.write(data)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--bind", required=True)
    ap.add_argument("--www", required=True)
    ap.add_argument("--http-port", type=int, default=8089)
    ap.add_argument("--echo-port", type=int, default=9100)
    args = ap.parse_args()
    make_files(args.www)
    httpd = LogHTTPServer((args.bind, args.http_port), functools.partial(QuietHandler, directory=args.www))
    echo = LogEchoServer((args.bind, args.echo_port), EchoHandler)
    threading.Thread(target=httpd.serve_forever, daemon=True).start()
    print("SERVERS_READY http=%s:%d echo=%s:%d" % (args.bind, args.http_port, args.bind, args.echo_port), flush=True)
    echo.serve_forever()


if __name__ == "__main__":
    main()
