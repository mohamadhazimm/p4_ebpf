#!/usr/bin/env python3
"""PC1.md part 6 / p4_perf 5.7: the 109 captures on perf/variants/exact (runs/, live_test/exact_replay.py) against
basic_fix (replay_rows_v3.csv) and basic_gtot_ba (replay_rows_gtot_ba.csv), all against the published rows. Groups as
in part 4e (calm, bulkup_200/400, overloaded on basic_fix). Columns: the 95 total-based, the 50 per-flow (of which 10
are durations: the switch's clock), all 145, and the 135 without durations. Writes exact_compare.csv and
replay_rows_exact.csv (the rows of runs/*/row.csv in replay_rows_v3.csv's order).

    compare_exact.py [-v]"""
import csv
import json
import statistics as st
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
CR = HERE.parent / "committee_replay"
DATASET = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection/dataset/features.csv")
TOTAL_FEATURES = ["net_pkts_total_delta", "net_bytes_total_delta", "net_pkts_ab_delta", "net_bytes_ab_delta",
                  "net_pkts_ba_delta", "net_bytes_ba_delta", "net_avg_pkt_size_delta", "net_avg_pkt_size_ab_delta",
                  "net_avg_pkt_size_ba_delta", "net_bytes_per_sec_delta", "net_pkts_per_sec_delta",
                  "net_down_up_ratio_delta", "net_ab_ratio_pkt_delta", "net_ba_ratio_pkt_delta",
                  "net_ab_ratio_byte_delta", "net_ba_ratio_byte_delta", "net_syn_delta", "net_ack_delta", "net_rst_delta"]
AGGS = ["mean", "max", "sum", "std", "active_windows"]
TOTAL_COLS = ["%s__%s" % (f, a) for f in TOTAL_FEATURES for a in AGGS]

published = {r["execution_id"]: r for r in csv.DictReader(open(DATASET))}
v3_list = list(csv.DictReader(open(CR / "replay_rows_v3.csv")))
NET_COLS = [c for c in v3_list[0] if c.startswith("net_")]
FLOW_COLS = [c for c in NET_COLS if c not in TOTAL_COLS]
NODUR_COLS = [c for c in NET_COLS if "duration" not in c]
assert len(NET_COLS) == 145 and len(TOTAL_COLS) == 95 and len(FLOW_COLS) == 50 and len(NODUR_COLS) == 135
ROWS = {"bf": {r["execution_id"]: r for r in v3_list},
        "ba": {r["execution_id"]: r for r in csv.DictReader(open(CR / "replay_rows_gtot_ba.csv"))}, "ex": {}}
progress = {}
for line in open(HERE / "runs" / "progress.jsonl"):
    r = json.loads(line)
    progress[r["execution_id"]] = r
    p = HERE / "runs" / r["execution_id"] / "row.csv"
    if p.exists():
        ROWS["ex"][r["execution_id"]] = next(csv.DictReader(open(p)))
GROUP = {r["execution_id"]: r for r in csv.DictReader(open(CR / "gtot_ba_all_compare.csv"))}
BUILDS = ("bf", "ba", "ex")


def exact_count(row, ref, cols):
    return sum(abs(float(row[c]) - float(ref[c])) <= 1e-9 * max(1.0, abs(float(row[c])), abs(float(ref[c])))
               for c in cols)


out = []
for eid in [r["execution_id"] for r in v3_list]:
    if eid not in ROWS["ex"]:
        continue
    pub, pr = published[eid], progress[eid]
    row = dict(execution_id=eid, pkts=pr.get("pkts"), untracked=pr.get("untracked_pkts"),
               lost=pr.get("windows_lost"), epoch0=pr.get("epoch0_pkts"), read_ms_max=pr.get("read_ms_max"),
               replay=pr.get("replay", "")[19:])
    for b in BUILDS:
        for name, cols in (("95", TOTAL_COLS), ("50", FLOW_COLS), ("145", NET_COLS), ("135", NODUR_COLS)):
            row["exact%s_%s" % (name, b)] = exact_count(ROWS[b][eid], pub, cols)
    out.append(row)

with open(HERE / "exact_compare.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(out[0]))
    w.writeheader()
    w.writerows(out)
with open(HERE / "replay_rows_exact.csv", "w", newline="") as fh:
    w = csv.DictWriter(fh, fieldnames=list(v3_list[0]))
    w.writeheader()
    for r in v3_list:
        if r["execution_id"] in ROWS["ex"]:
            # the v3 row's other columns (identifiers, host features) with the exact run's 145 network columns
            ex = ROWS["ex"][r["execution_id"]]
            w.writerow(dict({k: v for k, v in r.items() if not k.startswith("net_")}, **{k: ex[k] for k in NET_COLS}))
print("wrote exact_compare.csv and replay_rows_exact.csv (%d captures)" % len(out))

bulk = [r for r in out if r["execution_id"].startswith("bulkup")]
ovl = [r for r in out if int(GROUP[r["execution_id"]]["overload_bf"]) > 0]
calm = [r for r in out if r not in bulk and r not in ovl]
for name, grp in (("calm (no overloaded window on basic_fix)", calm), ("bulkup_200/400 (frames over the MTU)", bulk),
                  ("overloaded on basic_fix", ovl), ("all", out)):
    if not grp:
        continue
    print("\n== %s: %d captures" % (name, len(grp)))
    print("%-34s %12s %12s %12s" % ("", "basic_fix", "gtot_ba", "exact"))
    for n, total in (("95", 95), ("50", 50), ("145", 145), ("135", 135)):
        print("%-34s" % ("%s cols exact: mean" % n) + "".join(
            "%12.1f" % st.mean(r["exact%s_%s" % (n, b)] for r in grp) for b in BUILDS))
        print("%-34s" % ("%s cols: rows all equal" % n) + "".join(
            "%12d" % sum(r["exact%s_%s" % (n, b)] == total for r in grp) for b in BUILDS))
    print("%-34s %36s" % ("untracked packets / lost windows", "%d / %d" % (sum(r["untracked"] or 0 for r in grp),
                                                                     sum(r["lost"] or 0 for r in grp))))
if "-v" in sys.argv:
    print()
    for r in out:
        if r["exact135_ex"] != 135:
            print("%-22s pkts %7s untracked %6s | 135 exact bf %3d ba %3d ex %3d | %s" % (
                r["execution_id"][:22], r["pkts"], r["untracked"], r["exact135_bf"], r["exact135_ba"],
                r["exact135_ex"], progress[r["execution_id"]].get("mismatch")))
