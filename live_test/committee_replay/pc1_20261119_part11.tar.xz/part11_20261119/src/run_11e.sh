#!/bin/bash
# PC1.md part 11E: time to containment with real verdicts on replays. Each capture through basic_exact_block with the
# network detector trained without the capture's own group (cv_group), --block-skip-windows 4 (the replay's collector
# windows 0-3 come before the run's first: --align-window 4), a host block on 10.0.0.10 (no --block-host-port).
#   run_11e.sh OUT_DIR [NAME ...]
set -u
R=/home/admin/Desktop/hAZIM/p4_ebpf/perf/results/part11_20261119
OUT=$1; shift
declare -A OFF=([udp_sink_60k]=-0.003111 [syn_sink_40k]=-0.003678 [syn_fan_40k]=-0.004328 [goldeneye_p10]=-0.183829
                [bulk2000]=-0.00359 [session_1000]=-0.003934 [dns_10k]=-0.003482)
declare -A GRP=([udp_sink_60k]=flood_udp_sink_60k [syn_sink_40k]=flood_syn_sink_40k [syn_fan_40k]=flood_syn_fan_40k
                [goldeneye_p10]=flood_goldeneye_p10 [bulk2000]=netb_bulkup [session_1000]=netb_session [dns_10k]=netb_dns)
names=("$@")
[ ${#names[@]} -eq 0 ] && names=(udp_sink_60k syn_sink_40k syn_fan_40k goldeneye_p10 bulk2000 session_1000 dns_10k)
for n in "${names[@]}"; do
    echo "== $n ($(date +%T))"
    $R/src/run_block_replay.sh $OUT/$n /dev/shm/hz_p11/$n.pcap ${OFF[$n]} --block-detector network --block-host 10.0.0.10 \
        --block-hold-out-group ${GRP[$n]} --block-skip-windows 4
    /usr/bin/python3 $R/src/block_check.py $OUT/$n /dev/shm/hz_p11/$n.pcap --json $OUT/$n/block_check.json > /dev/null
done
