#!/usr/bin/env python3
"""PC2's clock against PC1's from servers_log.py's own log: N connections to PC2's HTTP port from PC1, each
connect() timed on PC1; their ACCEPT lines (PC2's clock) matched by client port. accept - connect-return is the
offset plus the ACK's way and the accept wake-up (well under a millisecond on the direct link).
    pc2_clock.py probe OUT.json [N]    then, after fetching the log:   pc2_clock.py match OUT.json SERVER_LOG"""
import json
import socket
import sys
import time

if sys.argv[1] == "probe":
    out = []
    for _ in range(int(sys.argv[3]) if len(sys.argv) > 3 else 10):
        t0 = time.time()
        s = socket.create_connection(("192.168.0.2", 8089), timeout=5)
        t1 = time.time()
        port = s.getsockname()[1]
        s.sendall(b"GET /small.html HTTP/1.0\r\n\r\n")
        while s.recv(4096):
            pass
        s.close()
        out.append({"port": port, "t_connect": t0, "t_connected": t1})
        time.sleep(0.1)
    json.dump(out, open(sys.argv[2], "w"), indent=1)
else:
    probes = json.load(open(sys.argv[2]))
    acc = {}
    for line in open(sys.argv[3]):
        f = line.split()
        if f and f[0] == "ACCEPT" and f[3] == "192.168.0.1":
            acc[int(f[4])] = float(f[1])
    offs = [acc[p["port"]] - p["t_connected"] for p in probes if p["port"] in acc]
    rtts = [(p["t_connected"] - p["t_connect"]) * 1e3 for p in probes]
    print(json.dumps({"matched": len(offs), "offset_pc2_minus_pc1_ms": sorted(round(o * 1e3, 3) for o in offs),
                      "median_ms": round(sorted(offs)[len(offs) // 2] * 1e3, 3) if offs else None,
                      "connect_ms": [round(r, 3) for r in rtts]}))
