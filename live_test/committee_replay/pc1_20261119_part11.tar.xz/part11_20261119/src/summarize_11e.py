#!/usr/bin/env python3
"""PC1.md part 11E: time to containment per replay (run_11e.sh), from each run's block_check.json, summary.json,
windows.block.jsonl and send log. Times are seconds from the run's anchor (the start of dataset window 0 = collector
window 4) on PC1's clock.
    summarize_11e.py DIR [NAME ...]  -> table on stdout, DIR/summary_11e.json"""
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import block_check as bc  # noqa: E402

SKIP = 4
d = Path(sys.argv[1])
names = sys.argv[2:] or ["udp_sink_60k", "syn_sink_40k", "syn_fan_40k", "goldeneye_p10", "bulk2000", "session_1000",
                         "dns_10k"]
out = []
print("| Capture | first frame from 10.0.0.10 | alarm (dataset window, p) | alarm after its window's end | block "
      "t_request / t_reply | last frame from 10.0.0.10 through | from 10.0.0.10: sent / through / dropped (switch) | "
      "share dropped | frames to 10.0.0.10 through |")
print("|---|---|---|---|---|---|---|---|---|")
for n in names:
    run = d / n
    if not (run / "block_check.json").exists():
        continue
    s = json.loads((run / "summary.json").read_text())
    c = json.loads((run / "block_check.json").read_text())
    ev = [json.loads(l) for l in open(run / "windows.block.jsonl")]
    scores = [e for e in ev if e.get("event") == "score"]
    # the switch's windows are the markers' (sent in order with the frames, the replayer's late start shifts them all):
    # marker k starts collector window k and carries epoch k + 1 (replay_absolute.py --markers)
    marks = {}
    for t, f in bc.read_pcap(str(run / "tx.pcap")):
        if len(f) >= 20 and f[12:16] == b"\x88\xb5\x57\x45":
            marks.setdefault(int.from_bytes(f[16:20], "big"), t)
    anchor = marks.get(SKIP + 1, s["anchor_on_this_clock"])
    window_end = lambda w: marks.get(w + 2, anchor + (w + 1 - SKIP) * s["window_sec"])
    pcap = "/dev/shm/hz_p11/%s.pcap" % n
    frames = bc.read_pcap(pcap)
    sent = [l.strip() for l in open(run / "send_log.txt")]
    host_sent = [float(t) for (ct, f), t in zip(frames, sent) if t != "-" and bc.ipv4(f) and bc.ipv4(f)[0] == "10.0.0.10"]
    first = host_sent[0] - anchor if host_sent else None
    fh, th = c["frames"]["from_host"], c["frames"]["to_host"]
    rec = {"capture": n, "first_host_frame_s": first, "anchor_marker_minus_reported_ms":
           round((anchor - s["anchor_on_this_clock"]) * 1e3, 3), "markers_seen": len(marks), "host_sent": fh["sent"], "host_through": fh["received"],
           "blocked_pkts": c["blocked_pkts"], "to_host_sent": th["sent"], "to_host_through": th["received"],
           "max_p": max((e["probability"] for e in scores), default=None), "windows_scored": len(scores)}
    a = c["alarm"]
    if a:
        w = a["window"]
        b = c["blocks"][0]
        rec.update(alarm_dataset_window=w - SKIP, alarm_p=a["probability"],
                   alarm_after_window_end_ms=round((a["time"] - window_end(w)) * 1e3, 1),
                   t_request_s=round(b["t_request"] - anchor, 4), t_reply_s=round(b["t_reply"] - anchor, 4),
                   block_reason=b["reason"], entries=b["entries"],
                   last_host_through_s=(round(fh["last_received_send_time"] - anchor, 4)
                                        if fh.get("last_received_send_time") else None),
                   share_dropped=round((c["blocked_pkts"] or 0) / fh["sent"], 4) if fh["sent"] else None)
    out.append(rec)
    if a:
        print("| %s | %.3f s | %d, p=%.3f | %.1f ms | %.3f / %.3f s (%s) | %s | %d / %d / %d | %.1f%% | %d / %d |" % (
            n, first, rec["alarm_dataset_window"], rec["alarm_p"], rec["alarm_after_window_end_ms"], rec["t_request_s"],
            rec["t_reply_s"], rec["block_reason"],
            "%.3f s" % rec["last_host_through_s"] if rec["last_host_through_s"] is not None else "none",
            fh["sent"], fh["received"], c["blocked_pkts"] or 0, 100 * rec["share_dropped"], th["received"], th["sent"]))
    else:
        print("| %s | %.3f s | no alarm (max p=%.3f over %d windows) | | | | %d / %d / 0 | 0%% | %d / %d |" % (
            n, first, rec["max_p"], rec["windows_scored"], fh["sent"], fh["received"], th["received"], th["sent"]))
(d / "summary_11e.json").write_text(json.dumps(out, indent=1) + "\n")
