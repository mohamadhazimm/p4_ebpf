#!/bin/bash
# PC1.md part 11F, second half: the seven workloads of section 2b with --block-on-alarm and the real (stacked) verdict,
# no forced alarm, no background program (section 2b's and part 6c's conditions). As root.
set -u
R=/home/admin/Desktop/hAZIM/p4_ebpf/perf/results/part11_20261119
for wl in fanout http_poll http_bulk tcp_beacon interactive threaded mixed; do
    echo "== $wl ($(date +%T))"
    bash $R/src/run_11f.sh $R/11f/seven $wl $wl
done
