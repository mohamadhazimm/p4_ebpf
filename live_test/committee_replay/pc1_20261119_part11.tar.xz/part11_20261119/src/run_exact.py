#!/usr/bin/env python3
"""Replay the dataset captures through perf/variants/exact (live_test/exact_replay.py), resumably.

    run_exact.py OUT_DIR [--only ID,ID] [--skip ID,ID]

Order: the cohort captures (manifest order), then the extras (calm, then overload), as in part 4.
An extra is extracted to /dev/shm for its run and removed afterwards. Each run's summary line goes to
OUT_DIR/progress.jsonl; a capture already there is skipped.
"""
import csv
import json
import subprocess
import sys
import tarfile
import time
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
CAPS = REPO / "live_test" / "captures"
ASROOT = REPO / "perf" / "results" / "committee_replay" / "scripts" / "asroot.sh"
SHM = Path("/dev/shm/hz_exact")


def log(out, msg):
    line = "%s %s" % (time.strftime("%H:%M:%S"), msg)
    print(line, flush=True)
    with open(out / "driver.log", "a") as f:
        f.write(line + "\n")


def main():
    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    opts = dict(zip(sys.argv[2::2], sys.argv[3::2]))
    only = set(opts.get("--only", "").split(",")) - {""}
    skip = set(opts.get("--skip", "").split(",")) - {""}
    done = set()
    if (out / "progress.jsonl").exists():
        done = {json.loads(l)["execution_id"] for l in open(out / "progress.jsonl") if l.strip()}
    items = [dict(eid=r["execution_id"], anchor=r["anchor_us"], path=CAPS / "cohort" / r["capture"], member=None)
             for r in csv.DictReader(open(CAPS / "cohort" / "manifest.csv"))]
    man = subprocess.run(["tar", "xzf", str(CAPS / "cohort-extra.tar.gz"), "-O", "cohort-extra/manifest.csv"],
                         check=True, capture_output=True, text=True).stdout
    extra = list(csv.DictReader(man.splitlines(True)))
    extra = [r for r in extra if r["expect_overload"] == "0"] + [r for r in extra if r["expect_overload"] == "1"]
    items += [dict(eid=r["execution_id"], anchor=r["anchor_us"], path=SHM / r["capture"],
                   member="cohort-extra/" + r["capture"]) for r in extra]
    todo = [it for it in items if it["eid"] not in done and it["eid"] not in skip and (not only or it["eid"] in only)]
    log(out, "%d captures to run (%d done before)" % (len(todo), len(done)))
    SHM.mkdir(exist_ok=True)
    for n, it in enumerate(todo, 1):
        if it["member"]:
            with tarfile.open(CAPS / "cohort-extra.tar.gz", "r:gz") as tar:
                m = tar.getmember(it["member"])
                with tar.extractfile(m) as src, open(it["path"], "wb") as dst:
                    dst.write(src.read())
        t0 = time.time()
        p = subprocess.run([sys.executable, str(REPO / "live_test" / "exact_replay.py"), str(it["path"]),
                            "--anchor-us", it["anchor"], "--execution-id", it["eid"], "--out", str(out / it["eid"]),
                            "--asroot", str(ASROOT)], capture_output=True, text=True, timeout=7200)
        if it["member"]:
            it["path"].unlink()
        line = (p.stdout.strip().splitlines() or ["{}"])[-1]
        try:
            res = json.loads(line)
        except ValueError:
            res = {"error": (p.stderr or p.stdout)[-1500:]}
        res["execution_id"] = it["eid"]
        res["rc"] = p.returncode
        res["wall_s"] = round(time.time() - t0, 1)
        with open(out / "progress.jsonl", "a") as f:
            f.write(json.dumps(res) + "\n")
        log(out, "[%d/%d] %s rc %d exact %s/135 untracked %s lost %s (%.0f s)" % (
            n, len(todo), it["eid"][:16], p.returncode, res.get("exact_nodur"), res.get("untracked_pkts"),
            res.get("windows_lost"), res["wall_s"]))


if __name__ == "__main__":
    main()
