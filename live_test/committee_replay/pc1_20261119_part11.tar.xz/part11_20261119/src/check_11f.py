#!/usr/bin/env python3
"""PC1.md part 11F: one live run with --block-on-alarm, per connection and per window.

    check_11f.py OUT_DIR NAME PC2_SERVER_LOG [--offset-ms 10.028] [--json OUT]

- The monitored program's connections (sockowner FLOW lines of the collector's cgroup, and PC2's ACCEPT lines of the
  same client ports): when each was accepted on PC2 (PC2's clock less --offset-ms), whether it was accepted after the
  alarm, when the entry for its 5-tuple was written (t_reply of the block request that held it) and its last packet in
  PC1's eth1 capture, so that "nothing of the flow after its entry" can be checked; other cgroups' connections (the
  background) before and after the alarm.
- The verdict timing of the 2026-11-19 collector (PC1.md 11F): each score record's time against its window's end on
  PC1's clock (the reader timing file's t_window_end).
- The rows (40), HOSTMON_HEALTH, HOSTMON_WINDOW_DONE lines, SOCKOWNER_HEALTH, blocked_pkts."""
import argparse
import csv
import json
import statistics
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import block_check as bc  # noqa: E402

csv.field_size_limit(sys.maxsize)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("out")
    ap.add_argument("name")
    ap.add_argument("server_log")
    ap.add_argument("--offset-ms", type=float, default=10.028, help="PC2's clock minus PC1's")
    ap.add_argument("--json")
    a = ap.parse_args()
    d, n = Path(a.out), a.name
    ev = [json.loads(l) for l in open(d / ("%s.block.jsonl" % n))]
    alarm = next((e for e in ev if e.get("event") == "alarm"), None)
    blocks = [e for e in ev if e.get("event") == "block"]
    summary = next((e for e in ev if e.get("event") == "summary"), {})
    scores = [e for e in ev if e.get("event") == "score"]
    timing = [json.loads(l) for l in open(d / ("%s.timing.jsonl" % n)) if l.strip()]
    wend = {int(t["window"]): float(t["t_window_end"]) for t in timing if "t_window_end" in t and "window" in t}
    lag = [(s["window"], s["time"] - wend[s["window"]]) for s in scores if s["window"] in wend]
    # flows of each cgroup (sockowner FLOW,t,?,cgroup,direction,proto,src,sport,dst,dport)
    flows = {}
    for line in open(d / ("%s.sockowner.log" % n), errors="replace"):
        f = line.strip().split(",")
        if len(f) == 10 and f[0] == "FLOW":
            cg = int(f[3])
            local_port = int(f[7]) if f[4] == "egress" else int(f[9])
            remote_port = int(f[9]) if f[4] == "egress" else int(f[7])
            flows.setdefault(cg, {}).setdefault((local_port, remote_port), f)
    # the monitored cgroup: the one whose flows were blocked
    blocked_ports = set()
    entry_written = {}
    for b in blocks:
        for e in b["entries"]:
            if e.get("src") == "192.168.0.1" and e.get("sport"):
                blocked_ports.add(e["sport"])
                entry_written.setdefault(e["sport"], b["t_reply"])
    mon = [cg for cg, fl in flows.items() if any(lp in blocked_ports for lp, _ in fl)]
    acc = {}
    for line in open(a.server_log):
        f = line.split()
        if f and f[0] == "ACCEPT" and f[3] == "192.168.0.1":
            acc[int(f[4])] = (float(f[1]) - a.offset_ms / 1e3, int(f[2]))
    # last packet of each local port in PC1's capture (both directions)
    last = {}
    for t, fr in bc.read_pcap(str(d / ("%s.eth1.pcap" % n))):
        x = bc.ipv4(fr)
        if not x or x[2] != 6:
            continue
        port = x[3] if x[0] == "192.168.0.1" else x[4] if x[1] == "192.168.0.1" else None
        if port is not None:
            last[port] = max(last.get(port, 0), t)
    t_alarm = alarm["time"] if alarm else None
    conns = []
    for cg in mon:
        for (lp, rp) in sorted(flows[cg], key=lambda k: acc.get(k[0], (0,))[0]):
            if rp not in (8089, 9100):
                continue
            ta = acc.get(lp, (None,))[0]
            conns.append({"port": lp, "server_port": rp, "accepted_pc1_clock": ta,
                          "after_alarm": (ta is not None and t_alarm is not None and ta > t_alarm),
                          "entry_written": entry_written.get(lp),
                          "last_packet": last.get(lp),
                          "packets_after_entry": (last.get(lp) is not None and entry_written.get(lp) is not None
                                                  and last[lp] > entry_written[lp])})
    other = [(lp, rp) for cg, fl in flows.items() if cg not in mon for lp, rp in fl if rp in (8089, 9100)]
    other_acc = [acc[lp][0] for lp, rp in other if lp in acc]
    rows = list(csv.DictReader(open(d / ("%s.csv" % n))))
    hm = open(d / ("%s.hostmon.log" % n), errors="replace").read().splitlines()
    so = open(d / ("%s.sockowner.log" % n), errors="replace").read().splitlines()
    res = {
        "rows": len(rows), "hostmon_health": next((l for l in reversed(hm) if l.startswith("HOSTMON_HEALTH")), None),
        "hostmon_window_done": sum(1 for l in hm if l.startswith("HOSTMON_WINDOW_DONE")),
        "sockowner_health": next((l for l in reversed(so) if l.startswith("SOCKOWNER_HEALTH")), None),
        "alarm": alarm, "blocks": len(blocks), "entries": sum(len(b["entries"]) for b in blocks),
        "block_round_trip_ms": [round((b["t_reply"] - b["t_request"]) * 1e3, 1) for b in blocks],
        "blocked_pkts": summary.get("blocked_pkts"),
        "monitored_cgroups": mon,
        "program_connections": len(conns),
        "program_connections_accepted_on_pc2": sum(1 for c in conns if c["accepted_pc1_clock"] is not None),
        "program_connections_accepted_after_alarm": sum(1 for c in conns if c["after_alarm"]),
        "program_connections_with_packets_after_their_entry": sum(1 for c in conns if c["packets_after_entry"]),
        "entry_after_last_packet_s": sorted(round(c["entry_written"] - c["last_packet"], 3) for c in conns
                                            if c["entry_written"] and c["last_packet"]),
        "other_cgroup_connections": len(other),
        "other_accepted_before_alarm": sum(1 for t in other_acc if t_alarm is None or t <= t_alarm),
        "other_accepted_after_alarm": sum(1 for t in other_acc if t_alarm is not None and t > t_alarm),
        "score_after_window_end_ms": {
            "n": len(lag), "median": round(statistics.median(l for _, l in lag) * 1e3, 1) if lag else None,
            "max": round(max(l for _, l in lag) * 1e3, 1) if lag else None,
            "over_100ms": [(w, round(l * 1e3, 1)) for w, l in lag if l > 0.1]},
        "score_ms_median": round(statistics.median(s["score_ms"] for s in scores), 1) if scores else None,
        "max_probability": max((s["probability"] for s in scores), default=None),
        "first_window_over_0_5": next((s["window"] for s in scores if s["probability"] >= 0.5), None),
    }
    print(json.dumps(res, indent=1))
    if a.json:
        Path(a.json).write_text(json.dumps(dict(res, connections=conns), indent=1) + "\n")


if __name__ == "__main__":
    main()
