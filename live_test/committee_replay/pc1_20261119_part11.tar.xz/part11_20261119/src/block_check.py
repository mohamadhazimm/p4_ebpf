#!/usr/bin/env python3
"""PC1.md part 11D/11E: what a block rule let through, from one replay_capture.py --exact run with a hairpin.

    block_check.py RUN_DIR CAPTURE [--host 10.0.0.10] [--ref-windows WINDOWS.csv --skip K] [--json OUT]

RUN_DIR: replay_capture.py --exact --send-log ... -- --block-on-alarm ... output (send_log.txt, windows.csv,
windows.block.jsonl, summary.json) plus rx.pcap: what came back to this host through the switch (forwarding
132 -> 132, tcpdump -Q in on eth1; it stands for PC2's capture, which needs root on PC2). Frames of one direction
leave and come back in order over one path, so the k-th frame received from HOST is the k-th one sent that the
switch let through; with a block every frame sent after the block's reply (t_reply) is dropped, and frames sent
between the request and the reply (t_request..t_reply) may go either way.

Prints and writes (--json): the alarm, each block (entries, t_request, t_reply, write_ms), the frames from and to
HOST sent before / during / after the block, received, the last frame from HOST received (its send time, and how long
before t_reply), the switch's blocked_pkts against the frames of the blocked kind sent after the write, and, with
--ref-windows, whether every window (non-duration features) equals the reference run's (the same capture without a
block: the blocked packets are still counted)."""
import argparse
import csv
import json
import struct
import sys

csv.field_size_limit(sys.maxsize)


def read_pcap(path):
    """[(time s, frame bytes)] of a pcap (us or ns)."""
    data = open(path, "rb").read()
    magic = struct.unpack("<I", data[:4])[0]
    if magic in (0xa1b2c3d4, 0xa1b23c4d):
        end, ns = "<", magic == 0xa1b23c4d
    else:
        end, ns = ">", struct.unpack(">I", data[:4])[0] == 0xa1b23c4d
    off, out = 24, []
    while off + 16 <= len(data):
        ts, tu, incl, _orig = struct.unpack(end + "IIII", data[off:off + 16])
        out.append((ts + tu / (1e9 if ns else 1e6), data[off + 16:off + 16 + incl]))
        off += 16 + incl
    return out


def ipv4(frame):
    """(src, dst, proto, sport, dport) of an IPv4 frame (up to two VLAN tags), else None."""
    off, et = 12, struct.unpack("!H", frame[12:14])[0]
    while et in (0x8100, 0x88A8) and len(frame) >= off + 6:
        off += 4
        et = struct.unpack("!H", frame[off:off + 2])[0]
    if et != 0x0800 or len(frame) < off + 22:
        return None
    ip = off + 2
    ihl = (frame[ip] & 0x0F) * 4
    src, dst = ".".join(map(str, frame[ip + 12:ip + 16])), ".".join(map(str, frame[ip + 16:ip + 20]))
    proto = frame[ip + 9]
    sport = dport = None
    if proto in (6, 17) and len(frame) >= ip + ihl + 4:
        sport, dport = struct.unpack("!HH", frame[ip + ihl:ip + ihl + 4])
    return src, dst, proto, sport, dport


def matches(entry, t, port=132):
    src, dst, proto, sport, dport = t
    for k, v in (("src", src), ("dst", dst), ("proto", proto), ("sport", sport), ("dport", dport), ("port", port)):
        e = entry.get(k)
        if e is None:
            continue
        if k in ("src", "dst"):
            a, _, plen = str(e).partition("/")
            plen = int(plen) if plen else 32
            ip = lambda s: struct.unpack("!I", bytes(int(x) for x in s.split(".")))[0]
            mask = ((1 << 32) - 1) << (32 - plen) & ((1 << 32) - 1)
            if ip(v) & mask != ip(a) & mask:
                return False
        elif v != int(e):
            return False
    return True


def window_rows(path):
    return {int(float(r.get("net_window_id") or r.get("window"))): r for r in csv.DictReader(open(path))}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("run")
    ap.add_argument("capture")
    ap.add_argument("--host", default="10.0.0.10")
    ap.add_argument("--ref-windows")
    ap.add_argument("--skip", type=int, default=4, help="collector windows before the run's first (--align-window)")
    ap.add_argument("--json")
    a = ap.parse_args()
    run = a.run.rstrip("/")
    frames = read_pcap(a.capture)
    sent = [l.strip() for l in open(run + "/send_log.txt")]
    assert len(sent) == len(frames), (len(sent), len(frames))
    events = [json.loads(l) for l in open(run + "/windows.block.jsonl")]
    blocks = [e for e in events if e.get("event") == "block"]
    alarm = next((e for e in events if e.get("event") == "alarm"), None)
    summary = next((e for e in events if e.get("event") == "summary"), {})
    entries = [x for b in blocks for x in b["entries"]]
    t_req = blocks[0]["t_request"] if blocks else None
    t_rep = blocks[0]["t_reply"] if blocks else None
    out = {"alarm": alarm, "blocks": [dict({k: b.get(k) for k in ("reason", "window", "entries", "t_request", "t_reply")},
                                           write_ms=b["reply"].get("write_ms"), added=b["reply"].get("added"),
                                           existing=b["reply"].get("existing"),
                                           round_trip_ms=round((b["t_reply"] - b["t_request"]) * 1e3, 2))
                                      for b in blocks],
           "blocked_pkts": summary.get("blocked_pkts"), "summary_entries": summary.get("entries")}
    if alarm and blocks:
        out["alarm_to_reply_ms"] = round((t_rep - alarm["time"]) * 1e3, 2)
    # what was sent, by direction and by time against the block
    sides = {"from_host": [], "to_host": [], "other": []}
    blocked_kind_after = blocked_kind_during = 0
    refused = 0
    for (cap_t, fr), s in zip(frames, sent):
        t = ipv4(fr)
        if s == "-":
            refused += 1
            continue
        ts = float(s)
        if t is None:
            continue
        side = "from_host" if t[0] == a.host else "to_host" if t[1] == a.host else "other"
        sides[side].append((ts, t))
        if blocks and t[2] in (6, 17) and any(matches(e, t) for e in entries):
            if ts > t_rep:
                blocked_kind_after += 1
            elif ts >= t_req:
                blocked_kind_during += 1
    rx = [(ts, ipv4(fr)) for ts, fr in read_pcap(run + "/rx.pcap")]
    rx = [(ts, t) for ts, t in rx if t is not None]
    res = {}
    for side, lst in sides.items():
        got = [x for x in rx if (x[1][0] == a.host if side == "from_host" else x[1][1] == a.host
                                 if side == "to_host" else a.host not in (x[1][0], x[1][1]))]
        before = sum(1 for ts, _ in lst if t_req is None or ts < t_req)
        during = sum(1 for ts, _ in lst if t_req is not None and t_req <= ts <= t_rep)
        after = sum(1 for ts, _ in lst if t_rep is not None and ts > t_rep)
        r = {"sent": len(lst), "sent_before_request": before, "sent_during_write": during, "sent_after_reply": after,
             "received": len(got)}
        if got and lst:
            k = len(got)
            r["last_received_send_time"] = lst[k - 1][0] if k <= len(lst) else None
            if t_rep is not None and k <= len(lst):
                r["last_received_sent_before_reply_ms"] = round((t_rep - lst[k - 1][0]) * 1e3, 3)
                r["first_dropped_sent_after_request_ms"] = (round((lst[k][0] - t_req) * 1e3, 3) if k < len(lst)
                                                            else None)
        res[side] = r
    out["frames"] = res
    out["refused_by_iface"] = refused
    out["blocked_kind_sent_after_reply"] = blocked_kind_after
    out["blocked_kind_sent_during_write"] = blocked_kind_during
    if out["blocked_pkts"] is not None:
        out["blocked_pkts_minus_sent_after_reply"] = out["blocked_pkts"] - blocked_kind_after
    if a.ref_windows:
        mine, ref = window_rows(run + "/windows.csv"), window_rows(a.ref_windows)
        bad = []
        for j in sorted(ref):
            m = mine.get(j + a.skip)
            if m is None:
                bad.append((j, "missing"))
                continue
            dc = [c for c in ref[j] if c.startswith("net_") and "duration" not in c and c in m
                  and float(m[c] or 0) != float(ref[j][c] or 0)]
            if dc:
                bad.append((j, {c: [m[c], ref[j][c]] for c in dc}))
        out["windows_equal_to_reference"] = "%d/%d" % (len(ref) - len(bad), len(ref))
        out["windows_differing"] = bad[:5]
    print(json.dumps(out, indent=1, default=str))
    if a.json:
        open(a.json, "w").write(json.dumps(out, indent=1, default=str) + "\n")


if __name__ == "__main__":
    main()
