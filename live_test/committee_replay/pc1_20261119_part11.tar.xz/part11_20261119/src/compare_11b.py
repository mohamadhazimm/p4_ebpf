#!/usr/bin/env python3
"""PC1.md part 11B: the rows (and the windows) of basic_exact_block against the exact build's.

    compare_11b.py RUNS_DIR OUT_PREFIX

RUNS_DIR holds exact_replay.py run directories (run_exact.py OUT_DIR), one per execution id. Each run's row.csv
(145 net_ columns) is compared with
  - v3: part 6b's collector rows on basic_exact_v3 (perf/results/exact_collector/replay_rows_exact_collector.csv),
  - p6: part 6's driver rows (perf/results/exact_replay/replay_rows_exact.csv),
and its windows.csv (every window's 29 features) with part 6's run of the same capture
(perf/results/exact_replay/runs/ID/windows.csv). Columns with "duration" in their name are the switch clock's
(the replay's timing), so they are counted apart: "135" = the other columns.
Writes OUT_PREFIX.csv (one line per run and reference) and OUT_PREFIX.json (the differing columns)."""
import csv
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[4]
REFS = {"v3": REPO / "perf/results/exact_collector/replay_rows_exact_collector.csv",
        "p6": REPO / "perf/results/exact_replay/replay_rows_exact.csv"}
P6_RUNS = REPO / "perf/results/exact_replay/runs"
csv.field_size_limit(sys.maxsize)


def rows_by_id(path):
    return {r["execution_id"]: r for r in csv.DictReader(open(path))}


def num(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return v


def same(a, b):
    a, b = num(a), num(b)
    if isinstance(a, float) and isinstance(b, float):
        return a == b or abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))
    return a == b


def windows(path):
    out = {}
    for r in csv.DictReader(open(path)):
        key = r.get("window") or r.get("window_id") or r.get("net_window_id")
        out[int(float(key))] = r
    return out


def main():
    runs, prefix = Path(sys.argv[1]), Path(sys.argv[2])
    refs = {k: rows_by_id(p) for k, p in REFS.items()}
    lines, detail = [], {}
    for d in sorted(p for p in runs.iterdir() if (p / "row.csv").exists()):
        eid = d.name
        row = next(csv.DictReader(open(d / "row.csv")))
        cols = [c for c in row if c.startswith("net_")]
        nodur = [c for c in cols if "duration" not in c]
        for name, ref in refs.items():
            r = ref.get(eid)
            if r is None:
                continue
            diff = [c for c in cols if not same(row[c], r.get(c))]
            lines.append({"execution_id": eid, "reference": name, "columns": len(cols),
                          "equal_all": len(cols) - len(diff),
                          "equal_nodur": len(nodur) - len([c for c in diff if c in nodur]),
                          "nodur_columns": len(nodur)})
            detail["%s/%s" % (eid, name)] = {c: [row[c], r.get(c)] for c in diff}
        wp6 = P6_RUNS / eid / "windows.csv"
        if wp6.exists() and (d / "windows.csv").exists():
            a, b = windows(d / "windows.csv"), windows(wp6)
            # the columns of both files (part 6's windows.csv lacks v3's net_rejected_markers, net_unclocked_pkts)
            feats = [c for c in next(iter(a.values())) if c.startswith("net_") and c in next(iter(b.values()))] \
                if a and b else []
            wdiff = {}
            for w in sorted(set(a) | set(b)):
                if w not in a or w not in b:
                    wdiff[w] = "missing in %s" % ("part 11" if w not in a else "part 6")
                    continue
                dc = [c for c in feats if not same(a[w].get(c), b[w].get(c))]
                if dc:
                    wdiff[w] = {c: [a[w].get(c), b[w].get(c)] for c in dc}
            nodur_w = {w: v for w, v in wdiff.items()
                       if not isinstance(v, dict) or any("duration" not in c for c in v)}
            lines.append({"execution_id": eid, "reference": "p6_windows", "columns": len(feats),
                          "equal_all": len(set(a) & set(b)) - len(wdiff),
                          "equal_nodur": len(set(a) & set(b)) - len(nodur_w), "nodur_columns": len(a)})
            detail["%s/p6_windows" % eid] = wdiff
    with open(str(prefix) + ".csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(lines[0]))
        w.writeheader()
        w.writerows(lines)
    Path(str(prefix) + ".json").write_text(json.dumps(detail, indent=1, sort_keys=True) + "\n")
    for l in lines:
        if l["reference"] == "p6_windows":
            print("%-20s %-10s windows equal in all features %d, without durations %d (of %d windows)" % (
                l["execution_id"][:20], l["reference"], l["equal_all"], l["equal_nodur"], l["nodur_columns"]))
        else:
            print("%-20s %-10s equal %3d/%d, without durations %3d/%d" % (
                l["execution_id"][:20], l["reference"], l["equal_all"], l["columns"], l["equal_nodur"],
                l["nodur_columns"]))


if __name__ == "__main__":
    main()
