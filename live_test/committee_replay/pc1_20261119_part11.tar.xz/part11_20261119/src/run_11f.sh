#!/bin/bash
# PC1.md part 11F: live runs on basic_exact_block with --block-on-alarm, the host monitor (hostmon_agg, rebuilt
# 2026-11-19 with HOSTMON_WINDOW_DONE) and the socket tracer (sockowner), servers on PC2 behind port 140 (the
# collector programs 132 <-> 140). As part 6c's run_live.sh, with PC1.md 11F's command: --profile exact (CPU-port
# markers, the dataset's launcher), the collector under the dataset construction's .venv (NumPy, scikit-learn 1.9.1 for
# the detectors; the program under test still runs on /usr/bin/python3). eth1 is captured in both directions.
#   run_11f.sh OUT_DIR NAME WORKLOAD [hybrid_collector.py options ...]      (as root)
set -u
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
REL=/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection
PY=/home/admin/Desktop/hAZIM/p4_ebpf-dataset-construction/.venv/bin/python3
OUT=$1; NAME=$2; WL=$3; shift 3
mkdir -p "$OUT"
if [ -e "$OUT/$NAME.csv" ]; then echo "$OUT/$NAME.csv exists" >&2; exit 1; fi
cd "$REPO"
tcpdump -i eth1 -s 128 -w "$OUT/$NAME.eth1.pcap" ip 2> "$OUT/$NAME.tcpdump.log" &
TD=$!
sleep 2
"$PY" hybrid_collector.py --profile exact --mode command --switch-ssh root@172.168.1.2 \
    --forward-int-port 132 --forward-ext-port 140 --cpu-iface enp5s0 --frame-min 192.168.0.1/32 \
    --p4-reader thesis-hybrid-ebpf-p4/python/read_registers_with_index.py \
    --p4-forwarder thesis-hybrid-ebpf-p4/python/program_forwarding.py --windows 40 \
    --hostmon ebpf_perf/build/hostmon_agg --hostmon-cgroup /sys/fs/cgroup/unified/hazim_collect \
    --hostmon-log "$OUT/$NAME.hostmon.log" \
    --sockowner ebpf_perf/sockowner/build/sockowner --sockowner-attach /sys/fs/cgroup/unified \
    --sockowner-log "$OUT/$NAME.sockowner.log" \
    --block-on-alarm "$@" \
    --scenario-name "blk_$NAME" --label benign \
    --command "python3 $REL/validation/hybrid/workloads.py $WL --server 192.168.0.2" \
    --out-csv "$OUT/$NAME.csv" --reader-timing-file "$OUT/$NAME.timing.jsonl" > "$OUT/$NAME.collector.log" 2>&1
echo "collector rc $?" >> "$OUT/$NAME.collector.log"
sleep 1; kill -INT $TD; wait $TD
chown -R admin:admin "$OUT"
echo "$NAME: $(tail -1 "$OUT/$NAME.collector.log"); $(grep -o 'HOSTMON_HEALTH.*' "$OUT/$NAME.hostmon.log" | tail -1);" \
     "$(grep -c '^HOSTMON_WINDOW_DONE' "$OUT/$NAME.hostmon.log") window-done lines"
grep -E '^\[BLOCK\]|block rules' "$OUT/$NAME.collector.log" | head -20
