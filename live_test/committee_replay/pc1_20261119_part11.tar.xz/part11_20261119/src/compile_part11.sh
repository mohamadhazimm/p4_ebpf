#!/bin/bash
# part 11A compiles (PC1.md part 11), one after another
H=/root/hazim_perf
C=$H/tools/sw_compile.sh
bash $C $H/src/exact_block basic.p4 $H/build/basic_exact_block
bash $C $H/src/exact_block basic.p4 $H/build/basic_exact_block_timer -DTIMER_LOCAL_PORT=68
bash $C $H/src/basic_hwl_exact_block basic.p4 $H/build/basic_hwl_exact_block
touch $H/build/part11_compiles.done
