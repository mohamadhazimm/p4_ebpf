#!/usr/bin/env python3
"""PC1.md Part 4 driver (2026-11-15): replay the 110 dataset captures through the Wedge with
live_test/replay_capture.py --profile dataset and turn each run into a dataset row.

Runs as admin; only replay_capture.py runs as root (through asroot.sh, the .env sudo wrapper).
Order: the 77 cohort captures in manifest order (Chaos last), then the 33 extras with
expect_overload 0 first (the three bulk uploads, the largest, at the end of that group) and the
8 with expect_overload 1 last. Extras are extracted from cohort-extra.tar.gz one at a time (PC1's
disk cannot hold the 771 MB at once), checked against SHA256SUMS and the manifest, and deleted
after their replay. tx.pcap is gzipped after each run (summary.json is already written then).
Before each run: free disk and MemAvailable are checked; if either is short the driver stops
BEFORE that capture (exit 3) so that a rerun resumes in order. A failed run is recorded in
progress.jsonl and never rerun by this driver (PC1.md: report it).

    python3 run_part4.py ASROOT [--only-check]
"""
import csv
import gzip
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection")
CAPS = REPO / "live_test" / "captures"
TARBALL = CAPS / "cohort-extra.tar.gz"
OUT = REPO / "perf" / "results" / "committee_replay"
RUNS = OUT / "runs"
ROWS = OUT / "replay_rows.csv"
PROGRESS = OUT / "progress.jsonl"
LOG = OUT / "driver.log"
ALIGN = 4
DISK_MARGIN = 150 << 20      # bytes left free beyond the extracted capture and the run's outputs
MEM_MARGIN = 450 << 20       # MemAvailable beyond the capture size (the replayer holds every frame)
# Resume of 11:30: a VS Code process holds 542 MB of deleted files open, so the remaining extras are
# extracted to tmpfs (RAM) instead of the disk; the memory gate then counts the capture twice.
EXTRACT_DIR = Path("/dev/shm/hz_part4")
# Not replayed, with the reason (recorded in progress.jsonl as "skipped"):
SKIP = {"bulkup_700": "15,072 of its 49,940 frames are guest GSO super-frames over 1514 B (max 65,226 B); "
                      "eth1 (MTU 1500) refuses them, as it did 4,370 of bulkup_200 and 8,824 of bulkup_400"}


def log(msg):
    line = "%s %s" % (time.strftime("%H:%M:%S"), msg)
    print(line, flush=True)
    with open(LOG, "a") as f:
        f.write(line + "\n")


def record(entry):
    with open(PROGRESS, "a") as f:
        f.write(json.dumps(entry) + "\n")


def done_ids():
    if not PROGRESS.exists():
        return {}
    out = {}
    for line in PROGRESS.read_text().splitlines():
        if line.strip():
            e = json.loads(line)
            if e.get("status") in ("done", "failed", "skipped"):
                out[e["execution_id"]] = e["status"]
    return out


def mem_available():
    for line in open("/proc/meminfo"):
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) * 1024
    return 0


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def plan():
    cohort = list(csv.DictReader(open(CAPS / "cohort" / "manifest.csv")))
    extra = list(csv.DictReader(open(CAPS / "cohort-extra" / "manifest.csv")))
    members = {}
    for line in subprocess.run(["tar", "tvzf", str(TARBALL)], check=True, capture_output=True,
                               text=True).stdout.splitlines():
        parts = line.split()
        members[parts[-1]] = int(parts[2])
    sums = {}
    for line in (CAPS / "cohort-extra" / "SHA256SUMS").read_text().splitlines():
        digest, name = line.split(None, 1)
        sums[name.lstrip("*")] = digest
    items = []
    for r in cohort:
        p = CAPS / "cohort" / r["capture"]
        items.append(dict(set="cohort", execution_id=r["execution_id"], category=r["category"], label=r["label"],
                          anchor=r["anchor_offset_s"], capture=p, size=p.stat().st_size, sha=r["sha256"],
                          overload=r["expect_overload"], extract=False))
    calm = [r for r in extra if r["expect_overload"] == "0"]
    calm = [r for r in calm if not r["execution_id"].startswith("bulkup_")] + \
        sorted([r for r in calm if r["execution_id"].startswith("bulkup_")],
               key=lambda r: members["cohort-extra/" + r["capture"]])
    for r in calm + [r for r in extra if r["expect_overload"] == "1"]:
        name = "cohort-extra/" + r["capture"]
        if sums.get(r["capture"]) != r["sha256"]:
            sys.exit("SHA256SUMS and manifest disagree for %s" % r["capture"])
        items.append(dict(set="extra", execution_id=r["execution_id"], category=r["category"], label=r["label"],
                          anchor=r["anchor_offset_s"], capture=EXTRACT_DIR / name, member=name, size=members[name],
                          sha=r["sha256"], overload=r["expect_overload"], extract=True))
    return items


def main():
    asroot = sys.argv[1]
    only_check = "--only-check" in sys.argv
    OUT.mkdir(parents=True, exist_ok=True)
    RUNS.mkdir(exist_ok=True)
    items = plan()
    log("plan: %d captures (%d cohort, %d extra); order: %s" % (
        len(items), sum(i["set"] == "cohort" for i in items), sum(i["set"] == "extra" for i in items),
        ", ".join(i["execution_id"][:12] for i in items[77:])))
    if only_check:
        return 0
    finished = done_ids()
    for n, it in enumerate(items, 1):
        eid = it["execution_id"]
        if eid in finished:
            continue
        if eid in SKIP:
            log("[%d/%d] %s skipped: %s" % (n, len(items), eid, SKIP[eid]))
            record(dict(execution_id=eid, set=it["set"], n=n, status="skipped", reason=SKIP[eid], time=time.time()))
            continue
        free = shutil.disk_usage("/").free
        need_disk = it["size"] // 8 + DISK_MARGIN
        need_mem = it["size"] * (2 if it["extract"] else 1) + MEM_MARGIN
        if free < need_disk or mem_available() < need_mem:
            log("STOP before %d/%d %s: free disk %d MB (need %d), MemAvailable %d MB (need %d)" % (
                n, len(items), eid, free >> 20, need_disk >> 20, mem_available() >> 20, need_mem >> 20))
            record(dict(execution_id=eid, status="stopped", free_mb=free >> 20, mem_mb=mem_available() >> 20,
                        need_disk_mb=need_disk >> 20, need_mem_mb=need_mem >> 20, time=time.time()))
            return 3
        entry = dict(execution_id=eid, set=it["set"], n=n, category=it["category"], label=it["label"],
                     expect_overload=it["overload"], capture_bytes=it["size"], start=time.time())
        try:
            if it["extract"]:
                EXTRACT_DIR.mkdir(exist_ok=True)
                subprocess.run(["tar", "xzf", str(TARBALL), "-C", str(EXTRACT_DIR), "--occurrence=1", it["member"]],
                               check=True)
            got = sha256(it["capture"])
            if got != it["sha"]:
                raise RuntimeError("sha256 %s != manifest %s" % (got, it["sha"]))
            run_dir = RUNS / eid
            cmd = [asroot, "python3", str(REPO / "live_test" / "replay_capture.py"), str(it["capture"]),
                   "--out", str(run_dir), "--profile", "dataset", "--anchor-offset", it["anchor"],
                   "--align-window", str(ALIGN)]
            log("[%d/%d] %s (%s, %s, overload %s, %.1f MB)" % (n, len(items), eid, it["set"], it["category"],
                                                               it["overload"], it["size"] / 1e6))
            p = subprocess.run(cmd, cwd=str(REPO), capture_output=True, text=True)
            for line in (p.stdout + p.stderr).splitlines():
                if line.startswith("[replay]") or "Traceback" in line or "Error" in line:
                    log("    " + line)
            entry["replay_rc"] = p.returncode
            if p.returncode != 0:
                (run_dir.mkdir(parents=True, exist_ok=True))
                (run_dir / "driver_replay_output.txt").write_text(p.stdout + p.stderr)
            summ = run_dir / "summary.json"
            if summ.exists():
                s = json.loads(summ.read_text())
                entry["collector_exit_code"] = s.get("collector_exit_code")
            tx = run_dir / "tx.pcap"
            if tx.exists():
                with open(tx, "rb") as src, gzip.open(str(tx) + ".gz", "wb", compresslevel=6) as dst:
                    shutil.copyfileobj(src, dst)
                tx.unlink()
            if not (run_dir / "windows.csv").exists():
                raise RuntimeError("no windows.csv (replay rc %d)" % p.returncode)
            d = subprocess.run([sys.executable, str(REPO / "live_test" / "dataset_row.py"), str(run_dir / "windows.csv"),
                                "--execution-id", eid, "--category", it["category"], "--label", it["label"],
                                "--skip-windows", str(ALIGN), "--release", str(RELEASE), "--out", str(ROWS)],
                               cwd=str(REPO), capture_output=True, text=True)
            log("    " + (d.stdout + d.stderr).strip().replace("\n", " | "))
            entry["dataset_row_rc"] = d.returncode
            ok = p.returncode == 0 and d.returncode == 0 and entry.get("collector_exit_code") == 0
            entry["status"] = "done" if ok else "failed"
        except Exception as e:  # noqa: BLE001 - recorded, not retried
            entry["status"] = "failed"
            entry["error"] = repr(e)
            log("    FAILED: %r" % e)
        finally:
            if it["extract"] and it["capture"].exists():
                it["capture"].unlink()
        entry["end"] = time.time()
        record(entry)
        if entry["status"] != "done":
            log("    -> %s (not rerun)" % entry["status"])
        time.sleep(2)
    log("all %d captures processed" % len(items))
    return 0


if __name__ == "__main__":
    sys.exit(main())
