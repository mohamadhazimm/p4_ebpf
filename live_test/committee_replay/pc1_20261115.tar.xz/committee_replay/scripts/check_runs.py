#!/usr/bin/env python3
"""Per-run checks of the Part 4 replays: totals, the self-check with the dataset profile's 14 B per frame
taken off (replay_capture.py compares frame bytes with IPv4 bytes), overload/overrun windows, replayer
failures and lateness. Writes run_checks.json and run_checks.csv next to progress.jsonl."""
import csv, json, re, statistics as st
from pathlib import Path
R = Path(__file__).resolve().parent.parent
last = {}
for l in open(R / "progress.jsonl"):
    if l.strip():
        e = json.loads(l); last[e["execution_id"]] = e
out = []
for eid, e in last.items():
    if e["status"] != "done":
        continue
    d = R / "runs" / eid
    s = json.loads((d / "summary.json").read_text()); sc = s["self_check"]
    w = list(csv.DictReader(open(d / "windows.csv")))[4:44]
    ok = chk = 0
    for pw in s["per_window"]:
        if pw["window"] < 4 or "certain_pkts" not in pw or pw["overload"]:
            continue
        chk += 1
        b = pw["switch_bytes"] - 14 * pw["switch_pkts"]
        ok += pw["certain_pkts"] <= pw["switch_pkts"] <= pw["possible_pkts"] and pw["certain_bytes"] <= b <= pw["possible_bytes"]
    log = (d / "collector.log").read_text()
    m = re.search(r"\[replay_absolute\] (\d+) frames sent, (\d+) failed", log)
    out.append(dict(execution_id=eid, set=e["set"], category=e["category"], expect_overload=int(e["expect_overload"]),
        alignment_error_ms=s.get("alignment_error_ms"), replay_late_max_ms=(s.get("replay_timing_error_ms") or {}).get("max"),
        replay_late_median_ms=(s.get("replay_timing_error_ms") or {}).get("median"),
        frames_sent=int(m.group(1)) if m else None, frames_failed=int(m.group(2)) if m else None,
        switch_pkts=sc["switch_pkts_total"], sent_pkts=sc["sent_pkts_total"],
        switch_ipv4_bytes=sc["switch_bytes_total"] - 14 * sc["switch_pkts_total"], sent_ipv4_bytes=sc["sent_bytes_total"],
        overload_windows=sum(int(float(r["net_overload"])) for r in w), overrun_windows=sum(int(float(r["net_read_overrun"])) for r in w),
        windows_checked=chk, windows_in_bounds=ok, collector_warnings=log.count("[WARN]") - log.count("pairing by index")))
(R / "run_checks.json").write_text(json.dumps(out, indent=1) + "\n")
with open(R / "run_checks.csv", "w", newline="") as f:
    wr = csv.DictWriter(f, fieldnames=list(out[0])); wr.writeheader(); wr.writerows(out)
calm = [r for r in out if not r["overload_windows"]]
print(len(out), "runs;", len(calm), "without an overloaded window")
print("  packets equal:", sum(r["switch_pkts"] == r["sent_pkts"] for r in calm), "; IPv4 bytes equal:", sum(r["switch_ipv4_bytes"] == r["sent_ipv4_bytes"] for r in calm))
print("  windows in bounds:", sum(r["windows_in_bounds"] for r in calm), "of", sum(r["windows_checked"] for r in calm))
print("  not equal:", [(r["execution_id"][:14], r["switch_pkts"] - r["sent_pkts"], r["switch_ipv4_bytes"] - r["sent_ipv4_bytes"]) for r in calm if r["switch_pkts"] != r["sent_pkts"] or r["switch_ipv4_bytes"] != r["sent_ipv4_bytes"]])
print("  out of bounds:", [(r["execution_id"][:14], r["windows_checked"] - r["windows_in_bounds"]) for r in calm if r["windows_in_bounds"] < r["windows_checked"]])
print("overloaded runs:", [(r["execution_id"][:14], r["expect_overload"], r["overload_windows"], "%.0f%%" % (100 * r["switch_pkts"] / r["sent_pkts"])) for r in out if r["overload_windows"]])
print("overrun windows:", sum(r["overrun_windows"] for r in out), "; replayer failures:", [(r["execution_id"], r["frames_failed"]) for r in out if r["frames_failed"]])
print("alignment |err| ms median %.2f max %.2f; replay lateness max: median %.1f ms, runs over 20 ms: %s" % (
    st.median(abs(r["alignment_error_ms"]) for r in out), max(abs(r["alignment_error_ms"]) for r in out),
    st.median(r["replay_late_max_ms"] for r in out), [(r["execution_id"][:14], r["replay_late_median_ms"], r["replay_late_max_ms"]) for r in out if r["replay_late_max_ms"] > 20]))
print("other collector warnings:", [(r["execution_id"][:14], r["collector_warnings"]) for r in out if r["collector_warnings"] and not r["overload_windows"]])
