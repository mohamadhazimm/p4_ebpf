#!/bin/bash
# p4_perf 3.2 / 5.5 matrix on the gtot build, with the global totals counted (--global-totals)
cd /root/hazim_perf/runs/linerate_gtot_20261115
T=/root/hazim_perf/tools/sw_pktgen_run.py
run() { out=$1; shift; python2.7 $T $out --prog basic --seconds 10 --flow-index 44993 --global-totals "$@" > ${out%.json}.log 2>&1; }
for r in 1 2 3; do run gtot_64_max_r$r.json --size 64; done
for s in 128 256 512 1024 1280 1518; do
    for r in 1 2 3; do run gtot_${s}_paced_r$r.json --size $s --rate-pct 99.9; done
    run gtot_${s}_max.json --size $s
done
python2.7 $T cleanup.json --prog basic --cleanup > cleanup.log 2>&1
date -u +%FT%TZ > matrix.done
