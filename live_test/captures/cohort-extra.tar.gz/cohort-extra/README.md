# Extra captures for the replays through the switch (PC1.md Part 4)

The 33 captures of the dataset rows that the cohort folder leaves out: the network attacks and the
network-active benign runs (rows 204-239 of the release's `dataset/features.csv`; the 3 null runs
have no traffic and are listed in `not_replayed.csv`). With the 77 in `../cohort/` they are every
dataset run that carries IPv4 TCP/UDP traffic: 110 in all.

## What is here

| file | content |
|---|---|
| `<execution_id>.pcap` | 33 captures: 15 network attacks, 18 network-active benign runs |
| `manifest.csv` | the cohort manifest's columns plus `attack_type`; `expect_overload` 1 for 8 attack runs |
| `not_replayed.csv` | the 3 null runs (no IPv4 TCP/UDP packet in their observation) |
| `SHA256SUMS` | every file in this folder |

The captures hold 1,308,754 TCP/UDP packets and take 771 MB unpacked (the bulk uploads keep their
frame lengths), so they are committed as `../cohort-extra.tar.gz` (26 MB). Unpack with

    tar xzf live_test/captures/cohort-extra.tar.gz -C live_test/captures
    (cd live_test/captures/cohort-extra && sha256sum -c SHA256SUMS)

## Where they come from

- **Runs:** the 15 attack runs and 18 network-benign runs of `flood21-collect` and
  `realtools-collect` behind rows 204-239, runner schema `2026-10-24.21`, 0.5 s windows, 40 windows,
  a fixed 20 s observation, the same settings as the cohort.
- **Packager:** `committee-eval-20261113/switchgap/package_extra.py` on the lab workstation
  (sha256 `719039ec7ffa77c25fe0109b12627ec4cfc2211e65b3066d27c2fb9b62db1ad7`). It applies the same steps and checks as `live_test/package_cohort.py`,
  using that file's own `sanitize()` and `SwitchRules`.
- **Steps:** each capture is trimmed to the observation [anchor, anchor + 20 s); every IPv4 frame
  keeps its Ethernet, IPv4 and TCP/UDP headers, every later byte is zero, lengths and timestamps
  are kept and the TCP/UDP checksum is recomputed. No payload is left.

## Checks (all passed)

- The sanitized capture gives the same features as the original in every window, under the
  published extractor (0.5 s, 40 windows) and under the switch rules at 0.5 s and 1 s.
- On the original capture the published extractor reproduces the row's 145 network columns.

## Replay order

Replay the 25 runs with `expect_overload` 0 first and the 8 with `expect_overload` 1 last: the
SYN/UDP fan-out floods, `slowloris_1000` and the two GoldenEye runs keep more buckets active per
window than the reader can read (they exercise the read budget). The three bulk uploads are the
largest files (106-372 MB unpacked).
