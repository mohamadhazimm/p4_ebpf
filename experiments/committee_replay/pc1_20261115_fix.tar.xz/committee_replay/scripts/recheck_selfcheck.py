#!/usr/bin/env python3
"""Recompute each Part 4 run's summary with the fixed self-check of live_test/replay_capture.py (sent bytes in the
collector's byte layer: +14 B per packet under --profile dataset). Inputs per run: windows.csv, timing.jsonl and
tx.pcap.gz from the run, the capture from cohort/ or streamed out of cohort-extra.tar.gz into tmpfs. Writes
runs/<id>/summary_fixed.json (the original summary.json is kept) and compares the windows inside the bounds with
check_runs.py's corrected count (run_checks.json). No switch, no root."""
import gzip
import importlib.util
import json
import shutil
import tarfile
import tempfile
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
R = REPO / "perf" / "results" / "committee_replay"
CAPS = REPO / "live_test" / "captures"

spec = importlib.util.spec_from_file_location("replay_capture", REPO / "live_test" / "replay_capture.py")
rc = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rc)

checks = {c["execution_id"]: c for c in json.load(open(R / "run_checks.json"))}
last = {}
for line in open(R / "progress.jsonl"):
    if line.strip():
        e = json.loads(line)
        last[e["execution_id"]] = e
done = {eid for eid, e in last.items() if e["status"] == "done"}
results = {}


def recheck(eid, capture):
    run = R / "runs" / eid
    old = json.loads((run / "summary.json").read_text())
    with tempfile.TemporaryDirectory(dir="/dev/shm") as d:
        tmp = Path(d)
        for name in ("windows.csv", "timing.jsonl"):
            (tmp / name).symlink_to(run / name)
        with gzip.open(run / "tx.pcap.gz", "rb") as src, open(tmp / "tx.pcap", "wb") as dst:
            shutil.copyfileobj(src, dst)
        new = rc.analyse(tmp, capture, old["anchor_offset_s"], old["align_window"], old["sleep_s"],
                         old["self_check"]["report_latency_bound_s"], old["window_sec"],
                         header_bytes=rc.self_check_header_bytes("dataset"))
    new["capture"] = old["capture"]
    new["collector_exit_code"] = old.get("collector_exit_code")
    assert new["capture_sha256"] == old["capture_sha256"], eid
    (run / "summary_fixed.json").write_text(json.dumps(new, indent=1) + "\n")
    sc, c = new["self_check"], checks[eid]
    results[eid] = (sc["windows_checked"], sc["windows_inside_bounds"], c["windows_checked"], c["windows_in_bounds"],
                    sc["switch_bytes_total"] - sc["sent_bytes_total"])


for p in sorted((CAPS / "cohort").glob("*.pcap")):
    if p.stem in done:
        recheck(p.stem, p)
with tarfile.open(CAPS / "cohort-extra.tar.gz", "r:gz") as t, tempfile.TemporaryDirectory(dir="/dev/shm") as d:
    for m in t:
        eid = Path(m.name).stem
        if not m.name.endswith(".pcap") or eid not in done:
            continue
        cap = Path(d) / Path(m.name).name
        with t.extractfile(m) as src, open(cap, "wb") as dst:
            shutil.copyfileobj(src, dst)
        recheck(eid, cap)
        cap.unlink()

agree = sum(r[0] == r[2] and r[1] == r[3] for r in results.values())
print("%d runs rechecked; windows checked / inside bounds equal to run_checks.json in %d" % (len(results), agree))
for eid, r in sorted(results.items()):
    if not (r[0] == r[2] and r[1] == r[3]):
        print("  differs:", eid, r)
print("windows inside bounds, fixed self-check: %d of %d" % (sum(r[1] for r in results.values()),
                                                             sum(r[0] for r in results.values())))
print("switch - sent bytes (frame layer), runs not 0:",
      [(eid[:14], r[4]) for eid, r in sorted(results.items()) if r[4] != 0 and not checks[eid]["overload_windows"]])
