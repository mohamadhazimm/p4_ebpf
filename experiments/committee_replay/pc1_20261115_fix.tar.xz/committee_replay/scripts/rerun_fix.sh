#!/bin/bash
# Rerun bulk1600 and bulk2000 (3 times each) with the fixed collector (dormant-row baseline) and the fixed
# self-check (frame bytes), the same commands as run_part4.py. Usage: rerun_fix.sh ASROOT
set -u
ASROOT=$1
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
R=$REPO/perf/results/committee_replay
SHM=/dev/shm/hz_fix
cd "$REPO" || exit 1
mkdir -p "$SHM" "$R/runs_fix"
for eid in bulk1600 bulk2000; do
  line=$(awk -F, -v id="$eid" 'NR==1{for(i=1;i<=NF;i++)h[$i]=i; next} $h["execution_id"]==id{print $h["category"], $h["label"], $h["anchor_offset_s"], $h["sha256"]}' live_test/captures/cohort-extra/manifest.csv)
  read -r cat label anchor sha <<< "$line"
  tar xzf live_test/captures/cohort-extra.tar.gz -C "$SHM" --occurrence=1 "cohort-extra/$eid.pcap" || exit 1
  cap=$SHM/cohort-extra/$eid.pcap
  [ "$(sha256sum "$cap" | cut -d' ' -f1)" = "$sha" ] || { echo "sha256 mismatch for $eid"; exit 1; }
  for rep in 1 2 3; do
    out=$R/runs_fix/${eid}_r$rep
    echo "== $eid rep $rep ($cat, label $label, anchor $anchor)"
    "$ASROOT" python3 live_test/replay_capture.py "$cap" --out "$out" --profile dataset \
        --anchor-offset "$anchor" --align-window 4 | grep '^\[replay\]'
    python3 live_test/dataset_row.py "$out/windows.csv" --execution-id "$eid" --category "$cat" --label "$label" \
        --skip-windows 4 --release /home/admin/Desktop/hAZIM/p4-ebpf-malware-detection --out "$R/runs_fix/rows.csv"
    gzip -6 "$out/tx.pcap"
    sleep 2
  done
  rm -f "$cap"
done
rmdir "$SHM/cohort-extra" "$SHM"
