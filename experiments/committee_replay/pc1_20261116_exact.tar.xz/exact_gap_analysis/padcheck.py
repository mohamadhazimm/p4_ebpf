import sys, json, csv, collections, tarfile, subprocess
sys.path.insert(0, ".")
from gap_analysis import records, parse_model, CAPS, WINDOW_US, WINDOWS
from socket import inet_ntoa
R=[json.loads(l) for l in open("out_all/gap.jsonl")]
want={r["execution_id"] for r in R if r["frame_gt_ipv4"]}
cohort={r["execution_id"]:r for r in csv.DictReader(open(CAPS/"cohort"/"manifest.csv"))}
tot=collections.Counter()
def scan(eid, f, anchor):
    c=collections.Counter()
    for tus, ts, ns, fr in records(f):
        off=tus-anchor
        if off<0 or off//WINDOW_US>=WINDOWS: continue
        p=parse_model(fr)
        if p is None: continue
        ext=len(fr)-14-p[6]
        if ext>0:
            c[("pad", len(fr), inet_ntoa(p[1]))]+=1
        elif len(fr) < 60:
            c[("short", len(fr), inet_ntoa(p[0]))]+=1
    return c
for eid in sorted(want):
    if eid in cohort:
        with open(CAPS/"cohort"/cohort[eid]["capture"],"rb") as f: c=scan(eid,f,int(cohort[eid]["anchor_us"]))
        tot.update(c); print(eid[:14], c.most_common(4))
print("TOTAL", tot.most_common(12))
