#!/usr/bin/env python3
"""Offline gap analysis of the switch design against features/switch_model.py (the published rows).

For each of the 110 captures (cohort/ + cohort-extra.tar.gz), with the windows of the dataset
(anchor_us, 40 x 0.5 s), it runs:
  model   the release's FlowTable (copied, py3.8), summarized as features/summary.py: must equal the
          published row (checks that the windows and the code are reproduced);
  bucket  the current ingress.p4 with perfect reads and perfect window cuts: CRC-16 symmetric
          bucket, the current parser (no VLAN / IHL / fragment checks), direction from the bucket's
          first ports, IPv4 totalLen + 14 B, 3-window TTL per bucket, never cleared;
  dp      the proposed data-plane design: exact flow (k-way table + 32-bit signature), direction from
          the first packet's (address, port), per-window aggregates in tagged banks reconstructed as the
          control plane would; run with frame bytes (dp_frame: checks the algorithm) and with IPv4
          totalLen + 14 (dp_ipv4: what the switch can count).
Also: parser disagreements, distinct flows, flow-table overflow for several k-way layouts, flows that a
symmetric (unordered) key would merge.

    python3 gap_analysis.py OUT_DIR [execution_id ...]
"""
import csv
import json
import math
import struct
import sys
import tarfile
import zlib
from decimal import Decimal
from pathlib import Path

import numpy as np

sys.path.insert(0, "/home/admin/Desktop/hAZIM/p4_ebpf/thesis-hybrid-ebpf-p4/python")
from flow_index import compute_flow_index  # noqa: E402

REL = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection")
CAPS = Path("/home/admin/Desktop/hAZIM/p4_ebpf/live_test/captures")
WINDOW_US, WINDOWS, TTL, HDR = 500000, 40, 3, 14

FEATURES = [
    "net_flow_count_seen", "net_pkts_total_delta", "net_bytes_total_delta", "net_pkts_ab_delta",
    "net_bytes_ab_delta", "net_pkts_ba_delta", "net_bytes_ba_delta", "net_min_len_mean", "net_max_len_mean",
    "net_min_len_min", "net_max_len_max", "net_avg_pkt_size_delta", "net_avg_pkt_size_ab_delta",
    "net_avg_pkt_size_ba_delta", "net_flow_duration_mean", "net_flow_duration_max", "net_bytes_per_sec_delta",
    "net_pkts_per_sec_delta", "net_down_up_ratio_delta", "net_ab_ratio_pkt_delta", "net_ba_ratio_pkt_delta",
    "net_ab_ratio_byte_delta", "net_ba_ratio_byte_delta", "net_syn_delta", "net_ack_delta", "net_rst_delta",
    "net_flows_with_ab", "net_flows_with_ba", "net_dir_valid_count",
]
STATS = ("mean", "max", "sum", "std", "active_windows")
COLS = ["%s__%s" % (f, s) for f in FEATURES for s in STATS]
DUR = {c for c in COLS if "duration" in c}


def records(f):
    head = f.read(24)
    order, digits = {b"\xd4\xc3\xb2\xa1": ("<", 6), b"\xa1\xb2\xc3\xd4": (">", 6),
                     b"\x4d\x3c\xb2\xa1": ("<", 9), b"\xa1\xb2\x3c\x4d": (">", 9)}[head[:4]]
    rec = struct.Struct(order + "IIII")
    while True:
        h = f.read(16)
        if len(h) < 16:
            return
        sec, frac, incl, _ = rec.unpack(h)
        frame = f.read(incl)
        micros = frac if digits == 6 else frac // 1000
        ns = sec * 10 ** 9 + (frac * 1000 if digits == 6 else frac)
        yield sec * 1000000 + micros, float(Decimal(sec) + Decimal(frac).scaleb(-digits)), ns, frame


def parse_model(frame):
    """features/switch_model.parse_flow_packet, plus the raw addresses and the IPv4 totalLen."""
    if len(frame) < 14:
        return None
    offset, ethertype, tags = 12, (frame[12] << 8) | frame[13], 0
    while ethertype in (0x8100, 0x88A8):
        tags += 1
        if tags > 2 or len(frame) < offset + 6:
            return None
        offset += 4
        ethertype = (frame[offset] << 8) | frame[offset + 1]
    offset += 2
    if ethertype != 0x0800 or len(frame) < offset + 20 or frame[offset] >> 4 != 4:
        return None
    header = (frame[offset] & 0x0F) * 4
    total = (frame[offset + 2] << 8) | frame[offset + 3]
    protocol = frame[offset + 9]
    if header < 20 or total < header or len(frame) < offset + header or protocol not in (6, 17):
        return None
    if ((frame[offset + 6] & 0x1F) << 8 | frame[offset + 7]) != 0:
        return None
    transport, limit = offset + header, min(len(frame), offset + total)
    if limit < transport + (20 if protocol == 6 else 8):
        return None
    sp = (frame[transport] << 8) | frame[transport + 1]
    dp = (frame[transport + 2] << 8) | frame[transport + 3]
    flags = ((frame[transport + 12] & 0x01) << 8 | frame[transport + 13]) if protocol == 6 else 0
    return (frame[offset + 12:offset + 16], frame[offset + 16:offset + 20], protocol, sp, dp, flags, total,
            tags, header)


def parse_p4_current(frame):
    """What the current IngressParser extracts: EtherType 0x0800 at byte 12, a fixed 20-byte IPv4
    header, TCP/UDP right after it; no version, IHL, fragment or length checks."""
    if len(frame) < 34 or ((frame[12] << 8) | frame[13]) != 0x0800:
        return None
    protocol = frame[23]
    if protocol not in (6, 17) or len(frame) < 34 + (20 if protocol == 6 else 8):
        return None
    sp, dp = (frame[34] << 8) | frame[35], (frame[36] << 8) | frame[37]
    flags = ((frame[46] & 0x01) << 8 | frame[47]) if protocol == 6 else 0
    total = (frame[16] << 8) | frame[17]
    return frame[26:30], frame[30:34], protocol, sp, dp, flags, total


# ---------------------------------------------------------------- the release's model (py3.8 copy)
COUNTERS = ("packets", "bytes", "ab_packets", "ab_bytes", "ba_packets", "ba_bytes", "syn", "ack", "rst")
DELTA_FEATURES = (
    ("net_pkts_total_delta", "packets"), ("net_bytes_total_delta", "bytes"),
    ("net_pkts_ab_delta", "ab_packets"), ("net_bytes_ab_delta", "ab_bytes"),
    ("net_pkts_ba_delta", "ba_packets"), ("net_bytes_ba_delta", "ba_bytes"),
    ("net_syn_delta", "syn"), ("net_ack_delta", "ack"), ("net_rst_delta", "rst"),
)


def derived(out, mins, maxs, durs, nflows, window_s=0.5):
    packets, size = out["net_pkts_total_delta"], out["net_bytes_total_delta"]
    ab_packets, ab_bytes = out["net_pkts_ab_delta"], out["net_bytes_ab_delta"]
    ba_packets, ba_bytes = out["net_pkts_ba_delta"], out["net_bytes_ba_delta"]
    out.update({
        "net_flow_count_seen": nflows,
        "net_min_len_mean": mins[0] / nflows if nflows else 0.0,
        "net_max_len_mean": maxs[0] / nflows if nflows else 0.0,
        "net_min_len_min": mins[1], "net_max_len_max": maxs[1],
        "net_avg_pkt_size_delta": size / packets if packets else 0.0,
        "net_avg_pkt_size_ab_delta": ab_bytes / ab_packets if ab_packets else 0.0,
        "net_avg_pkt_size_ba_delta": ba_bytes / ba_packets if ba_packets else 0.0,
        "net_flow_duration_mean": durs[0] / nflows if nflows else 0.0,
        "net_flow_duration_max": durs[1],
        "net_bytes_per_sec_delta": size / window_s, "net_pkts_per_sec_delta": packets / window_s,
        "net_down_up_ratio_delta": ba_bytes / ab_bytes if ab_bytes else 0.0,
        "net_ab_ratio_pkt_delta": ab_packets / packets if packets else 0.0,
        "net_ba_ratio_pkt_delta": ba_packets / packets if packets else 0.0,
        "net_ab_ratio_byte_delta": ab_bytes / size if size else 0.0,
        "net_ba_ratio_byte_delta": ba_bytes / size if size else 0.0,
    })
    return out


class Model:
    def __init__(self):
        self.first_source, self.state, self.last_seen, self.window_delta = {}, {}, {}, {}

    def update(self, window, ts, p, length):
        source, destination, protocol, sp, dp, flags = p[0], p[1], p[2], p[3], p[4], p[5]
        src, dst = (source, sp), (destination, dp)
        key = (protocol,) + tuple(sorted((src, dst)))
        direction = "ab" if src == self.first_source.setdefault(key, src) else "ba"
        syn, ack, rst = int(bool(flags & 0x02)), int(bool(flags & 0x10)), int(bool(flags & 0x04))
        state = self.state.get(key)
        if state is None:
            state = self.state[key] = dict(dict.fromkeys(COUNTERS, 0), min_len=length, max_len=length,
                                           first_ts=ts, last_ts=ts)
        delta = self.window_delta.setdefault(key, dict.fromkeys(COUNTERS, 0))
        for c in (state, delta):
            c["packets"] += 1
            c["bytes"] += length
            c[direction + "_packets"] += 1
            c[direction + "_bytes"] += length
            c["syn"] += syn
            c["ack"] += ack
            c["rst"] += rst
        state["min_len"] = min(state["min_len"], length)
        state["max_len"] = max(state["max_len"], length)
        state["first_ts"] = min(state["first_ts"], ts)
        state["last_ts"] = max(state["last_ts"], ts)
        self.last_seen[key] = max(window, self.last_seen.get(key, window))

    def read_window(self, window):
        out = dict.fromkeys(FEATURES, 0)
        delta, self.window_delta = self.window_delta, {}
        active = [k for k, seen in self.last_seen.items() if 0 <= window - seen <= TTL]
        mins, maxs, durs = [], [], []
        for key in active:
            st = self.state[key]
            for feature, counter in DELTA_FEATURES:
                out[feature] += delta.get(key, {}).get(counter, 0)
            mins.append(st["min_len"])
            maxs.append(st["max_len"])
            durs.append(max(st["last_ts"] - st["first_ts"], 0.0))
            out["net_flows_with_ab"] += int(st["ab_packets"] > 0)
            out["net_flows_with_ba"] += int(st["ba_packets"] > 0)
            out["net_dir_valid_count"] += 1
        return derived(out, (sum(mins), min(mins, default=0)), (sum(maxs), max(maxs, default=0)),
                       (sum(durs), max(durs, default=0.0)), len(active))


# ---------------------------------------------------------------- the current ingress.p4, ideal reads
class Bucket:
    def __init__(self):
        self.b, self.delta = {}, {}

    def update(self, window, ts, p, length):
        sip, dip, proto, sp, dp, flags = p[0], p[1], p[2], p[3], p[4], p[5]
        idx = compute_flow_index(int.from_bytes(sip, "big"), int.from_bytes(dip, "big"), sp, dp, proto)
        b = self.b.get(idx)
        if b is None:
            b = self.b[idx] = dict(ref=(sp, dp), pkts=0, bytes=0, pab=0, bab=0, syn=0, ack=0, rst=0,
                                   min_len=0, max_len=0, first=ts, last=ts, seen=window)
            ab = True
        else:
            ab = not ((sp, dp) != b["ref"] and (sp, dp) == (b["ref"][1], b["ref"][0]))
        d = self.delta.setdefault(idx, dict.fromkeys(COUNTERS, 0))
        syn, ack, rst = int(bool(flags & 0x02)), int(bool(flags & 0x10)), int(bool(flags & 0x04))
        d["packets"] += 1
        d["bytes"] += length
        d["ab_packets" if ab else "ba_packets"] += 1
        d["ab_bytes" if ab else "ba_bytes"] += length
        d["syn"] += syn
        d["ack"] += ack
        d["rst"] += rst
        b["pkts"] += 1
        b["bytes"] += length
        if ab:
            b["pab"] += 1
            b["bab"] += length
        b["min_len"] = length if b["min_len"] == 0 or length < b["min_len"] else b["min_len"]
        b["max_len"] = max(b["max_len"], length)
        b["last"] = ts
        b["seen"] = window

    def read_window(self, window):
        out = dict.fromkeys(FEATURES, 0)
        delta, self.delta = self.delta, {}
        active = [i for i, b in self.b.items() if 0 <= window - b["seen"] <= TTL]
        mins, maxs, durs = [], [], []
        for i in active:
            b = self.b[i]
            for feature, counter in DELTA_FEATURES:
                out[feature] += delta.get(i, {}).get(counter, 0)
            mins.append(b["min_len"])
            maxs.append(b["max_len"])
            durs.append(max(b["last"] - b["first"], 0.0))
            out["net_flows_with_ab"] += int(b["pab"] > 0)
            out["net_flows_with_ba"] += int(b["pkts"] - b["pab"] > 0)
            out["net_dir_valid_count"] += 1
        return derived(out, (sum(mins), min(mins, default=0)), (sum(maxs), max(maxs, default=0)),
                       (sum(durs), max(durs, default=0.0)), len(active))


# ---------------------------------------------------------------- the proposed data-plane design
M32 = (1 << 32) - 1


def canon(p):
    """(key bytes, src_is_smaller) for a flow packet: the key orders the endpoints (address, port)."""
    a, b = (p[0], p[3]), (p[1], p[4])
    lo, hi = (a, b) if a <= b else (b, a)
    key = bytes([p[2]]) + lo[0] + lo[1].to_bytes(2, "big") + hi[0] + hi[1].to_bytes(2, "big")
    return key, a < b


class Banked:
    """Tagged two-bank registers: entry (bank, sub) = [tag, value]; an entry whose tag is not the
    packet's epoch restarts from the identity first (the data plane's self-reset)."""

    def __init__(self, ident=0, op="add", mask=M32):
        self.r, self.ident, self.op, self.mask = {}, ident, op, mask

    def apply(self, epoch, sub, x):
        k = (epoch & 1, sub)
        e = self.r.get(k)
        if e is None or e[0] != epoch:
            e = self.r[k] = [epoch, self.ident]
        if self.op == "add":
            e[1] = (e[1] + x) & self.mask if self.mask else e[1] + x
        elif self.op == "min":
            e[1] = min(e[1], x)
        else:
            e[1] = max(e[1], x)

    def read(self, epoch, sub):
        e = self.r.get((epoch & 1, sub))
        return e[1] if e is not None and e[0] == epoch else self.ident


class DataPlane:
    """Registers and per-packet logic of the proposed program; read_window() is the control plane."""

    def __init__(self, ways=4, slots=16384, frame_bytes=False, time_shift=16, pad_to=()):
        """time_shift: the timestamps the program keeps are ingress_mac_tstamp >> time_shift (20: units of
        1.048576 ms, so that the duration sums fit 32 bits); 0 with frame_bytes checks the algebra
        with exact nanoseconds and unbounded sums."""
        self.ways, self.slots, self.frame_bytes, self.shift = ways, slots, frame_bytes, time_shift
        self.unit_s = (1 << time_shift) / 1e9
        self.pad_to = {bytes(map(int, a.split("."))) for a in pad_to}   # frame_len: >= 46 B IPv4 toward these
        self.sig = [dict() for _ in range(ways)]
        self.ref, self.seen, self.ba, self.minl, self.maxl, self.first, self.last = ({} for _ in range(7))
        self.tot = {k: Banked() for k in ("pkts_ab", "bytes_ab", "pkts_ba", "bytes_ba", "syn", "ack", "rst")}
        self.cnt, self.bec = Banked(), Banked()
        dmask = M32 if time_shift else None
        self.sin = {k: Banked(mask=(M32 if k != "dur" else dmask)) for k in ("min", "max", "dur")}
        self.sout = {k: Banked(mask=(M32 if k != "dur" else dmask)) for k in ("min", "max", "dur")}
        self.pmin, self.pmax, self.pdur = Banked(0xFFFF, "min"), Banked(0, "max"), Banked(0, "max")
        self.overflow_pkts = 0
        self.hist = {}          # epoch -> what the control plane read of it

    def slot(self, key):
        sig = zlib.crc32(key, 0x5A5A5A5A) or 1
        for w in range(self.ways):
            i = zlib.crc32(key, 0x1000193 * (w + 1)) % self.slots
            v = self.sig[w].get(i, 0)
            if v == 0:
                self.sig[w][i] = sig
                return w * self.slots + i, True
            if v == sig:
                return w * self.slots + i, False
        return None, False

    def update(self, window, ts_ns, p, frame_len):
        e = window + 1                                   # epoch: the window markers' count
        L = frame_len if self.frame_bytes else p[6]      # the switch adds 14 B per packet off-switch
        if not self.frame_bytes and p[1] in self.pad_to:
            L = max(L, 46)
        key, smaller = canon(p)
        s, new = self.slot(key)
        if s is None:
            self.overflow_pkts += 1
            ab = True
        elif new:
            self.ref[s] = smaller
            ab = True
        else:
            ab = self.ref[s] == smaller
        flags = p[5]
        t = self.tot
        t["pkts_ab" if ab else "pkts_ba"].apply(e, 0, 1)
        t["bytes_ab" if ab else "bytes_ba"].apply(e, 0, L)
        for name, bit in (("syn", 0x02), ("ack", 0x10), ("rst", 0x04)):
            if flags & bit:
                t[name].apply(e, 0, 1)
        if s is None:
            return
        ts = ts_ns >> self.shift                            # ingress timestamp in the program's units
        old_seen = self.seen.get(s, 0)
        self.seen[s] = e
        old_ba = self.ba.get(s, 0)
        if not ab:
            self.ba[s] = 1
        became = old_ba == 0 and not ab
        first_touch = new or old_seen != e
        d = e - old_seen if not new else 1 << 30
        cls = d if 1 <= d <= TTL else 0
        old_min, old_max = self.minl.get(s), self.maxl.get(s)
        new_min = L if new else min(old_min, L)
        new_max = L if new else max(old_max, L)
        self.minl[s], self.maxl[s] = new_min, new_max
        if new:
            self.first[s] = ts
        first = self.first[s]
        old_last = self.last.get(s, ts)
        self.last[s] = ts
        dur_new, dur_old = ts - first, old_last - first
        if first_touch:
            self.cnt.apply(e, (old_ba, cls), 1)
        if became:
            self.bec.apply(e, 0, 1)
        for name, nv, ov in (("min", new_min, old_min), ("max", new_max, old_max), ("dur", dur_new, dur_old)):
            self.sin[name].apply(e, 0, nv if first_touch else nv - ov)
            if first_touch and cls:
                self.sout[name].apply(e, cls, ov)
        self.pmin.apply(e, 0, new_min)
        self.pmax.apply(e, 0, new_max)
        self.pdur.apply(e, 0, dur_new)

    def read_window(self, window):
        """Control plane: read bank (e & 1) while the data plane counts in the other one."""
        e = window + 1
        r = dict(tot={k: v.read(e, 0) for k, v in self.tot.items()},
                 cnt={(b, c): self.cnt.read(e, (b, c)) for b in (0, 1) for c in range(TTL + 1)},
                 bec=self.bec.read(e, 0),
                 sin={k: v.read(e, 0) for k, v in self.sin.items()},
                 sout={k: {c: v.read(e, c) for c in range(1, TTL + 1)} for k, v in self.sout.items()},
                 pmin=self.pmin.read(e, 0), pmax=self.pmax.read(e, 0), pdur=self.pdur.read(e, 0))
        self.hist[e] = r
        H = self.hist
        js = [j for j in range(e - TTL, e + 1) if j in H]

        def live(total_of, out_of):
            s = 0
            for j in js:
                s += total_of(H[j])
                for k in range(j + 1, e + 1):
                    s -= out_of(H[k], k - j)
            return s

        n = live(lambda h: sum(h["cnt"].values()), lambda h, c: h["cnt"][(0, c)] + h["cnt"][(1, c)])
        nba = live(lambda h: sum(h["cnt"][(1, c)] for c in range(TTL + 1)) + h["bec"],
                   lambda h, c: h["cnt"][(1, c)])
        sums = {}
        for name in ("min", "max", "dur"):
            v = live(lambda h: h["sin"][name], lambda h, c: h["sout"][name][c])
            sums[name] = v & M32 if (name != "dur" or self.shift) else v
        hdr = 0 if self.frame_bytes else HDR
        pmin = min((H[j]["pmin"] for j in js), default=0xFFFF)
        pmax = max((H[j]["pmax"] for j in js), default=0)
        pdur = max((H[j]["pdur"] for j in js), default=0)
        tt = r["tot"]
        out = dict.fromkeys(FEATURES, 0)
        out["net_pkts_ab_delta"], out["net_pkts_ba_delta"] = tt["pkts_ab"], tt["pkts_ba"]
        out["net_pkts_total_delta"] = tt["pkts_ab"] + tt["pkts_ba"]
        out["net_bytes_ab_delta"] = tt["bytes_ab"] + hdr * tt["pkts_ab"]
        out["net_bytes_ba_delta"] = tt["bytes_ba"] + hdr * tt["pkts_ba"]
        out["net_bytes_total_delta"] = out["net_bytes_ab_delta"] + out["net_bytes_ba_delta"]
        out["net_syn_delta"], out["net_ack_delta"], out["net_rst_delta"] = tt["syn"], tt["ack"], tt["rst"]
        out["net_flows_with_ab"] = out["net_dir_valid_count"] = n
        out["net_flows_with_ba"] = nba
        return derived(out, (sums["min"] + hdr * n, pmin + hdr if n else 0),
                       (sums["max"] + hdr * n, pmax + hdr if n else 0),
                       (sums["dur"] * self.unit_s, pdur * self.unit_s if n else 0.0), n)


class DataPlaneHW:
    """perf/variants/exact as compiled: the registers (ingress.p4's names and index layout) and the
    per-packet logic, read as window_reader.py --follow reads them and rebuilt by window_features.py."""

    def __init__(self, ways=4, way_bits=14, pad_to=(), time_shift=16):
        sys.path.insert(0, "/home/admin/Desktop/hAZIM/p4_ebpf/thesis-hybrid-ebpf-p4/python")
        from window_features import WindowFeatures
        self.wf = WindowFeatures()
        self.ways, self.wslots, self.shift = ways, 1 << way_bits, time_shift
        self.pad_to = {bytes(map(int, a.split("."))) for a in pad_to}
        self.way = [dict() for _ in range(ways)]
        self.ref, self.seen, self.ba, self.minl, self.maxl, self.first, self.last = ({} for _ in range(7))
        self.r = {}                      # (register, index) -> int or [lo, hi]
        self.overflow_pkts = 0

    def _add(self, reg, idx, lo, hi=None):
        k = (reg, idx)
        if hi is None:
            self.r[k] = (self.r.get(k, 0) + lo) & M32
        else:
            v = self.r.setdefault(k, [0, 0])
            v[0], v[1] = (v[0] + lo) & M32, (v[1] + hi) & M32

    def _max(self, reg, idx, lo, hi=None):
        k = (reg, idx)
        if hi is None:
            self.r[k] = max(self.r.get(k, 0), lo)
        else:
            v = self.r.setdefault(k, [0, 0])
            v[0], v[1] = max(v[0], lo), max(v[1], hi)

    def update(self, window, ts_ns, p, frame_len):
        e = window + 1
        b = e & 1
        e16 = e & 0xFFFF
        t = (ts_ns >> self.shift) & M32
        L = p[6]
        if p[1] in self.pad_to:
            L = max(L, 46)
        self._max("reg_w_pb", b, 0xFFFF - L, L)
        flags = p[5]
        self._add("reg_w_flags", b, int(bool(flags & 0x02)), int(bool(flags & 0x10)))
        if flags & 0x04:
            self._add("reg_w_rst", b, 1)
        key, smaller = canon(p)
        sig = zlib.crc32(key, 0x5A5A5A5A) or 1
        s, new = None, False
        for w in range(self.ways):
            i = zlib.crc32(key, 0x1000193 * (w + 1)) % self.wslots
            v = self.way[w].get(i, 0)
            if v == 0:
                self.way[w][i] = sig
                s, new = w * self.wslots + i, True
                break
            if v == sig:
                s = w * self.wslots + i
                break
        found = int(s is not None)
        dir_ab = 1
        if found:
            if new:
                self.ref[s] = smaller
                self.seen[s] = e16
                self.minl[s] = self.maxl[s] = L
                old_min = old_max = L
                self.first[s] = first = t
                self.last[s] = old_last = t
                code = 4
            else:
                dir_ab = int(self.ref[s] == smaller)
                d = (e16 - self.seen[s]) & 0xFFFF
                code = 4 if d > TTL else d
                self.seen[s] = e16
                old_min, old_max = self.minl[s], self.maxl[s]
                self.minl[s], self.maxl[s] = min(old_min, L), max(old_max, L)
                first = self.first[s]
                old_last = self.last[s]
                self.last[s] = t
            ba_old = self.ba.get(s, 0)
            if dir_ab == 0:
                self.ba[s] = 1
            dec, inc = max(old_min - L, 0), max(L - old_max, 0)
            gap, dur_old, dur_new = (t - old_last) & M32, (old_last - first) & M32, (t - first) & M32
            self._add("reg_w_chg_len", b, -dec, inc)
            self._add("reg_w_chg_dur", b, gap)
            if code:
                self._add("reg_w_carry_len", (b << 2) | (code & 3), old_min, old_max)
                self._add("reg_w_carry_dur", (b << 2) | (code & 3), dur_old)
                self._add("reg_w_cnt", (b << 5) | (code << 2) | (ba_old << 1) | dir_ab, 1)
            elif ba_old == 0 and dir_ab == 0:
                self._add("reg_w_cnt", b << 5, 1)
            self._max("reg_w_pa", b, 0xFFFF - old_min, old_max)
            self._max("reg_w_pd", b, dur_new)
        else:
            self.overflow_pkts += 1
        self._add("reg_w_tot", (b << 2) | (found << 1) | dir_ab, 1, L)

    def read_window(self, window):
        sys.path.insert(0, "/home/admin/Desktop/hAZIM/p4_ebpf/thesis-hybrid-ebpf-p4/python")
        from window_reader import WINDOW_REGS, EXTREMES
        e = window + 1
        b = e & 1
        regs = {}
        for name, pair, how, idx in WINDOW_REGS:
            regs[name] = {str(i): (list(self.r.get((name, i), [0, 0])) if pair else self.r.get((name, i), 0))
                          for i in idx(b)}
        for name in EXTREMES:
            for i in [x for x in WINDOW_REGS if x[0] == name][0][3](b):
                self.r.pop((name, i), None)
        f = self.wf.add({"epoch": e, "regs": regs, "lost": False})
        return {k: f[k] for k in FEATURES}


def summarize(windows):
    out = {}
    for f in FEATURES:
        v = np.asarray([float(w[f]) for w in windows])
        st = {"mean": v.mean(), "max": v.max(), "sum": v.sum(), "std": v.std(),
              "active_windows": float((v != 0).sum())}
        for s in STATS:
            out["%s__%s" % (f, s)] = float(st[s])
    return out


def exact(a, b, tol=1e-9):
    a, b = float(a), float(b)
    return abs(a - b) <= tol * max(1.0, abs(a), abs(b))


LAYOUTS = [(1, 65536), (2, 32768), (3, 16384), (4, 16384), (3, 32768), (4, 32768)]


def table_overflow(keys, ways, slots):
    tabs = [set() for _ in range(ways)]
    lost = 0
    for key in keys:
        for w in range(ways):
            i = zlib.crc32(key, 0x1000193 * (w + 1)) % slots
            if i not in tabs[w]:
                tabs[w].add(i)
                break
        else:
            lost += 1
    return lost


def analyse(eid, f, anchor_us, published):
    sims = dict(model=Model(), bucket=Bucket(), dp_frame=DataPlane(frame_bytes=True, time_shift=0),
                dp_ipv4=DataPlane(), dp_hw=DataPlaneHW(pad_to=("10.0.0.10",)))
    rows = {k: [] for k in sims}
    cur = 0
    keys, order = set(), []
    cnt = dict(frames=0, model_flow=0, p4_flow=0, vlan=0, ip_options=0, frag_p4_counts=0, p4_only=0,
               model_only=0, ports_differ=0, padded=0, frame_gt_ipv4=0, frame_lt_ipv4=0)
    unordered = {}
    for time_us, ts, ns, frame in records(f):
        off = time_us - anchor_us
        if off < 0 or off // WINDOW_US >= WINDOWS:
            continue
        w = off // WINDOW_US
        while cur < w:
            for k, s in sims.items():
                rows[k].append(s.read_window(cur))
            cur += 1
        cnt["frames"] += 1
        pm, pc = parse_model(frame), parse_p4_current(frame)
        if pm is not None:
            cnt["model_flow"] += 1
            sims["model"].update(w, ts, pm, len(frame))
            sims["dp_frame"].update(w, ns, pm, len(frame))
            sims["dp_ipv4"].update(w, ns, pm, len(frame))
            sims["dp_hw"].update(w, ns, pm, len(frame))
            cnt["vlan"] += pm[7] > 0
            cnt["ip_options"] += pm[8] > 20
            ext = len(frame) - (14 + 4 * pm[7]) - pm[6]
            cnt["frame_gt_ipv4"] += ext > 0
            cnt["frame_lt_ipv4"] += ext < 0
            key, _ = canon(pm)
            if key not in keys:
                keys.add(key)
                order.append(key)
                u = (pm[2], frozenset((pm[0], pm[1])), frozenset((pm[3], pm[4])))
                unordered.setdefault(u, set()).add(key)
        if pc is not None:
            cnt["p4_flow"] += 1
            sims["bucket"].update(w, ts, pc, pc[6] + HDR)
        if pc is not None and pm is None:
            cnt["p4_only"] += 1
        if pm is not None and pc is None:
            cnt["model_only"] += 1
        if pm is not None and pc is not None and (pm[3], pm[4]) != (pc[3], pc[4]):
            cnt["ports_differ"] += 1
    while cur < WINDOWS:
        for k, s in sims.items():
            rows[k].append(s.read_window(cur))
        cur += 1
    res = dict(execution_id=eid, **cnt, flows=len(order),
               unordered_merges=sum(len(v) - 1 for v in unordered.values()),
               dp_overflow_pkts=sims["dp_ipv4"].overflow_pkts,
               max_active_flows=max(r["net_flow_count_seen"] for r in rows["model"]))
    for ways, slots in LAYOUTS:
        res["lost_%dx%d" % (ways, slots)] = table_overflow(order, ways, slots)
    sigs = {}
    for key in order:
        sigs.setdefault(zlib.crc32(key, 0x5A5A5A5A) or 1, []).append(key)
    res["sig_dups"] = sum(len(v) - 1 for v in sigs.values())
    mism = {}
    for k in sims:
        summ = summarize(rows[k])
        if k == "dp_frame":
            # exact ns against the model's float seconds (ulp ~2.4e-7 s at 1.8e9 s): absolute tolerance
            bad = [c for c in COLS if not (exact(summ[c], published[c]) or
                                           (c in DUR and abs(summ[c] - float(published[c])) <= 1e-5))]
        else:
            bad = [c for c in COLS if not exact(summ[c], published[c])]
        res["dur_relerr_" + k] = max((abs(summ[c] - float(published[c])) / max(abs(float(published[c])), 1e-9)
                                      for c in DUR if float(published[c])), default=0.0)
        res["exact145_" + k] = 145 - len(bad)
        res["exact_nodur_" + k] = 135 - len([c for c in bad if c not in DUR])
        mism[k] = sorted({c.split("__")[0] for c in bad})
    res["mismatch"] = mism
    return res


def main():
    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    only = set(sys.argv[2:])
    published = {r["execution_id"]: r for r in csv.DictReader(open(REL / "dataset" / "features.csv"))}
    results = []
    sink = open(out / "gap.jsonl", "a")
    done = set()
    if (out / "gap.jsonl").exists():
        done = {json.loads(l)["execution_id"] for l in open(out / "gap.jsonl") if l.strip()}
    cohort = list(csv.DictReader(open(CAPS / "cohort" / "manifest.csv")))
    for r in cohort:
        eid = r["execution_id"]
        if (only and eid not in only) or eid in done:
            continue
        with open(CAPS / "cohort" / r["capture"], "rb") as f:
            res = analyse(eid, f, int(r["anchor_us"]), published[eid])
        sink.write(json.dumps(res) + "\n")
        sink.flush()
        print(eid[:16], {k: res[k] for k in res if k.startswith("exact145")}, "flows", res["flows"], flush=True)
    import subprocess
    man = subprocess.run(["tar", "xzf", str(CAPS / "cohort-extra.tar.gz"), "-O", "cohort-extra/manifest.csv"],
                         check=True, capture_output=True, text=True).stdout
    extra = {x["capture"]: x for x in csv.DictReader(man.splitlines(True))}
    with tarfile.open(CAPS / "cohort-extra.tar.gz", "r|gz") as tar:
        for m in tar:
            if not m.name.endswith(".pcap"):
                continue
            base = m.name.split("/")[-1]
            r = extra[base]
            eid = r["execution_id"]
            if (only and eid not in only) or eid in done or eid not in published:
                continue
            res = analyse(eid, tar.extractfile(m), int(r["anchor_us"]), published[eid])
            sink.write(json.dumps(res) + "\n")
            sink.flush()
            print(eid[:16], {k: res[k] for k in res if k.startswith("exact145")}, "flows", res["flows"], flush=True)


if __name__ == "__main__":
    main()
