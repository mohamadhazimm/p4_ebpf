import sys, csv, collections, tarfile, subprocess
sys.path.insert(0, ".")
from gap_analysis import records, parse_model, CAPS, WINDOW_US, WINDOWS
from socket import inet_ntoa
tot=collections.Counter(); caps=0; nflow=0
def scan(f, anchor):
    global nflow
    c=collections.Counter()
    for tus, ts, ns, fr in records(f):
        off=tus-anchor
        if off<0 or off//WINDOW_US>=WINDOWS: continue
        p=parse_model(fr)
        if p is None: continue
        nflow+=1
        wire=max(60, 14+p[6])
        if wire!=len(fr): c[(len(fr), 14+p[6], inet_ntoa(p[0]), inet_ntoa(p[1]))]+=1
    return c
for r in csv.DictReader(open(CAPS/"cohort"/"manifest.csv")):
    with open(CAPS/"cohort"/r["capture"],"rb") as f: c=scan(f,int(r["anchor_us"]))
    caps+=1; tot.update(c)
    if c: print(r["execution_id"][:16], c.most_common(3), flush=True)
man=subprocess.run(["tar","xzf",str(CAPS/"cohort-extra.tar.gz"),"-O","cohort-extra/manifest.csv"],capture_output=True,text=True).stdout
extra={x["capture"]:x for x in csv.DictReader(man.splitlines(True))}
with tarfile.open(CAPS/"cohort-extra.tar.gz","r|gz") as tar:
    for m in tar:
        if not m.name.endswith(".pcap"): continue
        r=extra[m.name.split("/")[-1]]
        c=scan(tar.extractfile(m), int(r["anchor_us"])); caps+=1; tot.update(c)
        if c: print(r["execution_id"][:16], c.most_common(3), flush=True)
print("captures", caps, "flow frames", nflow, "frames whose length != max(60, IPv4+14):", sum(tot.values()))
