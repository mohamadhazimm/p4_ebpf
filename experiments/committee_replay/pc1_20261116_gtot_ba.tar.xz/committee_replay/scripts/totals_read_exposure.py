#!/usr/bin/env python3
"""PC1.md part 4f: which runs could the order of the seven totals' reads have changed? On gtot the reader reads
the registers one after another (2.7 ms for seven), so only a packet that reaches the switch while they are
being read can count in one register's cut and not another's. Per run: the sent IPv4 TCP/UDP packets (tx.pcap.gz)
whose time on this host's clock lies inside a window's totals read, widened by half the shortest round trip
(replay_capture.py's bounds). A run with none would read the same totals on basic_gtot_ba.

    python3 totals_read_exposure.py RUNS_DIR [ID ...]     (default: every run in RUNS_DIR)"""
import bisect
import gzip
import json
import struct
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[4] / "live_test"))
from replay_capture import clock_offset, ipv4_l4_len  # noqa: E402


def tx_times(path):
    out = []
    with gzip.open(path, "rb") as f:
        head = f.read(24)
        endian, frac = {b"\xd4\xc3\xb2\xa1": ("<", 1e-6), b"\xa1\xb2\xc3\xd4": (">", 1e-6),
                        b"\x4d\x3c\xb2\xa1": ("<", 1e-9), b"\xa1\xb2\x3c\x4d": (">", 1e-9)}[head[:4]]
        rec = struct.Struct(endian + "IIII")
        while True:
            h = f.read(16)
            if len(h) < 16:
                break
            sec, sub, incl, _orig = rec.unpack(h)
            frame = f.read(incl)
            if ipv4_l4_len(frame) is not None:
                out.append(sec + sub * frac)
    return sorted(out)


def exposure(run):
    records = [r for r in map(json.loads, open(run / "timing.jsonl")) if "window" in r]
    theta, dmin, _ = clock_offset(records)
    u = dmin / 2.0
    times = tx_times(run / "tx.pcap.gz")
    hit_pkts, hit_windows = 0, 0
    for r in records:
        c = r.get("clock") or {}
        if "reader_t_totals_start" not in c:
            continue
        lo, hi = c["reader_t_totals_start"] - theta - u, c["reader_t_totals_end"] - theta + u
        n = bisect.bisect_left(times, hi) - bisect.bisect_left(times, lo)
        hit_pkts += n
        hit_windows += n > 0
    return len(times), hit_pkts, hit_windows


def main():
    root = Path(sys.argv[1])
    ids = sys.argv[2:] or sorted(p.name for p in root.iterdir() if (p / "timing.jsonl").exists())
    for eid in ids:
        sent, pk, wn = exposure(root / eid)
        print("%s\t%d\t%d\t%d" % (eid, sent, pk, wn))


if __name__ == "__main__":
    main()
