#!/usr/bin/env python3
"""PC1.md part 4f: the six floods with B->A packets that were never sent on gtot, rerun on basic_gtot_ba
(-DP4_GLOBAL_TOTALS_SPLIT=1, runs_gtot_ba/), against basic_fix (replay_rows_v3.csv) and gtot with the boundary cut
(runs_gtot_boundary/). Per capture and build: packets in the 40 dataset windows, B->A packets and bytes in them
against the published row, windows with more A->B packets than packets in all, the self-check, and the agreement
with the published row in the 30 B->A columns, the 95 total-based columns and all 145. Writes gtot_ba_compare.csv
and replay_rows_gtot_ba.csv (replay_rows_gtot.csv with these six rows from runs_gtot_ba/)."""
import csv
import json
import statistics as st
from pathlib import Path

R = Path(__file__).resolve().parent.parent
DATASET = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection/dataset/features.csv")
TOTAL_FEATURES = ["net_pkts_total_delta", "net_bytes_total_delta", "net_pkts_ab_delta", "net_bytes_ab_delta",
                  "net_pkts_ba_delta", "net_bytes_ba_delta", "net_avg_pkt_size_delta", "net_avg_pkt_size_ab_delta",
                  "net_avg_pkt_size_ba_delta", "net_bytes_per_sec_delta", "net_pkts_per_sec_delta",
                  "net_down_up_ratio_delta", "net_ab_ratio_pkt_delta", "net_ba_ratio_pkt_delta",
                  "net_ab_ratio_byte_delta", "net_ba_ratio_byte_delta", "net_syn_delta", "net_ack_delta", "net_rst_delta"]
BA_FEATURES = ["net_pkts_ba_delta", "net_bytes_ba_delta", "net_avg_pkt_size_ba_delta", "net_down_up_ratio_delta",
               "net_ba_ratio_pkt_delta", "net_ba_ratio_byte_delta"]
AGGS = ["mean", "max", "sum", "std", "active_windows"]
TOTAL_COLS = ["%s__%s" % (f, a) for f in TOTAL_FEATURES for a in AGGS]
BA_COLS = ["%s__%s" % (f, a) for f in BA_FEATURES for a in AGGS]
IDS = [l.strip() for l in open(R / "scripts" / "gtot_ba_ids.txt") if l.strip()]

published = {r["execution_id"]: r for r in csv.DictReader(open(DATASET))}
v3_list = list(csv.DictReader(open(R / "replay_rows_v3.csv")))
NET_COLS = [c for c in v3_list[0] if c.startswith("net_")]
assert len(NET_COLS) == 145 and len(TOTAL_COLS) == 95 and len(BA_COLS) == 30
ROWS = {"bf": {r["execution_id"]: r for r in v3_list}}
for b, d in (("gtot", "runs_gtot_boundary"), ("ba", "runs_gtot_ba")):
    ROWS[b] = {r["execution_id"]: r for r in csv.DictReader(open(R / d / "rows.csv"))}
DIRS = {"gtot": "runs_gtot_boundary", "ba": "runs_gtot_ba"}


def agreement(row, ref, cols):
    exact, errs = 0, []
    for c in cols:
        a, b = float(row[c]), float(ref[c])
        exact += abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))
        errs.append(abs(a - b) / max(abs(b), 1e-9) if b else (0.0 if a == 0 else 1.0))
    return exact, st.median(errs)


def run_stats(run):
    sc = json.loads((run / "summary.json").read_text())["self_check"]
    w = list(csv.DictReader(open(run / "windows.csv")))
    f = lambda r, k: int(float(r.get(k) or 0))
    return dict(sent=sc["sent_pkts_total"], pkts=sum(f(r, "net_pkts_total_delta") for r in w[4:44]),
                ab_over=sum(f(r, "net_pkts_ab_delta") > f(r, "net_pkts_total_delta") for r in w),
                inside="%d/%d" % (sc["windows_inside_bounds"], sc["windows_checked"]),
                run_exact=int(sc["switch_pkts_total"] == sc["sent_pkts_total"]
                              and sc["switch_bytes_total"] == sc["sent_bytes_total"]),
                cut_ms=(sc.get("totals_read_end_after_window_end_ms") or {}).get("median"))


out = []
for eid in IDS:
    pub = published[eid]
    row = dict(execution_id=eid, pub_ba_pkts=int(float(pub["net_pkts_ba_delta__sum"])),
               pub_ba_bytes=int(float(pub["net_bytes_ba_delta__sum"])))
    for b in ("bf", "gtot", "ba"):
        r = ROWS[b][eid]
        if b != "bf":
            for k, v in run_stats(R / DIRS[b] / eid).items():
                row["%s_%s" % (k, b)] = v
        row["ba_pkts_" + b] = int(float(r["net_pkts_ba_delta__sum"]))
        row["ba_bytes_" + b] = int(float(r["net_bytes_ba_delta__sum"]))
        for name, cols in (("30", BA_COLS), ("95", TOTAL_COLS), ("145", NET_COLS)):
            e, m = agreement(r, pub, cols)
            row["exact%s_%s" % (name, b)], row["mrel%s_%s" % (name, b)] = e, round(m, 6)
    out.append(row)

with open(R / "gtot_ba_compare.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(out[0]))
    wr.writeheader()
    wr.writerows(out)
gtot_rows = list(csv.DictReader(open(R / "replay_rows_gtot.csv")))
with open(R / "replay_rows_gtot_ba.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(gtot_rows[0]))
    wr.writeheader()
    wr.writerows(ROWS["ba"][r["execution_id"]] if r["execution_id"] in IDS else r for r in gtot_rows)
print("wrote gtot_ba_compare.csv and replay_rows_gtot_ba.csv (%d rows, %d from runs_gtot_ba)" % (len(gtot_rows), len(IDS)))

print("%-14s %7s | %-17s | %-21s | %-12s | %-11s | %-11s | %-11s | %s" % (
    "capture", "sent", "seen gtot / ba", "B->A pkts pub/gtot/ba", "A->B>all g/b", "30 bf/g/ba", "95 bf/g/ba",
    "145 bf/g/ba", "self-check gtot, ba"))
for r in out:
    print("%-14s %7d | %7d / %7d | %5d / %5d / %5d | %4d / %4d | %2d /%2d /%2d | %2d /%2d /%2d | %3d/%3d/%3d | %s, %s" % (
        r["execution_id"], r["sent_ba"], r["pkts_gtot"], r["pkts_ba"], r["pub_ba_pkts"], r["ba_pkts_gtot"],
        r["ba_pkts_ba"], r["ab_over_gtot"], r["ab_over_ba"], r["exact30_bf"], r["exact30_gtot"], r["exact30_ba"],
        r["exact95_bf"], r["exact95_gtot"], r["exact95_ba"], r["exact145_bf"], r["exact145_gtot"],
        r["exact145_ba"], r["inside_gtot"], r["inside_ba"]))
print("95-column median relative error, bf / gtot / ba:")
for r in out:
    print("  %-14s %.4f / %.4f / %.4f   run exact gtot %d ba %d   cut median %s / %s ms" % (
        r["execution_id"], r["mrel95_bf"], r["mrel95_gtot"], r["mrel95_ba"], r["run_exact_gtot"], r["run_exact_ba"],
        r["cut_ms_gtot"], r["cut_ms_ba"]))
