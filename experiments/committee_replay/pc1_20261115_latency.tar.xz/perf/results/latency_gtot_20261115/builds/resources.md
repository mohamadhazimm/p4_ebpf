# Phase 1: compile-time resources

Usage over the whole pipe (all MAU stages; ingress and egress share them). MAU latency is the compiler's estimate in pipeline clock cycles.

| variant | status | -D flags | stages ig/eg | crit. path | sram | map ram | tcam | stateful alu | hash bit | gateway | logical table | PHV normal | PHV tagalong | parser TCAM ig/eg | MAU latency ig/eg | power ig/eg (W) | compile wall s | peak RSS MiB |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| baseline_hwl_nonewconn | ok | – | 1/2 | 1 | 1/960 (0.1%) | 0/576 (0.0%) | 0/288 (0.0%) | 0/48 (0.0%) | 10/4992 (0.2%) | 1/192 (0.5%) | 4/192 (2.1%) | 5/64×8b, 9/96×16b, 3/64×32b | 3/32×8b, 10/48×16b, 5/32×32b | 1/8 | 56/172 | 0.10/0.10 | 12.746 | 124 |
| basic_hwl_nonewconn | ok | – | 5/2 | 4 | 197/960 (20.5%) | 196/576 (34.0%) | 3/288 (1.0%) | 14/48 (29.2%) | 172/4992 (3.4%) | 20/192 (10.4%) | 24/192 (12.5%) | 11/64×8b, 19/96×16b, 8/64×32b | 7/32×8b, 20/48×16b, 11/32×32b | 9/8 | 131/172 | 7.49/0.73 | 26.09 | 192 |
| basic_hwl_gtot | ok | – | 6/2 | 4 | 211/960 (22.0%) | 210/576 (36.5%) | 3/288 (1.0%) | 21/48 (43.8%) | 206/4992 (4.1%) | 23/192 (12.0%) | 31/192 (16.1%) | 11/64×8b, 19/96×16b, 8/64×32b | 7/32×8b, 20/48×16b, 11/32×32b | 9/8 | 135/172 | 10.23/0.73 | 26.692 | 201 |

## baseline_hwl_nonewconn: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 1 (1%) | 0 | 0 | 0 | 0 | 10 (2%) | 0 | 0 | 2 (6%) | 2 (2%) | 3 (19%) |
| 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 1 (6%) | 1 (3%) | 2 (2%) | 1 (6%) |

## basic_hwl_nonewconn: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 42 (52%) | 41 (85%) | 3 (12%) | 3 (75%) | 1 (25%) | 42 (10%) | 2 (33%) | 4 (25%) | 3 (9%) | 24 (19%) | 8 (50%) |
| 1 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 16 (4%) | 1 (17%) | 3 (19%) | 1 (3%) | 16 (12%) | 3 (19%) |
| 2 | 44 (55%) | 44 (92%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 21 (16%) | 6 (38%) |
| 3 | 43 (54%) | 43 (90%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 25 (20%) | 5 (31%) |
| 4 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_hwl_nonewconn: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 3 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 4 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 2 | 9 | 9 | 1 |
| Ingress.reg_pkts | 3 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 4 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

## basic_hwl_gtot: per-stage usage

| stage | sram | map ram | tcam | stateful alu | stats alu | hash bit | hash dist unit | gateway | vliw instr | xbar exact byte | logical table |
|---|---|---|---|---|---|---|---|---|---|---|---|
| *capacity* | 80 | 48 | 24 | 4 | 4 | 416 | 6 | 16 | 32 | 128 | 16 |
| 0 | 29 (36%) | 28 (58%) | 3 (12%) | 4 (100%) | 1 (25%) | 42 (10%) | 2 (33%) | 3 (19%) | 3 (9%) | 22 (17%) | 9 (56%) |
| 1 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 16 (4%) | 1 (17%) | 5 (31%) | 1 (3%) | 17 (13%) | 5 (31%) |
| 2 | 37 (46%) | 37 (77%) | 0 | 4 (100%) | 0 | 48 (12%) | 3 (50%) | 6 (38%) | 2 (6%) | 19 (15%) | 6 (38%) |
| 3 | 35 (44%) | 35 (73%) | 0 | 3 (75%) | 0 | 32 (8%) | 2 (33%) | 5 (31%) | 2 (6%) | 29 (23%) | 5 (31%) |
| 4 | 38 (48%) | 38 (79%) | 0 | 4 (100%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 19 (15%) | 4 (25%) |
| 5 | 34 (42%) | 34 (71%) | 0 | 2 (50%) | 0 | 34 (8%) | 1 (17%) | 2 (12%) | 1 (3%) | 17 (13%) | 2 (12%) |

### basic_hwl_gtot: register placement

| register | stage | SRAM | map RAM | stateful ALU |
|---|---|---|---|---|
| Ingress.reg_ack | 1 | 17 | 17 | 1 |
| Ingress.reg_bytes | 4 | 17 | 17 | 1 |
| Ingress.reg_bytes_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_dir_valid | 0 | 5 | 5 | 1 |
| Ingress.reg_first_ts | 3 | 17 | 17 | 1 |
| Ingress.reg_g_ack | 1 | 2 | 2 | 1 |
| Ingress.reg_g_bytes | 0 | 2 | 2 | 1 |
| Ingress.reg_g_bytes_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_pkts | 0 | 2 | 2 | 1 |
| Ingress.reg_g_pkts_ab | 4 | 2 | 2 | 1 |
| Ingress.reg_g_rst | 1 | 2 | 2 | 1 |
| Ingress.reg_g_syn | 2 | 2 | 2 | 1 |
| Ingress.reg_last_ts | 0 | 17 | 17 | 1 |
| Ingress.reg_max_len | 3 | 9 | 9 | 1 |
| Ingress.reg_min_len | 3 | 9 | 9 | 1 |
| Ingress.reg_pkts | 4 | 17 | 17 | 1 |
| Ingress.reg_pkts_ab | 5 | 17 | 17 | 1 |
| Ingress.reg_ref_dst_port | 2 | 9 | 9 | 1 |
| Ingress.reg_ref_src_port | 2 | 9 | 9 | 1 |
| Ingress.reg_rst | 1 | 17 | 17 | 1 |
| Ingress.reg_syn | 2 | 17 | 17 | 1 |

