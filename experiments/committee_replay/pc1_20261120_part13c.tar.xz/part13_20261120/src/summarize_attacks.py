#!/usr/bin/env python3
"""PC1.md part 13: the live attacks of run_attacks.sh, per run directory (one window length each).

Per attack: the alarm (window, probability, its time after that window's end: the block log's alarm against the reader
timing's t_window_end), the block (write time, packets the switch dropped), the packets hping3 sent and got replies to
(its summary line in the collector log), the packets PC2 received (pc2_rx.jsonl), and the scoring time per window.

    summarize_attacks.py RUN_DIR [RUN_DIR ...]      (writes RUN_DIR/summary.json)
"""
import json
import re
import statistics
import sys
from pathlib import Path


def records(path):
    out = []
    for line in open(path):
        line = line.strip()
        if line:
            out.append(json.loads(line))
    return out


def main():
    for d in map(Path, sys.argv[1:]):
        rx = {r["id"]: r for r in records(d / "pc2_rx.jsonl")}
        out = {}
        for ident in rx:
            block = records(d / (ident + ".block.jsonl"))
            ends = {r["window"]: r["t_window_end"] for r in records(d / (ident + ".timing.jsonl")) if "t_window_end" in r}
            alarm = next((r for r in block if r.get("event") == "alarm"), None)
            first_block = next((r for r in block if r.get("event") == "block"), None)
            summary = next((r for r in block if r.get("event") == "summary"), {})
            scores = [r["score_ms"] for r in block if r.get("event") == "score" and "score_ms" in r]
            log = (d / (ident + ".collector.log")).read_text(errors="replace")
            m = re.search(r"(\d+) packets transmitted, (\d+) packets received", log)
            window_s = re.search(r"window_sec=([0-9.]+)", log)
            rec = {"window_s": float(window_s.group(1)) if window_s else None,
                   "alarm_window": alarm["window"] if alarm else None,
                   "alarm_p": alarm["probability"] if alarm else None,
                   "alarm_after_window_end_ms": round((alarm["time"] - ends[alarm["window"]]) * 1e3, 1)
                   if alarm and alarm["window"] in ends else None,
                   "block_write_ms": round((first_block["t_reply"] - first_block["t_request"]) * 1e3, 2)
                   if first_block else None,
                   "dropped": summary.get("blocked_pkts"),
                   "sent": int(m.group(1)) if m else None, "replies": int(m.group(2)) if m else None,
                   "pc2_rx_run": rx[ident]["pc2_rx_run"],
                   "score_ms_median": round(statistics.median(scores), 1) if scores else None,
                   "score_ms_max": max(scores) if scores else None, "windows_scored": len(scores)}
            if rec["sent"] and rec["dropped"] is not None:
                rec["dropped_share"] = round(rec["dropped"] / rec["sent"], 4)
            out[ident] = rec
            print("%s %s: alarm window %s p %s, %s ms after its end; block %s ms; dropped %s of %s (%s); replies %s, "
                  "PC2 rx %s; score %s ms median (max %s)" % (
                      d.name, ident, rec["alarm_window"], rec["alarm_p"], rec["alarm_after_window_end_ms"],
                      rec["block_write_ms"], rec["dropped"], rec["sent"], rec.get("dropped_share"), rec["replies"],
                      rec["pc2_rx_run"], rec["score_ms_median"], rec["score_ms_max"]))
        (d / "summary.json").write_text(json.dumps(out, indent=1) + "\n")


if __name__ == "__main__":
    main()
