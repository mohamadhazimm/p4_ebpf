#!/bin/bash
# PC1.md part 13: live runs through hybrid_collector.py --profile exact on basic_exact_block_v2 at WINDOW_SEC windows
# (20 s of them: 80 at 0.25 s), otherwise as part 12's run_live.sh: CPU-port markers, the dataset's launcher, the eBPF
# host monitor hostmon_agg at the same window, one case per line of CASES (idx, id, group, category, command), each
# from an empty working directory in /dev/shm. Extra arguments go to the collector (e.g. --block-on-alarm ...). A case
# whose CSV exists is skipped. Servers on PC2 behind port 140: servers_log.py (HTTP 8089, echo 9100), banners.py
# (8021, 8023), openssl s_server (8443).
#   run_live.sh OUT_DIR CASES FROM TO WINDOW_SEC [collector options ...]       (as root)
set -u
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
PY=/home/admin/Desktop/hAZIM/p4_ebpf-dataset-construction/.venv/bin/python3
OUT=$1; CASES=$2; FROM=$3; TO=$4; WS=$5; shift 5
NW=$(python3 -c "import sys; n = 20.0 / float(sys.argv[1]); assert abs(n - round(n)) < 1e-9; print(int(round(n)))" "$WS") || exit 2
W=/dev/shm/hz_live_work
mkdir -p "$OUT"
# the dataset launcher runs each program from tempfile.mkdtemp(): keep it (and the programs' outputs) in RAM
export TMPDIR=/dev/shm/hz_live_tmp
mkdir -p "$TMPDIR"
while IFS=$'\t' read -r idx id group cat cmd; do
    [ "$idx" -ge "$FROM" ] && [ "$idx" -le "$TO" ] || continue
    if [ -e "$OUT/$id.csv" ]; then echo "[$idx] $id: done before"; continue; fi
    rm -rf "$W" "$TMPDIR"/sample-launch-*; mkdir -p "$W"; cd "$W"
    t0=$(date +%s)
    "$PY" "$REPO/hybrid_collector.py" --profile exact --mode command --switch-ssh root@172.168.1.2 \
        --forward-int-port 132 --forward-ext-port 140 --cpu-iface enp5s0 --frame-min 192.168.0.1/32 \
        --p4-reader "$REPO/thesis-hybrid-ebpf-p4/python/read_registers_with_index.py" \
        --p4-forwarder "$REPO/thesis-hybrid-ebpf-p4/python/program_forwarding.py" --window-sec "$WS" --windows "$NW" \
        --hostmon "$REPO/ebpf_perf/build/hostmon_agg" --hostmon-cgroup /sys/fs/cgroup/unified/hazim_collect \
        --hostmon-log "$OUT/$id.hostmon.log" "$@" \
        --scenario-name "$id" --label "$cat" --command "$cmd" \
        --out-csv "$OUT/$id.csv" --reader-timing-file "$OUT/$id.timing.jsonl" > "$OUT/$id.collector.log" 2>&1 < /dev/null
    rc=$?
    cd /
    rows=$(($(wc -l < "$OUT/$id.csv" 2>/dev/null || echo 1) - 1))
    echo "[$idx] $id: collector rc $rc, $rows rows, $(grep -o 'HOSTMON_HEALTH.*' "$OUT/$id.hostmon.log" | tail -1)," \
         "$(grep -o 'the command ended with code [-0-9]*' "$OUT/$id.collector.log" | tail -1), $(( $(date +%s) - t0 )) s;" \
         "$(grep -E '^\[BLOCK\] (window [0-9]+: ALARM|alarm at|no alarm)' "$OUT/$id.collector.log" | tr '\n' ' ')"
done < "$CASES"
rm -rf "$W" "$TMPDIR"
chown -R admin:admin "$OUT"
