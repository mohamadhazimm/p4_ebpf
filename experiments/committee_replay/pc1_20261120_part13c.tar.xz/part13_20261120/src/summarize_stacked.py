#!/usr/bin/env python3
"""PC1.md part 13C: the live runs of run_recal_live.sh, per run directory (one window length each).

Per run, from its block log (score, alarm, block and summary events), the reader timing (t_window_end per window),
the CSV (windows written), the collector log (hping3's summary line) and pc2_rx.jsonl:
- the alarm: window, probability, its time after that window's end;
- the highest probability over the run, for a benign run how near it came to an alarm;
- the scoring: per window, the score time and the time from the window's end to its score (does it keep up?);
- the block: write time, packets the switch dropped; hping3's sent and replies; the packets PC2 received.

    summarize_stacked.py RUN_DIR [RUN_DIR ...]      (writes RUN_DIR/summary.json)
"""
import json
import re
import statistics
import sys
from pathlib import Path


def records(path):
    out = []
    if path.exists():
        for line in open(path):
            line = line.strip()
            if line:
                out.append(json.loads(line))
    return out


def q(values, f):
    if not values:
        return None
    s = sorted(values)
    return round(s[min(len(s) - 1, int(f * len(s)))], 1)


def main():
    for d in map(Path, sys.argv[1:]):
        rx = {r["id"]: r for r in records(d / "pc2_rx.jsonl")}
        out = {}
        for ident in rx:
            block = records(d / (ident + ".block.jsonl"))
            ends = {r["window"]: r["t_window_end"] for r in records(d / (ident + ".timing.jsonl")) if "t_window_end" in r}
            scores = [r for r in block if r.get("event") == "score"]
            alarm = next((r for r in block if r.get("event") == "alarm"), None)
            first_block = next((r for r in block if r.get("event") == "block"), None)
            summary = next((r for r in block if r.get("event") == "summary"), {})
            log = (d / (ident + ".collector.log")).read_text(errors="replace")
            m = re.search(r"(\d+) packets transmitted, (\d+) packets received", log)
            trained = re.search(r"detector trained in ([0-9.]+) s", log)
            csv_path = d / (ident + ".csv")
            rows = max(0, len(csv_path.read_text().splitlines()) - 1) if csv_path.exists() else 0
            lags = [(r["time"] - ends[r["window"]]) * 1e3 for r in scores if r["window"] in ends]
            ms = [r["score_ms"] for r in scores if "score_ms" in r]
            rec = {"rows": rows, "windows_scored": len(scores),
                   "trained_s": float(trained.group(1)) if trained else None,
                   "alarm_window": alarm["window"] if alarm else None,
                   "alarm_p": alarm["probability"] if alarm else None,
                   "alarm_after_window_end_ms": round((alarm["time"] - ends[alarm["window"]]) * 1e3, 1)
                   if alarm and alarm["window"] in ends else None,
                   "max_p": max((r["probability"] for r in scores), default=None),
                   "max_p_window": max(scores, key=lambda r: r["probability"])["window"] if scores else None,
                   "score_ms_median": round(statistics.median(ms), 1) if ms else None, "score_ms_p95": q(ms, 0.95),
                   "score_ms_max": max(ms) if ms else None,
                   "score_after_window_end_ms_median": round(statistics.median(lags), 1) if lags else None,
                   "score_after_window_end_ms_max":
                       round(max(lags), 1) if lags else None,
                   "block_write_ms": round((first_block["t_reply"] - first_block["t_request"]) * 1e3, 2)
                   if first_block and "t_reply" in first_block and "t_request" in first_block else None,
                   "dropped": summary.get("blocked_pkts"),
                   "sent": int(m.group(1)) if m else None, "replies": int(m.group(2)) if m else None,
                   "pc2_rx_run": rx[ident]["pc2_rx_run"]}
            if rec["sent"] and rec["dropped"] is not None:
                rec["dropped_share"] = round(rec["dropped"] / rec["sent"], 4)
            out[ident] = rec
            print("%s %-15s rows %s scored %s trained %ss | alarm %s p %s +%s ms | max p %.3f (w%s) | score %s/%s/%s ms "
                  "(med/p95/max), after window end %s/%s ms | block %s ms dropped %s of %s (%s) replies %s PC2 rx %s" % (
                      d.name, ident, rows, len(scores), rec["trained_s"], rec["alarm_window"], rec["alarm_p"],
                      rec["alarm_after_window_end_ms"], rec["max_p"] or 0, rec["max_p_window"], rec["score_ms_median"],
                      rec["score_ms_p95"], rec["score_ms_max"], rec["score_after_window_end_ms_median"],
                      rec["score_after_window_end_ms_max"], rec["block_write_ms"], rec["dropped"], rec["sent"],
                      rec.get("dropped_share"), rec["replies"], rec["pc2_rx_run"]))
        (d / "summary.json").write_text(json.dumps(out, indent=1) + "\n")


if __name__ == "__main__":
    main()
