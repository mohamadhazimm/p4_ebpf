#!/usr/bin/env python3
"""PC1.md part 13: the detectors at 0.25 s against 0.5 s windows, on all 240 dataset runs and the live benign runs.

Part 12C's study (recalibrate.py) at any window count. Per window length LABEL: the dataset's table (0.5 s:
live_test/streaming/dataset_windows.csv.gz; 0.25 s: the network half net_windows_0.25s.csv.gz until the host half
is there, then dataset_windows_0.25s.csv.gz) and the live benign runs at that length (part 12C's at 0.5 s, part 13's
at 0.25 s; their signals are cut to the table's). Folds as 12C: StratifiedGroupKFold(5, shuffle, seed 11) over the
dataset's runs and the live runs present at every length, the same folds at every length. Model A trains on the
dataset runs of the training folds; model B on those plus the live benign runs. Every run is scored after each of its
windows (live_test/streaming/stream_verdicts.py train_arrays: the release's forests on the summaries of a run's first
k windows, at the prefixes of the window length).

Per length, detector and model:
- the dataset's runs: run level (all windows: TPR, TNR, balanced accuracy) and streaming (an alarm in any window: TPR,
  FPR), and the first alarm's time for the attacks (the end of its window): median, malware and floods apart;
- the live benign runs: false alarms, run level and streaming, by group; and the detector as deployed (A trained on
  all 240 dataset runs) on all of them.
A detector that needs host signals is skipped at a length whose table has none.

    evaluate_windows.py OUT_JSON LABEL:DATASET_TABLE:LIVE_TABLE [...] [--detectors network,stacked]   (the .venv)
"""
import csv
import gzip
import json
import sys
from pathlib import Path

import numpy as np
from sklearn.model_selection import StratifiedGroupKFold

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = REPO.parent / "p4-ebpf-malware-detection"
sys.path.insert(0, str(REPO / "live_test" / "streaming"))
sys.path.insert(0, str(RELEASE / "evaluation"))
import common  # noqa: E402
import stream_verdicts as sv  # noqa: E402


def load(path):
    """Run ids, categories, signals, W (n, windows, signals), labels and groups of a window table, in file order."""
    with gzip.open(path, "rt", newline="") as f:
        r = csv.reader(f)
        header = next(r)
        runs, order = {}, []
        for row in r:
            if row[0] not in runs:
                runs[row[0]] = (int(row[1]), row[2], row[3], {})
                order.append(row[0])
            runs[row[0]][3][int(row[5])] = [float(x) for x in row[6:]]
    n = 1 + max(max(v[3]) for v in runs.values())
    W = np.asarray([[runs[e][3][k] for k in range(n)] for e in order])
    return (order, [runs[e][1] for e in order], header[6:], W, np.asarray([runs[e][0] for e in order]),
            np.asarray([runs[e][2] for e in order]))


def scores(model, W, idx, host, net):
    """Probabilities after each window (len(idx), windows)."""
    K = W.shape[1]
    if len(idx) == 0:
        return np.zeros((0, K))
    Xh = np.vstack([np.vstack([sv.summarize(W[i:i + 1, :, host], k) for k in range(1, K + 1)]) for i in idx])
    Xn = np.vstack([np.vstack([sv.summarize(W[i:i + 1, :, net], k) for k in range(1, K + 1)]) for i in idx])
    return np.asarray(model.batch(Xh, Xn)).reshape(len(idx), K)


def rates(P, y):
    run = P[:, -1] >= 0.5
    stream = (P >= 0.5).any(axis=1)
    out = {}
    if (y == 1).any():
        out.update(tpr_run=round(float(run[y == 1].mean()), 4), tpr_stream=round(float(stream[y == 1].mean()), 4))
    if (y == 0).any():
        out.update(fpr_run=round(float(run[y == 0].mean()), 4), fpr_stream=round(float(stream[y == 0].mean()), 4))
    if (y == 1).any() and (y == 0).any():
        out["balanced_accuracy_run"] = round((out["tpr_run"] + 1 - out["fpr_run"]) / 2, 4)
        out["balanced_accuracy_stream"] = round((out["tpr_stream"] + 1 - out["fpr_stream"]) / 2, 4)
    return out


def first_alarms(P, window_s):
    """The end of the first alarmed window (s) of each run, None without an alarm."""
    out = []
    for p in P:
        hit = np.nonzero(p >= 0.5)[0]
        out.append(round(float((hit[0] + 1) * window_s), 4) if len(hit) else None)
    return out


def median(values):
    v = [x for x in values if x is not None]
    return round(float(np.median(v)), 4) if v else None


def main():
    out_path = Path(sys.argv[1])
    specs = [a for a in sys.argv[2:] if not a.startswith("--")]
    detectors = ["network"]
    if "--detectors" in sys.argv:
        detectors = sys.argv[sys.argv.index("--detectors") + 1].split(",")
        specs = [a for a in specs if a != sys.argv[sys.argv.index("--detectors") + 1]]
    lengths = []
    for spec in specs:
        label, table, live = spec.split(":")
        ids, cats, signals, Wd, yd, gd = load(table)
        lids, _, lsig, Wb, yb, gb = load(live)
        lengths.append(dict(label=label, ids=ids, cats=cats, signals=signals, Wd=Wd, yd=yd, gd=gd,
                            live=dict(zip(lids, range(len(lids)))), lsig=lsig, Wb=Wb, yb=yb, gb=gb))
    base = lengths[0]
    for L in lengths[1:]:
        assert L["ids"] == base["ids"], "the dataset tables hold other runs or another order"
    live_ids = [e for e in base["live"] if all(e in L["live"] for L in lengths)]
    result = {"dataset_runs": len(base["ids"]), "live_runs": len(live_ids),
              "live_runs_left_out": sorted(set(e for L in lengths for e in L["live"]) - set(live_ids)), "lengths": {}}
    yl = np.asarray([base["yb"][base["live"][e]] for e in live_ids])
    gl = np.asarray([base["gb"][base["live"][e]] for e in live_ids])
    y = np.concatenate([base["yd"], yl])
    g = np.concatenate([base["gd"], gl])
    live = np.concatenate([np.zeros(len(base["yd"]), bool), np.ones(len(yl), bool)])
    folds = list(StratifiedGroupKFold(5, shuffle=True, random_state=11).split(np.zeros((len(y), 1)), y, g))
    attack = np.asarray([c for c in base["cats"]])
    for L in lengths:
        signals = L["signals"]
        cols = [L["lsig"].index(s) for s in signals]
        Wl = L["Wb"][[L["live"][e] for e in live_ids]][:, :, cols]
        W = np.concatenate([L["Wd"], Wl])
        K = W.shape[1]
        window_s = sv.RUN_S / K
        host = [i for i, s in enumerate(signals) if s.startswith("host_")]
        net = [i for i, s in enumerate(signals) if s.startswith("net_")]
        res_l = {"windows": K, "window_s": window_s, "prefixes": sv.prefixes(K), "detectors": {}}
        for det in detectors:
            if det != "network" and not host:
                res_l["detectors"][det] = "skipped: the table has no host signals"
                continue
            P = {m: np.full((len(y), K), np.nan) for m in ("A", "B")}
            for f, (tr, te) in enumerate(folds):
                tr_d = tr[~live[tr]]
                mA = sv.train_arrays(common, signals, W[tr_d], y[tr_d], g[tr_d], det)[2]
                mB = sv.train_arrays(common, signals, W[tr], y[tr], g[tr], det)[2]
                P["A"][te] = scores(mA, W, te, host, net)
                P["B"][te] = scores(mB, W, te, host, net)
                print("%s %s fold %d: A %d runs, B %d, scored %d" % (L["label"], det, f, len(tr_d), len(tr), len(te)),
                      flush=True)
            n_d = len(base["yd"])
            mA_all = sv.train_arrays(common, signals, W[:n_d], y[:n_d], g[:n_d], det)[2]
            P_dep = scores(mA_all, W, np.arange(n_d, len(y)), host, net)
            res = {"A_all_live_benign": rates(P_dep, yl)}
            for m in ("A", "B"):
                PM = P[m]
                t = first_alarms(PM[:n_d], window_s)
                by_cat = {}
                for c in sorted(set(base["cats"])):
                    sel = [i for i in range(n_d) if attack[i] == c]
                    alarmed = [t[i] for i in sel if t[i] is not None]
                    by_cat[c] = {"runs": len(sel), "alarmed": len(alarmed), "first_alarm_s_median": median(alarmed)}
                by_group = {}
                for grp in sorted(set(gl.tolist())):
                    sel = np.where(live & (g == grp))[0]
                    by_group[grp] = {"runs": int(len(sel)), "alarmed_stream": int((PM[sel] >= 0.5).any(axis=1).sum()),
                                     "alarmed_run": int((PM[sel][:, -1] >= 0.5).sum())}
                res[m] = {"dataset": rates(PM[:n_d], y[:n_d]),
                          "first_alarm_s_attacks_median": median([t[i] for i in range(n_d) if y[i] == 1]),
                          "by_category": by_cat, "live_benign": rates(PM[n_d:], yl), "live_benign_by_group": by_group}
                r = res[m]
                print("%-5s %-8s %s: dataset BA run %.3f stream %.3f (TPR %.3f/%.3f, FPR %.3f/%.3f); first alarm "
                      "median %s s (floods %s, malware %s); live benign FPR run %.3f stream %.3f" % (
                          L["label"], det, m, r["dataset"]["balanced_accuracy_run"],
                          r["dataset"]["balanced_accuracy_stream"], r["dataset"]["tpr_run"],
                          r["dataset"]["tpr_stream"], r["dataset"]["fpr_run"], r["dataset"]["fpr_stream"],
                          r["first_alarm_s_attacks_median"], by_cat.get("network_attack", {}).get("first_alarm_s_median"),
                          by_cat.get("malware", {}).get("first_alarm_s_median"), r["live_benign"]["fpr_run"],
                          r["live_benign"]["fpr_stream"]), flush=True)
            res_l["detectors"][det] = res
            result["lengths"][L["label"]] = res_l
            out_path.write_text(json.dumps(result, indent=1) + "\n")
        result["lengths"][L["label"]] = res_l
    out_path.write_text(json.dumps(result, indent=1) + "\n")


if __name__ == "__main__":
    main()
