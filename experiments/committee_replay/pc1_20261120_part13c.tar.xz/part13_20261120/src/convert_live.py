#!/usr/bin/env python3
"""PC1.md part 13: live collector runs as a window table in the detectors' training format, at any window length.

    convert_live.py CASES_TSV RUNS_DIR LABEL WINDOWS OUT_CSV_GZ

As part 12's convert_live.py, with WINDOWS windows per run (80 at 0.25 s): CASES_TSV is run_live.sh's (idx, id, group,
category, command); each run RUNS_DIR/ID.csv must hold window_id 0..WINDOWS-1, or it is reported and left out. The
signals are the training table's 47 (live_test/streaming/dataset_windows.csv.gz); execution_id "live:ID", split "live".
"""
import csv
import gzip
import sys
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
csv.field_size_limit(sys.maxsize)


def main():
    cases, runs, label, windows, out = (Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3]), int(sys.argv[4]),
                                        Path(sys.argv[5]))
    with gzip.open(REPO / "live_test/streaming/dataset_windows.csv.gz", "rt") as f:
        header = next(csv.reader(f))
    signals = header[6:]
    kept, left = 0, []
    with gzip.open(out, "wt", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        for line in open(cases):
            idx, ident, group, cat, _cmd = line.rstrip("\n").split("\t")
            path = runs / (ident + ".csv")
            if not path.exists():
                left.append((ident, "no csv"))
                continue
            rows = {int(float(r["window_id"])): r for r in csv.DictReader(open(path))}
            if sorted(rows) != list(range(windows)):
                left.append((ident, "%d windows" % len(rows)))
                continue
            for k in range(windows):
                r = rows[k]
                w.writerow(["live:" + ident, label, cat, group, "live", k] + [float(r[s] or 0) for s in signals])
            kept += 1
    print("%d runs written to %s; left out: %s" % (kept, out, left or "none"))


if __name__ == "__main__":
    main()
