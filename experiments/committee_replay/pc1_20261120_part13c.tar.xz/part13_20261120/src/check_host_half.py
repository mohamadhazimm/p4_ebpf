#!/usr/bin/env python3
"""Check the workstation's 0.25 s training table (PC1.md part 13B) on PC1, from the tables alone.

1. Layout: the 0.5 s training table's columns; 240 runs x 80 windows, in the training table's run order; the run
   columns (label, category, cv_group, split) equal the training table's.
2. Network half: every network cell equals PC1's net_windows_0.25s.csv.gz, as text.
3. Host half against the published 0.5 s table (window k at 0.5 s = windows 2k and 2k+1 at 0.25 s), from
   features/host_model.py's definitions (per process p, A and B the two halves, W the 0.5 s window):
   - total calls: W = A + B exactly;
   - transitions: W - (A + B) is the processes in both halves whose calls at the boundary differ: 0 <= d <= min(A, B);
   - unique calls, longest run: max(A, B) <= W <= A + B (maxima over processes);
   - first 50 / 100 unique: A <= W <= A + B;
   - top call frequency, rare ratio: W <= max(A, B) (a ratio of sums is at most the larger ratio);
   - mean run length: W <= A + B; entropy: W <= max(A, B) + 1 bit;
   - empty windows: W has no calls exactly when A and B have none, and then all its host cells are 0.
4. Calls: the sum over all windows (the report says 10,006,454).
"""
import csv
import gzip
import json
import sys
from collections import OrderedDict

import numpy as np

BASE = "/home/admin/Desktop/hAZIM/p4_ebpf/live_test/streaming/"
EPS = 1e-9


def read(path):
    with gzip.open(path, "rt", newline="") as f:
        r = csv.reader(f)
        header = next(r)
        rows = list(r)
    return header, rows


def runs_of(header, rows):
    i = header.index("execution_id")
    w = header.index("window")
    out = OrderedDict()
    for row in rows:
        out.setdefault(row[i], []).append(row)
    for e, rs in out.items():
        assert [int(r[w]) for r in rs] == list(range(len(rs))), e
    return out


def main():
    h05, r05 = read(BASE + "dataset_windows.csv.gz")
    h25, r25 = read(BASE + "dataset_windows_0.25s.csv.gz")
    hn, rn = read(BASE + "net_windows_0.25s.csv.gz")
    res = OrderedDict()
    res["columns_equal"] = h05 == h25
    runs05, runs25, runsn = runs_of(h05, r05), runs_of(h25, r25), runs_of(hn, rn)
    res["runs"] = len(runs25)
    res["windows_per_run"] = sorted({len(v) for v in runs25.values()})
    res["run_order_equal"] = list(runs05) == list(runs25) == list(runsn)
    meta = ["label", "category", "cv_group", "split"]
    mi = [h25.index(c) for c in meta]
    res["run_columns_equal"] = all(
        all(r[j] == runs05[e][0][j] for r in rs for j in mi) for e, rs in runs25.items())

    # 2. network half, as text
    net_cols = [c for c in hn if c.startswith("net_")]
    res["network_columns"] = len(net_cols)
    a = [h25.index(c) for c in net_cols]
    b = [hn.index(c) for c in net_cols]
    bad = 0
    for e in runs25:
        for x, y in zip(runs25[e], runsn[e]):
            bad += sum(x[i] != y[j] for i, j in zip(a, b))
    res["network_cells_differing"] = bad
    res["network_cells"] = len(runs25) * 80 * len(net_cols)

    # 3. host half
    host = [c for c in h25 if c.startswith("host_")]
    res["host_columns"] = len(host)
    idx25 = [h25.index(c) for c in host]
    idx05 = [h05.index(c) for c in host]
    A = np.array([[[float(r[i]) for i in idx25] for r in rs[0::2]] for rs in runs25.values()])
    B = np.array([[[float(r[i]) for i in idx25] for r in rs[1::2]] for rs in runs25.values()])
    W = np.array([[[float(r[i]) for i in idx05] for r in runs05[e]] for e in runs25])
    col = {c: k for k, c in enumerate(host)}

    def c(name):
        k = col[name]
        return A[..., k], B[..., k], W[..., k]

    checks = OrderedDict()
    a_, b_, w_ = c("host_total_syscalls_total")
    checks["total: W == A + B"] = int(np.sum(w_ != a_ + b_))
    ta, tb = a_, b_
    a_, b_, w_ = c("host_transition_count_total")
    d = w_ - (a_ + b_)
    checks["transitions: 0 <= W-(A+B) <= min(callsA, callsB)"] = int(np.sum((d < 0) | (d > np.minimum(ta, tb))))
    for name in ["host_unique_syscalls_max", "host_max_run_length_max"]:
        a_, b_, w_ = c(name)
        checks[name + ": max(A,B) <= W <= A+B"] = int(np.sum((w_ < np.maximum(a_, b_) - EPS) | (w_ > a_ + b_ + EPS)))
    for name in ["host_first50_unique_max", "host_first100_unique_max"]:
        a_, b_, w_ = c(name)
        checks[name + ": A <= W <= A+B"] = int(np.sum((w_ < a_ - EPS) | (w_ > a_ + b_ + EPS)))
    for name in ["host_top_syscall_freq_max", "host_rare_syscall_ratio_max"]:
        a_, b_, w_ = c(name)
        checks[name + ": W <= max(A,B)"] = int(np.sum(w_ > np.maximum(a_, b_) + EPS))
    a_, b_, w_ = c("host_avg_run_length_max")
    checks["host_avg_run_length_max: W <= A+B"] = int(np.sum(w_ > a_ + b_ + EPS))
    a_, b_, w_ = c("host_entropy_max")
    checks["host_entropy_max: W <= max(A,B)+1"] = int(np.sum(w_ > np.maximum(a_, b_) + 1 + EPS))
    empty_w = W[..., col["host_total_syscalls_total"]] == 0
    empty_ab = (ta == 0) & (tb == 0)
    checks["empty: W empty == A and B empty"] = int(np.sum(empty_w != empty_ab))
    allh = np.concatenate([A, B], axis=1)
    calls_h = allh[..., col["host_total_syscalls_total"]]
    checks["empty 0.25 s windows have all host cells 0"] = int(np.sum(np.any(allh[calls_h == 0] != 0, axis=-1)))
    res["host_checks_failing_windows"] = checks
    res["window_pairs"] = int(W.shape[0] * W.shape[1])
    tight = OrderedDict()
    a_, b_, w_ = c("host_transition_count_total")
    tight["transitions lost at the boundary (sum over pairs)"] = int(np.sum(w_ - (a_ + b_)))
    tight["transitions at 0.5 s (sum)"] = int(np.sum(w_))
    res["notes"] = tight
    res["calls_0.25s"] = int(calls_h.sum())
    res["calls_0.5s"] = int(W[..., col["host_total_syscalls_total"]].sum())
    res["runs_with_calls"] = int(np.sum(calls_h.sum(axis=1) > 0))
    print(json.dumps(res, indent=1))
    ok = (res["columns_equal"] and res["run_order_equal"] and res["run_columns_equal"] and res["runs"] == 240
          and res["windows_per_run"] == [80] and bad == 0 and not any(checks.values()))
    print("ALL OK" if ok else "FAILED")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
