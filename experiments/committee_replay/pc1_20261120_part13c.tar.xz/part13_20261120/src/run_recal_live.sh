#!/bin/bash
# PC1.md part 13: part 12E's live loop at WINDOW_SEC windows. The detector (default stacked) is trained on the
# dataset's table at that length (block_policy.default_table) plus the live benign runs at that length
# (EXTRA_WINDOWS_CSV_GZ: --block-train-extra), with a host block at the alarm. A benign workload runs with its own live
# group held out (--block-hold-out-group), so its verdict is out of sample; an attack has no live group in the table.
# PC2's eth1 receive counter is read around each run, as run_attacks.sh does.
#   run_recal_live.sh OUT_DIR CASES WINDOW_SEC EXTRA_WINDOWS_CSV_GZ [DETECTOR]       (as admin)
set -u
R=/home/admin/Desktop/hAZIM/p4_ebpf/perf/results/part13_20261120
ASROOT=/tmp/claude-1000/-home-admin-Desktop-hAZIM/dd29711f-6d0a-47d6-8c92-d2a98cd93247/scratchpad/asroot.sh
# absolute paths: run_live.sh runs each case from a working directory in /dev/shm
OUT=$(realpath -m "$1"); CASES=$(realpath "$2"); WS=$3; EXTRA=$(realpath "$4"); DET=${5:-stacked}
mkdir -p "$OUT"
rx() { timeout 20 ssh -n -o BatchMode=yes admin@192.168.0.2 'cat /sys/class/net/eth1/statistics/rx_packets'; }
while IFS=$'\t' read -r idx id group cat cmd; do
    ho=()
    case "$group" in live::attack-*) ;; *) ho=(--block-hold-out-group "$group") ;; esac
    a=$(rx); b=$(rx)
    "$ASROOT" bash "$R/src/run_live.sh" "$OUT" "$CASES" "$idx" "$idx" "$WS" --block-on-alarm --block-detector "$DET" \
        --block-host 192.168.0.1 --block-train-extra "$EXTRA" "${ho[@]}" < /dev/null
    sleep 3
    c=$(rx)
    echo "{\"id\": \"$id\", \"pc2_rx_before\": [$a, $b], \"pc2_rx_after\": $c, \"pc2_rx_run\": $((c - b - (b - a)))}" \
        | tee -a "$OUT/pc2_rx.jsonl"
done < "$CASES"
