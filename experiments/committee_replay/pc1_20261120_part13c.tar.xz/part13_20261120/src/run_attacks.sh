#!/bin/bash
# PC1.md part 13: part 12D's live attacks (hping3 from PC1 in the monitored cgroup to PC2) at WINDOW_SEC windows, one
# at a time, with PC2's eth1 receive counter read before (twice: the second read minus the first is what one ssh read
# adds) and after each run. Extra arguments go to the collector (the detector and block options).
#   run_attacks.sh OUT_DIR CASES WINDOW_SEC [collector options ...]           (as admin; run_live.sh goes through ASROOT)
set -u
R=/home/admin/Desktop/hAZIM/p4_ebpf/perf/results/part13_20261120
ASROOT=/tmp/claude-1000/-home-admin-Desktop-hAZIM/dd29711f-6d0a-47d6-8c92-d2a98cd93247/scratchpad/asroot.sh
OUT=$1; CASES=$2; WS=$3; shift 3
mkdir -p "$OUT"
rx() { timeout 20 ssh -n -o BatchMode=yes admin@192.168.0.2 'cat /sys/class/net/eth1/statistics/rx_packets'; }
while IFS=$'\t' read -r idx id group cat cmd; do
    a=$(rx); b=$(rx)
    "$ASROOT" bash "$R/src/run_live.sh" "$OUT" "$CASES" "$idx" "$idx" "$WS" "$@" < /dev/null
    sleep 3
    c=$(rx)
    echo "{\"id\": \"$id\", \"pc2_rx_before\": [$a, $b], \"pc2_rx_after\": $c, \"pc2_rx_run\": $((c - b - (b - a)))}" \
        | tee -a "$OUT/pc2_rx.jsonl"
done < "$CASES"
