#!/bin/bash
# PC1.md part 12B on the switch: captures replayed through basic_exact_block_v2 at 0.1 s (200 windows) and 0.25 s
# (80 windows) with live_test/exact_replay.py (the replayer's in-band markers at each boundary; the reader follows the
# switch's clock), compared with the switch model's windows at the same length (compare_ws.py).
set -u
REPO=/home/admin/Desktop/hAZIM/p4_ebpf
R=$REPO/perf/results/part12_20261119
ASROOT=$REPO/perf/results/committee_replay/scripts/asroot.sh
cd "$REPO"
run() {   # ID CAPTURE ANCHOR_US WINDOW_US WINDOWS TABLE
    out=$R/short_windows/$1_$4
    /usr/bin/python3 live_test/exact_replay.py "$2" --anchor-us "$3" --out "$out" --asroot "$ASROOT" --execution-id "$1" \
        --window-us "$4" --windows "$5" > "$out.log" 2>&1
    echo "$1 at $4 us: rc $? $(/usr/bin/python3 "$R/src/compare_ws.py" "$out" "$R/windows/$6" "$1")"
}
C=0004b57f7671cb3dbc993e632279e883d138ea72a271b3ab84637c918e391023
run $C live_test/captures/cohort/$C.pcap 1792932220606770 100000 200 windows_0.1.csv.gz
run bulk2000 /dev/shm/hz_sw/bulk2000.pcap 1793028045728957 100000 200 windows_0.1.csv.gz
run syn_fan_40k /dev/shm/hz_sw/syn_fan_40k.pcap 1793033859742639 100000 200 windows_0.1.csv.gz
run udp_sink_60k /dev/shm/hz_sw/udp_sink_60k.pcap 1793034227552301 100000 200 windows_0.1.csv.gz
run bulk2000 /dev/shm/hz_sw/bulk2000.pcap 1793028045728957 250000 80 windows_0.25.csv.gz
