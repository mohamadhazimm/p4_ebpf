#!/usr/bin/env python3
"""PC1.md part 12B: the switch's windows at a shorter window length against the switch model's.

    compare_ws.py RUN_DIR WINDOWS_CSV_GZ EXECUTION_ID

RUN_DIR: an exact_replay.py run with --window-us W --windows N (its windows.csv); WINDOWS_CSV_GZ: compute_windows.py's
table at the same length. Prints how many windows equal the model's in every non-duration feature (durations are the
switch clock's, in 65.536 us units, and follow the replay's timing) and the run's read timing (lost windows)."""
import csv
import gzip
import json
import sys
from pathlib import Path

csv.field_size_limit(sys.maxsize)


def main():
    run, table, eid = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
    mine = {int(float(r["window"])): r for r in csv.DictReader(open(run / "windows.csv"))}
    model = {}
    with gzip.open(table, "rt") as f:
        for r in csv.DictReader(f):
            if r["execution_id"] == eid:
                model[int(r["window"])] = r
    feats = [c for c in next(iter(model.values())) if c.startswith("net_") and "duration" not in c]
    bad = {}
    for w in sorted(model):
        m = mine.get(w)
        if m is None:
            bad[w] = "missing"
            continue
        d = [c for c in feats if abs(float(m.get(c) or 0) - float(model[w][c] or 0)) > 1e-6 * max(1.0, abs(float(model[w][c] or 0)))]
        if d:
            bad[w] = {c: [m.get(c), model[w][c]] for c in d[:4]}
    s = json.loads((run / "summary.json").read_text()) if (run / "summary.json").exists() else {}
    out = {"windows": len(model), "equal": len(model) - len(bad), "features": len(feats), "differing": dict(list(bad.items())[:5]),
           "windows_lost": s.get("windows_lost"), "untracked_pkts": s.get("untracked_pkts")}
    print(json.dumps(out))


if __name__ == "__main__":
    main()
