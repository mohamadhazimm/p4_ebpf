#!/usr/bin/env python3
"""PC1.md part 12A: the 109 replays on the final build (run_replays_109.py OUT_DIR): rows and verdicts.

Rows: OUT_DIR/rows.csv against the published rows (the release's dataset/features.csv) in the 135 non-duration
network columns and in all 145, and against part 6b's rows of basic_exact_v3 (exact_collector/
replay_rows_exact_collector.csv). Verdicts (the network detector without the capture's group, a host block on
10.0.0.10 at the alarm): attacks alarmed, benign runs alarmed, the alarm's dataset window and its delay after that
window's end, and the share of the host's frames (the capture's own timeline, from its manifest anchor) sent after the
block's reply, measured from the replay's anchor on this host's clock.

    summarize_109.py OUT_DIR       (writes OUT_DIR/summary_109.json; the .venv)
"""
import csv
import json
import statistics as st
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import study_windows  # noqa: E402  host_bins

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
PUBLISHED = REPO.parent / "p4-ebpf-malware-detection" / "dataset" / "features.csv"
V3 = REPO / "perf/results/exact_collector/replay_rows_exact_collector.csv"
csv.field_size_limit(sys.maxsize)


def equal(a, b):
    try:
        x, y = float(a), float(b)
    except (TypeError, ValueError):
        return a == b
    return x == y or abs(x - y) <= 1e-9 * max(1.0, abs(x), abs(y))


def main():
    out = Path(sys.argv[1])
    rows = {r["execution_id"]: r for r in csv.DictReader(open(out / "rows.csv"))}
    pub = {r["execution_id"]: r for r in csv.DictReader(open(PUBLISHED))}
    v3 = {r["execution_id"]: r for r in csv.DictReader(open(V3))}
    net = [c for c in next(iter(rows.values())) if c.startswith("net_")]
    nodur = [c for c in net if "duration" not in c]
    prog = {}
    for line in open(out / "progress.jsonl"):
        r = json.loads(line)
        prog[r["execution_id"]] = r            # the last line of a capture run again
    bins = study_windows.host_bins()
    per = []
    for eid, p in prog.items():
        row = rows.get(eid)
        rec = dict(execution_id=eid, label=int(p["label"]), category=p["category"],
                   windows_exact="%s/%s" % (p.get("windows_exact"), p.get("windows_checked")),
                   pkts_exact=p.get("switch_pkts_total") == p.get("sent_pkts_total"))
        if row is not None:
            rec["published_equal_135"] = sum(equal(row[c], pub[eid][c]) for c in nodur) if eid in pub else None
            rec["published_equal_145"] = sum(equal(row[c], pub[eid][c]) for c in net) if eid in pub else None
            rec["v3_equal_135"] = sum(equal(row[c], v3[eid][c]) for c in nodur) if eid in v3 else None
        rec.update(alarm_window=p.get("alarm_window"), alarm_p=p.get("alarm_p"), max_p=p.get("max_p"),
                   blocked_pkts=p.get("blocked_pkts"))
        anchor = p.get("anchor_on_this_clock")
        if p.get("alarm_time") is not None and anchor:
            rec["alarm_after_window_end_ms"] = round((p["alarm_time"] - (anchor + (p["alarm_window"] + 1) * 0.5)) * 1e3, 1)
            rec["block_reply_s"] = round(p["block_t_reply"] - anchor, 4)
            b = bins.get(eid)
            if b is not None and b.sum() > 0:
                rec["host_frames_after_block"] = round(float(b[int(round(rec["block_reply_s"] / study_windows.BIN_S)):].sum() / b.sum()), 4)
        per.append(rec)
    att = [r for r in per if r["label"] == 1]
    ben = [r for r in per if r["label"] == 0]
    cats = sorted(set(r["category"] for r in per))
    summary = dict(
        captures=len(per),
        replay_exact=sum(1 for r in per if r["windows_exact"].split("/")[0] == r["windows_exact"].split("/")[1] and r["pkts_exact"]),
        rows=len(rows),
        rows_equal_published_135=sum(1 for r in per if r.get("published_equal_135") == len(nodur)),
        rows_equal_published_145=sum(1 for r in per if r.get("published_equal_145") == len(net)),
        rows_equal_v3_135=sum(1 for r in per if r.get("v3_equal_135") == len(nodur)),
        mean_published_equal_135=round(st.mean(r["published_equal_135"] for r in per if r.get("published_equal_135") is not None), 2),
        attacks=len(att), attacks_alarmed=sum(1 for r in att if r["alarm_window"] is not None),
        benign=len(ben), benign_alarmed=sum(1 for r in ben if r["alarm_window"] is not None),
        by_category={c: dict(runs=sum(1 for r in per if r["category"] == c),
                             alarmed=sum(1 for r in per if r["category"] == c and r["alarm_window"] is not None))
                     for c in cats},
        alarm_window_counts={str(w): sum(1 for r in att if r["alarm_window"] == w)
                             for w in sorted(set(r["alarm_window"] for r in att if r["alarm_window"] is not None))},
        alarm_after_window_end_ms_median=st.median(r["alarm_after_window_end_ms"] for r in att if "alarm_after_window_end_ms" in r),
        host_frames_after_block_attacks_mean=round(st.mean(r["host_frames_after_block"] for r in att if "host_frames_after_block" in r), 4),
        host_frames_after_block_floods={r["execution_id"]: r.get("host_frames_after_block") for r in att
                                        if r["category"] == "network_attack"},
        false_alarms=[dict(execution_id=r["execution_id"], category=r["category"], alarm_window=r["alarm_window"],
                           alarm_p=r["alarm_p"], host_frames_after_block=r.get("host_frames_after_block"))
                      for r in ben if r["alarm_window"] is not None],
        rows_not_equal_published=[(r["execution_id"], r.get("published_equal_135")) for r in per
                                  if r.get("published_equal_135") is not None and r["published_equal_135"] < len(nodur)])
    (out / "summary_109.json").write_text(json.dumps(dict(summary=summary, runs=per), indent=1) + "\n")
    print(json.dumps(summary, indent=1))


if __name__ == "__main__":
    main()
