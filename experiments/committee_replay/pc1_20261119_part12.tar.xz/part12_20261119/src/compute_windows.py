#!/usr/bin/env python3
"""PC1.md part 12B: the 29 network window features of the 110 replayable captures at 0.1, 0.25 and 0.5 s windows.

The release's switch model (features/switch_model.py window_features: the program's definitions, which the switch
computes exactly, part 6 and 11B) over each capture's 20 s from its manifest anchor: 200, 80 and 40 windows. Writes
OUT_DIR/windows_<ws>.csv.gz (execution_id, label, category, cv_group, window, the 29 features) and checks the 0.5 s
windows against live_test/streaming/dataset_windows.csv.gz, the detectors' training table (OUT_DIR/check_05.json).
Needs Python 3.9 or later (the model). Run niced.

    compute_windows.py OUT_DIR
"""
import csv
import gzip
import io
import json
import math
import os
import sys
import tarfile
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = REPO.parent / "p4-ebpf-malware-detection"
sys.path.insert(0, str(RELEASE / "features"))
import switch_model  # noqa: E402

CAPS = REPO / "live_test" / "captures"
SHM = Path("/dev/shm/hz_p12win")
SIZES = [0.1, 0.25, 0.5]
RUN_S = 20.0


def main():
    out = Path(sys.argv[1])
    out.mkdir(parents=True, exist_ok=True)
    SHM.mkdir(exist_ok=True)
    items = [dict(r, path=CAPS / "cohort" / r["capture"], member=None)
             for r in csv.DictReader(open(CAPS / "cohort" / "manifest.csv"))]
    tar = tarfile.open(CAPS / "cohort-extra.tar.gz", "r:gz")
    items += [dict(r, path=SHM / r["capture"], member="cohort-extra/" + r["capture"])
              for r in csv.DictReader(io.TextIOWrapper(tar.extractfile("cohort-extra/manifest.csv")))]
    # the training table's 0.5 s network columns, for the check
    ref = {}
    with gzip.open(REPO / "live_test" / "streaming" / "dataset_windows.csv.gz", "rt") as f:
        r = csv.reader(f)
        header = next(r)
        net = [i for i, h in enumerate(header) if h.startswith("net_")]
        for row in r:
            ref.setdefault(row[0], {})[int(row[5])] = {header[i]: float(row[i]) for i in net}
    writers, files = {}, {}
    for ws in SIZES:
        files[ws] = gzip.open(out / ("windows_%s.csv.gz" % ws), "wt", newline="")
        writers[ws] = csv.writer(files[ws])
        writers[ws].writerow(["execution_id", "label", "category", "cv_group", "window"] + switch_model.FEATURES)
    check = {"runs": 0, "runs_equal": 0, "differing": {}}
    for n, it in enumerate(items, 1):
        if it["member"]:
            with tar.extractfile(it["member"]) as src, open(it["path"], "wb") as dst:
                dst.write(src.read())
        start = int(it["anchor_us"])
        for ws in SIZES:
            rows = switch_model.window_features(str(it["path"]), start, ws, int(round(RUN_S / ws)))
            for w, feats in enumerate(rows):
                writers[ws].writerow([it["execution_id"], it["label"], it["category"], it["cv_group"], w]
                                     + [feats[k] for k in switch_model.FEATURES])
            if ws == 0.5 and it["execution_id"] in ref:
                check["runs"] += 1
                bad = []
                for w, feats in enumerate(rows):
                    for k, v in ref[it["execution_id"]].get(w, {}).items():
                        a = float(feats.get(k, 0.0))
                        if not math.isclose(a, v, rel_tol=1e-6, abs_tol=1e-6):
                            bad.append((w, k, a, v))
                if bad:
                    check["differing"][it["execution_id"]] = bad[:5] + [len(bad)]
                else:
                    check["runs_equal"] += 1
        if it["member"]:
            os.unlink(it["path"])
        print("[%d/%d] %s" % (n, len(items), it["execution_id"][:24]), flush=True)
    for f in files.values():
        f.close()
    (out / "check_05.json").write_text(json.dumps(check, indent=1) + "\n")
    print("0.5 s check: %d of %d runs equal to the training table in every window" % (check["runs_equal"], check["runs"]))


if __name__ == "__main__":
    main()
