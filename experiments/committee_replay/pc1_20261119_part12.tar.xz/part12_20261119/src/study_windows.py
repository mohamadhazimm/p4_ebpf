#!/usr/bin/env python3
"""PC1.md part 12B: does a shorter window make the verdict, and the block, come sooner without costing accuracy?

The network detector of the release (evaluation/common.py random_forest on the mean, max, sum, population std and
active windows of the 29 network features over a run's first k windows, as live_test/streaming/stream_verdicts.py)
at 0.1, 0.25 and 0.5 s windows, on the 110 replayable captures (windows_<ws>.csv.gz of compute_windows.py: the
switch model's features, which the switch computes exactly). Leave one group out: for each of the 42 cv_groups a
forest is trained on the other groups' runs at the prefixes PREFIX_TIMES (plus the first 1-3 windows) and scores
each run of the group after every window.

Per window size:
- the run-level verdict on the whole 20 s (balanced accuracy, AUC);
- the streaming verdict: attacks alarmed, benign runs alarmed (a false alarm), the time of the first alarm;
- containment: the share of the host's packets (from 10.0.0.10, the capture's timeline from its manifest anchor) sent
  after the alarm plus PROCESSING_S, the host block's start on a decent control-plane host (part 12's estimate:
  about 10 ms to read a window, 1-20 ms to score, 3-5 ms to write).

    study_windows.py WINDOWS_DIR OUT_JSON        (Python >= 3.9, NumPy, scikit-learn: the .venv)
"""
import csv
import gzip
import io
import json
import struct
import sys
import tarfile
from pathlib import Path

import numpy as np
from sklearn.metrics import roc_auc_score

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = REPO.parent / "p4-ebpf-malware-detection"
sys.path.insert(0, str(RELEASE / "evaluation"))
import common  # noqa: E402

SIZES = [0.1, 0.25, 0.5]
PREFIX_TIMES = [0.5, 1, 2, 3, 5, 8, 10, 15, 20]       # stream_verdicts.PREFIXES at 0.5 s, in seconds
PROCESSING_S = 0.05
HOST = bytes([10, 0, 0, 10])
BIN_S = 0.01


def load(path):
    runs, order = {}, []
    with gzip.open(path, "rt") as f:
        r = csv.reader(f)
        h = next(r)
        feats = h[5:]
        for row in r:
            eid = row[0]
            if eid not in runs:
                runs[eid] = dict(label=int(row[1]), category=row[2], group=row[3], w={})
                order.append(eid)
            runs[eid]["w"][int(row[4])] = [float(x) for x in row[5:]]
    K = max(len(v["w"]) for v in runs.values())
    W = np.asarray([[runs[e]["w"][k] for k in range(K)] for e in order])
    return order, W, np.asarray([runs[e]["label"] for e in order]), np.asarray([runs[e]["group"] for e in order]), \
        [runs[e]["category"] for e in order], feats


def summarize(W, k):
    """stream_verdicts.summarize: (n, signals * 5), the 5 statistics of each signal next to each other."""
    W = W[:, :k]
    return np.stack([W.mean(1), W.max(1), W.sum(1), W.std(1), (W != 0).sum(1).astype(float)], axis=2).reshape(len(W), -1)


def host_bins():
    """Per execution id: the host's frames (source 10.0.0.10) in 10 ms bins from the manifest anchor, over 20 s."""
    out = {}
    items = [(r, open(REPO / "live_test/captures/cohort" / r["capture"], "rb").read)
             for r in csv.DictReader(open(REPO / "live_test/captures/cohort/manifest.csv"))]
    tar = tarfile.open(REPO / "live_test/captures/cohort-extra.tar.gz", "r:gz")
    extra = list(csv.DictReader(io.TextIOWrapper(tar.extractfile("cohort-extra/manifest.csv"))))
    for r in extra:
        items.append((r, (lambda m: (lambda: tar.extractfile(m).read()))("cohort-extra/" + r["capture"])))
    for r, read in items:
        data = read()
        ns = struct.unpack("<I", data[:4])[0] == 0xa1b23c4d
        anchor = int(r["anchor_us"]) / 1e6
        bins = np.zeros(int(round(20.0 / BIN_S)) + 1)
        off = 24
        while off + 16 <= len(data):
            ts, tu, il, _ = struct.unpack("<IIII", data[off:off + 16])
            fr = data[off + 16:off + 16 + il]
            off += 16 + il
            if len(fr) >= 34 and fr[12:14] == b"\x08\x00" and fr[26:30] == HOST:
                t = ts + tu / (1e9 if ns else 1e6) - anchor
                if 0 <= t < 20.0:
                    bins[int(t / BIN_S)] += 1
        out[r["execution_id"]] = bins
    return out


def main():
    wdir, out_path = Path(sys.argv[1]), Path(sys.argv[2])
    bins = host_bins()
    result = {"processing_s": PROCESSING_S, "sizes": {}}
    for ws in SIZES:
        ids, W, y, g, cats, feats = load(wdir / ("windows_%s.csv.gz" % ws))
        K = W.shape[1]
        pref = sorted(set([1, 2, 3] + [int(round(t / ws)) for t in PREFIX_TIMES]))
        pref = [k for k in pref if 1 <= k <= K]
        P = np.full((len(ids), K), np.nan)
        for grp in sorted(set(g)):
            test, train = g == grp, g != grp
            Xtr = np.vstack([summarize(W[train], k) for k in pref])
            ytr = np.tile(y[train], len(pref))
            forest = common.random_forest().fit(Xtr, ytr)
            for i in np.where(test)[0]:
                Xk = np.vstack([summarize(W[i:i + 1], k) for k in range(1, K + 1)])
                P[i] = forest.predict_proba(Xk)[:, 1]
            print("ws %.2f: group %s done" % (ws, grp), flush=True)
        final = P[:, -1]
        pred = final >= 0.5
        tpr = float(pred[y == 1].mean())
        tnr = float((~pred[y == 0]).mean())
        runs = []
        for i, eid in enumerate(ids):
            k_alarm = next((k for k in range(K) if P[i, k] >= 0.5), None)
            t_alarm = None if k_alarm is None else (k_alarm + 1) * ws
            b = bins.get(eid)
            share = None
            if b is not None and b.sum() > 0:
                t_block = None if t_alarm is None else t_alarm + PROCESSING_S
                share = 0.0 if t_block is None else float(b[int(round(t_block / BIN_S)):].sum() / b.sum())
            runs.append(dict(execution_id=eid, label=int(y[i]), category=cats[i], group=g[i],
                             p_final=round(float(final[i]), 4), first_alarm_s=t_alarm,
                             blocked_share=None if share is None else round(share, 4),
                             p=[round(float(x), 4) for x in P[i]]))
        att = [r for r in runs if r["label"] == 1]
        ben = [r for r in runs if r["label"] == 0]
        t_att = sorted(r["first_alarm_s"] for r in att if r["first_alarm_s"] is not None)
        shares = [r["blocked_share"] for r in att if r["blocked_share"] is not None]
        net_att = [r for r in att if r["category"] == "network_attack"]
        result["sizes"][str(ws)] = dict(
            windows=K, prefixes=pref,
            run_level=dict(balanced_accuracy=round((tpr + tnr) / 2, 4), tpr=round(tpr, 4), tnr=round(tnr, 4),
                           auc=round(float(roc_auc_score(y, final)), 4)),
            streaming=dict(attacks=len(att), attacks_alarmed=sum(1 for r in att if r["first_alarm_s"] is not None),
                           benign=len(ben), benign_alarmed=sum(1 for r in ben if r["first_alarm_s"] is not None),
                           first_alarm_median_s=float(np.median(t_att)) if t_att else None,
                           first_alarm_p90_s=float(np.percentile(t_att, 90)) if t_att else None),
            containment=dict(attacks_with_host_frames=len(shares),
                             blocked_share_median=round(float(np.median(shares)), 4) if shares else None,
                             blocked_share_mean=round(float(np.mean(shares)), 4) if shares else None,
                             network_attacks={r["execution_id"]: r["blocked_share"] for r in net_att}),
            benign_blocked_share={r["execution_id"]: r["blocked_share"] for r in ben if r["first_alarm_s"] is not None},
            runs=runs)
        s = result["sizes"][str(ws)]
        print("ws %.2f: run-level BA %.3f (TPR %.3f TNR %.3f, AUC %.3f); streaming: attacks %d/%d alarmed, benign %d/%d "
              "alarmed, first alarm median %.2f s; host frames blocked: median %.1f%%" % (
                  ws, s["run_level"]["balanced_accuracy"], tpr, tnr, s["run_level"]["auc"],
                  s["streaming"]["attacks_alarmed"], len(att), s["streaming"]["benign_alarmed"], len(ben),
                  s["streaming"]["first_alarm_median_s"] or -1, 100 * (s["containment"]["blocked_share_median"] or 0)),
              flush=True)
    out_path.write_text(json.dumps(result, indent=1) + "\n")


if __name__ == "__main__":
    main()
