#!/usr/bin/env python3
"""PC1.md part 12C: live collector runs as a window table in the detectors' training format
(live_test/streaming/dataset_windows.csv.gz: execution_id, label, category, cv_group, split, window, 47 signals).

    convert_live.py CASES_TSV RUNS_DIR LABEL OUT_CSV_GZ

CASES_TSV: idx, id, group, category, command (run_live.sh's). Each run RUNS_DIR/ID.csv must hold the collector's 40
windows (window_id 0..39); a run with fewer is reported and left out. execution_id is "live:ID", split "live".
"""
import csv
import gzip
import sys
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
csv.field_size_limit(sys.maxsize)


def main():
    cases, runs, label, out = Path(sys.argv[1]), Path(sys.argv[2]), int(sys.argv[3]), Path(sys.argv[4])
    with gzip.open(REPO / "live_test/streaming/dataset_windows.csv.gz", "rt") as f:
        header = next(csv.reader(f))
    signals = header[6:]
    kept, left = 0, []
    with gzip.open(out, "wt", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        for line in open(cases):
            idx, ident, group, cat, _cmd = line.rstrip("\n").split("\t")
            path = runs / (ident + ".csv")
            if not path.exists():
                left.append((ident, "no csv"))
                continue
            rows = {int(float(r["window_id"])): r for r in csv.DictReader(open(path))}
            if sorted(rows) != list(range(40)):
                left.append((ident, "%d windows" % len(rows)))
                continue
            for k in range(40):
                r = rows[k]
                w.writerow(["live:" + ident, label, cat, group, "live", k] + [float(r[s] or 0) for s in signals])
            kept += 1
    print("%d runs written to %s; left out: %s" % (kept, out, left or "none"))


if __name__ == "__main__":
    main()
