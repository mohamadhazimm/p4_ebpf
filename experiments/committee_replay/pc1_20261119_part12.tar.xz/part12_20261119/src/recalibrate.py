#!/usr/bin/env python3
"""PC1.md part 12C: do live benign runs in the training stop the live false alarms, and at what cost?

The detectors of the live loop (live_test/streaming/stream_verdicts.py train_arrays: the release's forests on the
summaries of a run's first k windows at the prefixes 1..40; network, host, stacked), trained two ways on the same
folds and scored after every window:
  A  on the dataset's runs only (as now);
  B  on the dataset's runs plus live benign runs collected through the deployed pipeline (part 12C).
Folds: StratifiedGroupKFold(5, shuffle, seed 11) over the dataset's 240 runs and the live benign runs together, by
group (the dataset's cv_group; a live program's group holds its sizes or repetitions), so a scored run's own group is
never in its training. The live attacks (part 12D) are never trained on: models trained on everything else (A_all,
B_all) score them.

Per detector and model: the dataset's runs (run level, 40 windows: TPR, TNR, balanced accuracy; streaming, an alarm
in any window: TPR, FPR), the live benign runs (run-level and streaming false-alarm rates, by group), the live attacks
(alarmed, first alarm window).

    recalibrate.py LIVE_BENIGN_CSV_GZ LIVE_ATTACK_CSV_GZ OUT_JSON [DETECTOR ...]     (the .venv; run niced)
"""
import json
import sys
from pathlib import Path

import numpy as np
from sklearn.model_selection import StratifiedGroupKFold

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = REPO.parent / "p4-ebpf-malware-detection"
sys.path.insert(0, str(REPO / "live_test" / "streaming"))
sys.path.insert(0, str(RELEASE / "evaluation"))
import common  # noqa: E402
import stream_verdicts as sv  # noqa: E402

K = 40


def prefix_rows(W, idx, host, net):
    """Summaries of the first k windows, k = 1..40, of the runs idx: (len(idx) * 40, ...) host and network."""
    Xh = np.vstack([np.vstack([sv.summarize(W[i:i + 1, :, host], k) for k in range(1, K + 1)]) for i in idx])
    Xn = np.vstack([np.vstack([sv.summarize(W[i:i + 1, :, net], k) for k in range(1, K + 1)]) for i in idx])
    return Xh, Xn


def scores(model, W, idx, host, net):
    if len(idx) == 0:
        return np.zeros((0, K))
    Xh, Xn = prefix_rows(W, idx, host, net)
    return np.asarray(model.batch(Xh, Xn)).reshape(len(idx), K)


def rates(P, y):
    run = P[:, -1] >= 0.5
    stream = (P >= 0.5).any(axis=1)
    out = {}
    if (y == 1).any():
        out.update(tpr_run=round(float(run[y == 1].mean()), 4), tpr_stream=round(float(stream[y == 1].mean()), 4))
    if (y == 0).any():
        out.update(fpr_run=round(float(run[y == 0].mean()), 4), fpr_stream=round(float(stream[y == 0].mean()), 4))
    if (y == 1).any() and (y == 0).any():
        out["balanced_accuracy_run"] = round((out["tpr_run"] + 1 - out["fpr_run"]) / 2, 4)
        out["balanced_accuracy_stream"] = round((out["tpr_stream"] + 1 - out["fpr_stream"]) / 2, 4)
    return out


def main():
    live_benign, live_attack, out_path = sys.argv[1], sys.argv[2], Path(sys.argv[3])
    detectors = sys.argv[4:] or ["network", "host", "stacked"]
    signals, Wd, yd, gd = sv.load_windows(str(REPO / "live_test/streaming/dataset_windows.csv.gz"))
    s_b, Wb, yb, gb = sv.load_windows(live_benign)
    s_a, Wa, ya, ga = sv.load_windows(live_attack)
    assert s_b == signals and s_a == signals
    host = [i for i, s in enumerate(signals) if s.startswith("host_")]
    net = [i for i, s in enumerate(signals) if s.startswith("net_")]
    # one table: dataset runs then live benign runs
    W = np.concatenate([Wd, Wb])
    y = np.concatenate([yd, yb])
    g = np.concatenate([gd, gb])
    live = np.concatenate([np.zeros(len(yd), bool), np.ones(len(yb), bool)])
    folds = list(StratifiedGroupKFold(5, shuffle=True, random_state=11).split(W[:, 0, :1], y, g))
    result = {"dataset_runs": int(len(yd)), "live_benign_runs": int(len(yb)), "live_attack_runs": int(len(ya)),
              "live_benign_groups": sorted(set(gb.tolist())), "detectors": {}}
    for det in detectors:
        P = {m: np.full((len(y), K), np.nan) for m in ("A", "B")}
        for f, (tr, te) in enumerate(folds):
            tr_d = tr[~live[tr]]
            mA = sv.train_arrays(common, signals, W[tr_d], y[tr_d], g[tr_d], det)[2]
            mB = sv.train_arrays(common, signals, W[tr], y[tr], g[tr], det)[2]
            P["A"][te] = scores(mA, W, te, host, net)
            P["B"][te] = scores(mB, W, te, host, net)
            print("%s fold %d: trained on %d (A) / %d (B) runs, scored %d" % (det, f, len(tr_d), len(tr), len(te)),
                  flush=True)
        mA_all = sv.train_arrays(common, signals, Wd, yd, gd, det)[2]
        mB_all = sv.train_arrays(common, signals, W, y, g, det)[2]
        PA_att = scores(mA_all, Wa, np.arange(len(ya)), host, net)
        PB_att = scores(mB_all, Wa, np.arange(len(ya)), host, net)
        # the detector as deployed (all 240 dataset runs) on every live benign run: none is in its training
        PA_all_live = scores(mA_all, Wb, np.arange(len(yb)), host, net)
        res = {"A_all_live_benign": dict(rates(PA_all_live, yb), by_group={
            grp: int((PA_all_live[gb == grp] >= 0.5).any(axis=1).sum()) for grp in sorted(set(gb.tolist()))})}
        for m, PM, PAtt in (("A", P["A"], PA_att), ("B", P["B"], PB_att)):
            by_group = {}
            for grp in sorted(set(gb.tolist())):
                sel = np.where(live & (g == grp))[0]
                by_group[grp] = dict(runs=int(len(sel)), alarmed_stream=int((PM[sel] >= 0.5).any(axis=1).sum()),
                                     alarmed_run=int((PM[sel][:, -1] >= 0.5).sum()),
                                     max_p=round(float(PM[sel].max()), 3))
            att = []
            for i in range(len(ya)):
                k = next((k for k in range(K) if PAtt[i, k] >= 0.5), None)
                att.append(dict(group=str(ga[i]), first_alarm_window=k, p_first=round(float(PAtt[i, 0]), 3),
                                p_final=round(float(PAtt[i, -1]), 3), max_p=round(float(PAtt[i].max()), 3)))
            res[m] = dict(dataset=rates(PM[~live], y[~live]), live_benign=rates(PM[live], y[live]),
                          live_benign_by_group=by_group, live_attacks=att)
        result["detectors"][det] = res
        print("%-8s A_all (as deployed) on the live benign runs: FPR run %.3f stream %.3f" % (
            det, res["A_all_live_benign"]["fpr_run"], res["A_all_live_benign"]["fpr_stream"]), flush=True)
        for m in ("A", "B"):
            r = res[m]
            print("%-8s %s: dataset BA run %.3f stream %.3f (TPR %.3f/%.3f, FPR %.3f/%.3f); live benign FPR run %.3f "
                  "stream %.3f; live attacks alarmed %d/%d" % (
                      det, m, r["dataset"]["balanced_accuracy_run"], r["dataset"]["balanced_accuracy_stream"],
                      r["dataset"]["tpr_run"], r["dataset"]["tpr_stream"], r["dataset"]["fpr_run"],
                      r["dataset"]["fpr_stream"], r["live_benign"]["fpr_run"], r["live_benign"]["fpr_stream"],
                      sum(1 for a in r["live_attacks"] if a["first_alarm_window"] is not None), len(r["live_attacks"])),
                  flush=True)
        out_path.write_text(json.dumps(result, indent=1) + "\n")


if __name__ == "__main__":
    main()
