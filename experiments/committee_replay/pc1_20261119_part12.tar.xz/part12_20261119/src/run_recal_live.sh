#!/bin/bash
# PC1.md part 12E: the live loop with the recalibrated detector (stacked, trained on the dataset's runs plus the live
# benign runs of part 12C: --block-train-extra), host block at the alarm. A benign workload runs with its own live group
# held out (--block-hold-out-group), so its verdict is out of sample; an attack has no live group in the table. PC2's
# eth1 receive counter is read around each run, as run_attacks.sh does.
#   run_recal_live.sh OUT_DIR CASES EXTRA_WINDOWS_CSV_GZ          (as admin)
set -u
R=/home/admin/Desktop/hAZIM/p4_ebpf/perf/results/part12_20261119
ASROOT=/tmp/claude-1000/-home-admin-Desktop-hAZIM/dd29711f-6d0a-47d6-8c92-d2a98cd93247/scratchpad/asroot.sh
OUT=$1; CASES=$2; EXTRA=$3
mkdir -p "$OUT"
rx() { timeout 20 ssh -n -o BatchMode=yes admin@192.168.0.2 'cat /sys/class/net/eth1/statistics/rx_packets'; }
while IFS=$'\t' read -r idx id group cat cmd; do
    ho=()
    case "$group" in live::attack-*) ;; *) ho=(--block-hold-out-group "$group") ;; esac
    a=$(rx); b=$(rx)
    "$ASROOT" bash "$R/src/run_live.sh" "$OUT" "$CASES" "$idx" "$idx" --block-on-alarm --block-detector stacked \
        --block-host 192.168.0.1 --block-train-extra "$EXTRA" "${ho[@]}" < /dev/null
    sleep 3
    c=$(rx)
    echo "{\"id\": \"$id\", \"pc2_rx_before\": [$a, $b], \"pc2_rx_after\": $c, \"pc2_rx_run\": $((c - b - (b - a)))}" \
        | tee -a "$OUT/pc2_rx.jsonl"
done < "$CASES"
