#!/usr/bin/env python3
"""PC1.md part 12A: the 109 captures of part 6b (all 110 but bulkup_700) through hybrid_collector.py on the final build
(basic_exact_block_v2: perf/variants/exact_block, the lookup last with the direct counter), resumably.

As part 6b's run_collector_exact.py (replay_capture.py --exact --profile dataset --align-window 4, then
live_test/dataset_row.py --skip-windows 4 into OUT_DIR/rows.csv), plus the verdict loop of part 11: the collector
scores each window with the network detector trained without the capture's own group (--block-hold-out-group
CV_GROUP, the manifest's cv_group), and at an alarm the switch blocks everything from the replayed host
(--block-scope host, src 10.0.0.10). Each run's line in OUT_DIR/progress.jsonl adds the alarm (window, probability)
and the drops. The send capture tx.pcap is deleted after the run (PC1's disk; its counts are in summary.json).
Run it under the dataset construction's .venv (scikit-learn for the detector).

    run_replays_109.py OUT_DIR [--only ID,ID] [--skip ID,ID]
"""
import csv
import json
import subprocess
import sys
import tarfile
import time
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = REPO.parent / "p4-ebpf-malware-detection"
CAPS = REPO / "live_test" / "captures"
ASROOT = REPO / "perf" / "results" / "committee_replay" / "scripts" / "asroot.sh"
SHM = Path("/dev/shm/hz_part12")
ALWAYS_SKIP = {"bulkup_700"}       # part 4: guest GSO super-frames the MTU refuses (as part 6b)


def log(out, msg):
    line = "%s %s" % (time.strftime("%H:%M:%S"), msg)
    print(line, flush=True)
    with open(out / "driver.log", "a") as f:
        f.write(line + "\n")


def main():
    out = Path(sys.argv[1]).resolve()
    out.mkdir(parents=True, exist_ok=True)
    opts = dict(zip(sys.argv[2::2], sys.argv[3::2]))
    only = set(opts.get("--only", "").split(",")) - {""}
    skip = (set(opts.get("--skip", "").split(",")) - {""}) | ALWAYS_SKIP
    done = set()
    if (out / "progress.jsonl").exists():
        done = {json.loads(l)["execution_id"] for l in open(out / "progress.jsonl") if l.strip()}
    items = [dict(eid=r["execution_id"], offset=r["anchor_offset_s"], cat=r["category"], label=r["label"],
                  group=r["cv_group"], path=CAPS / "cohort" / r["capture"], member=None)
             for r in csv.DictReader(open(CAPS / "cohort" / "manifest.csv"))]
    man = subprocess.run(["tar", "xzf", str(CAPS / "cohort-extra.tar.gz"), "-O", "cohort-extra/manifest.csv"],
                         check=True, capture_output=True, text=True).stdout
    extra = list(csv.DictReader(man.splitlines(True)))
    extra = [r for r in extra if r["expect_overload"] == "0"] + [r for r in extra if r["expect_overload"] == "1"]
    items += [dict(eid=r["execution_id"], offset=r["anchor_offset_s"], cat=r["category"], label=r["label"],
                   group=r["cv_group"], path=SHM / r["capture"], member="cohort-extra/" + r["capture"]) for r in extra]
    todo = [it for it in items if it["eid"] not in done and it["eid"] not in skip and (not only or it["eid"] in only)]
    log(out, "%d captures to run (%d done before)" % (len(todo), len(done)))
    SHM.mkdir(exist_ok=True)
    for n, it in enumerate(todo, 1):
        if it["member"]:
            with tarfile.open(CAPS / "cohort-extra.tar.gz", "r:gz") as tar:
                with tar.extractfile(tar.getmember(it["member"])) as src, open(it["path"], "wb") as dst:
                    dst.write(src.read())
        run = out / it["eid"]
        t0 = time.time()
        p = subprocess.run([str(ASROOT), sys.executable, str(REPO / "live_test" / "replay_capture.py"), str(it["path"]),
                            "--out", str(run), "--profile", "dataset", "--anchor-offset", it["offset"],
                            "--align-window", "4", "--exact", "--",
                            "--block-on-alarm", "--block-detector", "network", "--block-host", "10.0.0.10",
                            "--block-hold-out-group", it["group"], "--block-skip-windows", "4"],
                           cwd=str(REPO), capture_output=True, text=True)
        if it["member"]:
            it["path"].unlink()
        res = {"execution_id": it["eid"], "label": it["label"], "category": it["cat"], "cv_group": it["group"],
               "rc": p.returncode, "wall_s": round(time.time() - t0, 1)}
        d = subprocess.run([sys.executable, str(REPO / "live_test" / "dataset_row.py"), str(run / "windows.csv"),
                            "--execution-id", it["eid"], "--category", it["cat"], "--label", it["label"],
                            "--skip-windows", "4", "--release", str(RELEASE), "--out", str(out / "rows.csv")],
                           cwd=str(REPO), capture_output=True, text=True)
        res["row_rc"] = d.returncode
        try:
            s = json.loads((run / "summary.json").read_text())
            ec = s["exact_check"]
            res.update({k: ec[k] for k in ("windows_checked", "windows_exact", "switch_pkts_total", "sent_pkts_total",
                                           "switch_bytes_total", "sent_bytes_total", "untracked_pkts", "windows_lost",
                                           "sent_before_first_marker_or_after_last")})
            res["anchor_on_this_clock"] = s.get("anchor_on_this_clock")
            res["tx_capture"] = ec.get("tx_capture")
        except Exception as error:
            res["error"] = "%s; %s" % (error, (p.stdout + p.stderr)[-600:])
        try:
            ev = [json.loads(l) for l in open(run / "windows.block.jsonl")]
            alarm = next((e for e in ev if e.get("event") == "alarm"), None)
            block = next((e for e in ev if e.get("event") == "block"), None)
            summ = next((e for e in ev if e.get("event") == "summary"), {})
            scores = [e for e in ev if e.get("event") == "score"]
            res.update(alarm_window=alarm["window"] - 4 if alarm else None,
                       alarm_p=alarm["probability"] if alarm else None, alarm_time=alarm["time"] if alarm else None,
                       block_t_request=block["t_request"] if block else None,
                       block_t_reply=block["t_reply"] if block else None, blocked_pkts=summ.get("blocked_pkts"),
                       max_p=max((e["probability"] for e in scores), default=None), windows_scored=len(scores),
                       p_by_window=[e["probability"] for e in scores])
        except Exception as error:
            res["block_error"] = str(error)[:300]
        tx = run / "tx.pcap"
        if tx.exists():
            subprocess.run([str(ASROOT), "rm", "-f", str(tx)])
        with open(out / "progress.jsonl", "a") as f:
            f.write(json.dumps(res) + "\n")
        log(out, "[%d/%d] %s rc %d row %d: %s/%s windows exact, pkts %s/%s, lost %s; alarm %s (p %s), blocked %s (%.0f s)" % (
            n, len(todo), it["eid"][:16], p.returncode, d.returncode, res.get("windows_exact"),
            res.get("windows_checked"), res.get("switch_pkts_total"), res.get("sent_pkts_total"),
            res.get("windows_lost"), res.get("alarm_window"), res.get("alarm_p"), res.get("blocked_pkts"),
            res["wall_s"]))
        time.sleep(2)


if __name__ == "__main__":
    main()
