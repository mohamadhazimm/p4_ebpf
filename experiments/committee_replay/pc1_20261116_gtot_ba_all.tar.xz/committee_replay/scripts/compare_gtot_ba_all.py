#!/usr/bin/env python3
"""PC1.md part 4g: all 109 captures on basic_gtot_ba (-DP4_GLOBAL_TOTALS_SPLIT=1, runs_gtot_ba/), against basic_fix
(replay_rows_v3.csv) and gtot with the boundary cut (runs_gtot_boundary/); the per-run numbers of those two come
from part 4e's gtot_all_compare.csv. Per capture: packets in the 40 dataset windows, windows with more A->B packets
than packets in all, B->A packets against the published row, the self-check, and the agreement with the published
row in the 30 B->A columns, the 95 total-based columns, the 50 per-flow columns and all 145. Writes
gtot_ba_all_compare.csv and replay_rows_gtot_ba.csv (all 109 rows from runs_gtot_ba/, in replay_rows_v3.csv's order);
prints a summary by group and (-v) the captures whose 95 total columns changed against gtot."""
import csv
import json
import statistics as st
import sys
from pathlib import Path

R = Path(__file__).resolve().parent.parent
DATASET = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection/dataset/features.csv")
TOTAL_FEATURES = ["net_pkts_total_delta", "net_bytes_total_delta", "net_pkts_ab_delta", "net_bytes_ab_delta",
                  "net_pkts_ba_delta", "net_bytes_ba_delta", "net_avg_pkt_size_delta", "net_avg_pkt_size_ab_delta",
                  "net_avg_pkt_size_ba_delta", "net_bytes_per_sec_delta", "net_pkts_per_sec_delta",
                  "net_down_up_ratio_delta", "net_ab_ratio_pkt_delta", "net_ba_ratio_pkt_delta",
                  "net_ab_ratio_byte_delta", "net_ba_ratio_byte_delta", "net_syn_delta", "net_ack_delta", "net_rst_delta"]
BA_FEATURES = ["net_pkts_ba_delta", "net_bytes_ba_delta", "net_avg_pkt_size_ba_delta", "net_down_up_ratio_delta",
               "net_ba_ratio_pkt_delta", "net_ba_ratio_byte_delta"]
AGGS = ["mean", "max", "sum", "std", "active_windows"]
TOTAL_COLS = ["%s__%s" % (f, a) for f in TOTAL_FEATURES for a in AGGS]
BA_COLS = ["%s__%s" % (f, a) for f in BA_FEATURES for a in AGGS]

published = {r["execution_id"]: r for r in csv.DictReader(open(DATASET))}
v3_list = list(csv.DictReader(open(R / "replay_rows_v3.csv")))
NET_COLS = [c for c in v3_list[0] if c.startswith("net_")]
FLOW_COLS = [c for c in NET_COLS if c not in TOTAL_COLS]
assert len(NET_COLS) == 145 and len(TOTAL_COLS) == 95 and len(BA_COLS) == 30 and len(FLOW_COLS) == 50
ROWS = {"bf": {r["execution_id"]: r for r in v3_list},
        "gtot": {r["execution_id"]: r for r in csv.DictReader(open(R / "runs_gtot_boundary" / "rows.csv"))},
        "ba": {r["execution_id"]: r for r in csv.DictReader(open(R / "runs_gtot_ba" / "rows.csv"))}}
assert set(ROWS["ba"]) == set(ROWS["bf"]), "runs_gtot_ba/rows.csv: %d captures, not the 109" % len(ROWS["ba"])
PART4E = {r["execution_id"]: r for r in csv.DictReader(open(R / "gtot_all_compare.csv"))}
BUILDS = ("bf", "gtot", "ba")


def agreement(row, ref, cols):
    exact, errs = 0, []
    for c in cols:
        a, b = float(row[c]), float(ref[c])
        exact += abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))
        errs.append(abs(a - b) / max(abs(b), 1e-9) if b else (0.0 if a == 0 else 1.0))
    return exact, st.median(errs)


def run_stats(run):
    sc = json.loads((run / "summary.json").read_text())["self_check"]
    w = list(csv.DictReader(open(run / "windows.csv")))
    recs = [r for r in map(json.loads, open(run / "timing.jsonl")) if "window" in r and r.get("wall_ms") is not None]
    f = lambda r, k: int(float(r.get(k) or 0))
    return dict(sent=sc["sent_pkts_total"], pkts=sum(f(r, "net_pkts_total_delta") for r in w[4:44]),
                overload=sum(f(r, "net_overload") for r in w[4:44]), overrun=sum(f(r, "net_read_overrun") for r in w[4:44]),
                wall_max=max(r["wall_ms"] for r in recs),
                ab_over=sum(f(r, "net_pkts_ab_delta") > f(r, "net_pkts_total_delta")
                            or f(r, "net_bytes_ab_delta") > f(r, "net_bytes_total_delta") for r in w),
                checked=sc["windows_checked"], inside=sc["windows_inside_bounds"],
                run_exact=int(sc["switch_pkts_total"] == sc["sent_pkts_total"]
                              and sc["switch_bytes_total"] == sc["sent_bytes_total"]),
                cut_ms=(sc.get("totals_read_end_after_window_end_ms") or {}).get("median"))


out = []
for eid in [r["execution_id"] for r in v3_list]:
    p4e, pub = PART4E[eid], published[eid]
    row = dict(execution_id=eid, sent=int(p4e["sent"]))
    for b, src in (("bf", "bf"), ("gtot", "bound")):
        for k in ("pkts", "overload", "overrun", "wall_max", "checked", "inside", "run_exact"):
            row["%s_%s" % (k, b)] = float(p4e["%s_%s" % (k, src)]) if k == "wall_max" else int(float(p4e["%s_%s" % (k, src)]))
    s = run_stats(R / "runs_gtot_ba" / eid)
    assert s["sent"] == row["sent"], eid
    for k in ("pkts", "overload", "overrun", "wall_max", "checked", "inside", "run_exact", "cut_ms", "ab_over"):
        row["%s_ba" % k] = s[k]
    row["pub_ba_pkts"] = int(float(pub["net_pkts_ba_delta__sum"]))
    for b in BUILDS:
        row["ba_pkts_" + b] = int(float(ROWS[b][eid]["net_pkts_ba_delta__sum"]))
        for name, cols in (("30", BA_COLS), ("95", TOTAL_COLS), ("50", FLOW_COLS), ("145", NET_COLS)):
            e, m = agreement(ROWS[b][eid], pub, cols)
            row["exact%s_%s" % (name, b)], row["mrel%s_%s" % (name, b)] = e, round(m, 6)
    out.append(row)

with open(R / "gtot_ba_all_compare.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(out[0]))
    wr.writeheader()
    wr.writerows(out)
with open(R / "replay_rows_gtot_ba.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(v3_list[0]))
    wr.writeheader()
    wr.writerows(ROWS["ba"][r["execution_id"]] for r in v3_list)
print("wrote gtot_ba_all_compare.csv and replay_rows_gtot_ba.csv (%d rows from runs_gtot_ba)" % len(out))

bulkup = [r for r in out if r["execution_id"].startswith("bulkup")]
ovl = [r for r in out if r["overload_bf"] > 0]
calm = [r for r in out if r not in bulkup and r not in ovl]
for name, grp in (("calm (no overloaded window on basic_fix)", calm), ("bulkup_200/400 (incomplete)", bulkup),
                  ("overloaded on basic_fix", ovl), ("all 109", out)):
    print("\n== %s: %d captures, %d packets sent" % (name, len(grp), sum(r["sent"] for r in grp)))
    print("%-36s %12s %12s %12s" % ("", "basic_fix", "gtot", "gtot_ba"))
    line = lambda label, fn: print("%-36s" % label + "".join("%12s" % fn(b) for b in BUILDS))
    line("packets in the 40 windows", lambda b: sum(r["pkts_" + b] for r in grp))
    line("captures with all of them", lambda b: sum(r["pkts_" + b] == r["sent"] for r in grp))
    line("runs exact over 44 windows", lambda b: sum(r["run_exact_" + b] for r in grp))
    line("self-check inside/checked", lambda b: "%d/%d" % (sum(r["inside_" + b] for r in grp),
                                                             sum(r["checked_" + b] for r in grp)))
    line("B->A packets (published %d)" % sum(r["pub_ba_pkts"] for r in grp), lambda b: sum(r["ba_pkts_" + b] for r in grp))
    for n in ("30", "95", "50", "145"):
        line("%s cols exact: median / mean" % n, lambda b: "%s / %.1f" % (st.median(r["exact%s_%s" % (n, b)] for r in grp),
                                                                        st.mean(r["exact%s_%s" % (n, b)] for r in grp)))
        line("%s cols: rows all equal" % n, lambda b: sum(r["exact%s_%s" % (n, b)] == int(n) for r in grp))
    line("95 cols median rel err: median", lambda b: "%.4f" % st.median(r["mrel95_" + b] for r in grp))
    line("overloaded / overrun windows", lambda b: "%d / %d" % (sum(r["overload_" + b] for r in grp),
                                                               sum(r["overrun_" + b] for r in grp)))
    line("longest read (ms)", lambda b: "%.0f" % max(r["wall_max_" + b] for r in grp))
    print("%-36s %36s" % ("windows with A->B above all (ba)", sum(r["ab_over_ba"] for r in grp)))
    cuts = [r["cut_ms_ba"] for r in grp if r["cut_ms_ba"] is not None]
    print("%-36s %36s" % ("totals' cut after boundary (ba)", "median of runs %.2f ms, max %.2f ms" % (st.median(cuts), max(cuts))))

if "-v" in sys.argv:
    print()
    for r in out:
        if r["exact95_ba"] != r["exact95_gtot"] or r["exact50_ba"] != r["exact50_gtot"]:
            print("%-22s sent %7d | 95 exact bf %2d gtot %2d ba %2d | 50 exact gtot %2d ba %2d | B->A pub %6d gtot %6d ba %6d"
                  % (r["execution_id"][:22], r["sent"], r["exact95_bf"], r["exact95_gtot"], r["exact95_ba"],
                     r["exact50_gtot"], r["exact50_ba"], r["pub_ba_pkts"], r["ba_pkts_gtot"], r["ba_pkts_ba"]))
