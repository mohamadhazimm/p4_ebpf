# Lab workstation, 2026-11-20: parts 13C/13K checked, part 12B rerun

See PC1.md, "Results, parts 13C/13K checked and 12B rerun (lab workstation, 2026-11-20)".

- `src/check_13ck.py` (standard library only): the check of 13H's claims about the 0.25 s training table, and of
  13J/13L's timing and floods from the archives' raw `timing.jsonl`, `block.jsonl` and `summary.json`.
  Output: `check_13ck/check_13ck.json`, `check_13ck/console.txt`.

      python3 -I src/check_13ck.py P4_EBPF part13_20261120 part13c_dir/part13_20261120 part13k_dir/part13_20261120 OUT.json

  (the three directories are `part13_20261120` of pc1_20261120_part13.tar.xz, _part13c.tar.xz and _part13k.tar.xz).
- `src/rerun_12b.py` (NumPy, scikit-learn; scikit-learn 1.7.0 here): part 12B's offline study rerun, with PC1's
  `study_windows.py` code copied verbatim, then trained on all 240 runs. Output: `rerun_12b/rerun_12b.json` (per run,
  each variant), `rerun_12b/rerun_12b.md` (the table), `rerun_12b/console.txt`.

      python3 src/rerun_12b.py part12_20261119/windows P4_EBPF RELEASE OUT_DIR --jobs 16

  (`part12_20261119/windows` of pc1_20261119_part12.tar.xz; RELEASE is a checkout of p4-ebpf-malware-detection.)
