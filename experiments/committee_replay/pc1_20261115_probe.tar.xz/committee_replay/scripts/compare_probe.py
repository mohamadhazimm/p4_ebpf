#!/usr/bin/env python3
"""Part 4c: each rerun with the dormant probe (runs_probe/, runs_probe_trial/) against its part 4 run (runs/):
windows inside the self-check bounds (both with the frame-byte self-check: summary_fixed.json for the old runs),
packet and byte totals, overloaded and overrun windows, the read's wall time, dormant coverage. Writes
probe_compare.csv and replay_rows_v3.csv (replay_rows_v2.csv with the rerun rows)."""
import csv
import json
import statistics as st
from pathlib import Path

R = Path(__file__).resolve().parent.parent
# later directories supersede earlier ones for the same capture (runs_probe2: the capped probe and the dst fix)
NEW_DIRS = [d for d in (R / "runs_probe_trial", R / "runs_probe", R / "runs_probe2") if d.exists()]


def run_stats(run, summary_name):
    s = json.loads((run / summary_name).read_text())
    sc = s["self_check"]
    w = list(csv.DictReader(open(run / "windows.csv")))[4:44]
    recs = [r for r in map(json.loads, open(run / "timing.jsonl")) if "window" in r and r.get("wall_ms") is not None]
    dorm = [r for r in recs if r.get("dormant")]
    return dict(checked=sc["windows_checked"], inside=sc["windows_inside_bounds"],
                pkts=sc["switch_pkts_total"], sent_pkts=sc["sent_pkts_total"],
                bytes=sc["switch_bytes_total"], sent_bytes=sc["sent_bytes_total"],
                overload=sum(int(float(x["net_overload"])) for x in w),
                overrun=sum(int(float(x["net_read_overrun"])) for x in w),
                wall_med=st.median(r["wall_ms"] for r in recs), wall_max=max(r["wall_ms"] for r in recs),
                dormant_max=max((r["dormant"] for r in dorm), default=0),
                dormant_windows=len(dorm),
                dormant_all_covered=sum((r.get("dormant_probed", 0) or r.get("dormant_read", 0)) >= r["dormant"]
                                        for r in dorm),
                exit=s.get("collector_exit_code"))


new_rows, latest = {}, {}
for d in NEW_DIRS:
    for r in csv.DictReader(open(d / "rows.csv")):
        new_rows[r["execution_id"]] = r
    for run in sorted(p for p in d.iterdir() if (p / "summary.json").exists() and (p / "windows.csv").exists()):
        latest[run.name] = run
rows = []
for eid, run in sorted(latest.items()):
    old = run_stats(R / "runs" / eid, "summary_fixed.json")
    new = run_stats(run, "summary.json")
    rows.append(dict(execution_id=eid, new_dir=run.parent.name, **{"old_" + k: v for k, v in old.items()},
                     **{"new_" + k: v for k, v in new.items()}))

with open(R / "probe_compare.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0]))
    w.writeheader()
    w.writerows(rows)

calm = [r for r in rows if not r["old_overload"] and not r["new_overload"]]
print("%d reruns (%d without overload in either run)" % (len(rows), len(calm)))
print("  collector exit 0:", sum(r["new_exit"] == 0 for r in rows))
for tag, sel in (("calm", calm), ("all", rows)):
    print("  %s: windows inside bounds old %d / %d -> new %d / %d" % (
        tag, sum(r["old_inside"] for r in sel), sum(r["old_checked"] for r in sel),
        sum(r["new_inside"] for r in sel), sum(r["new_checked"] for r in sel)))
print("  calm, totals exact (pkts and frame bytes): old %d -> new %d of %d" % (
    sum(r["old_pkts"] == r["old_sent_pkts"] and r["old_bytes"] == r["old_sent_bytes"] for r in calm),
    sum(r["new_pkts"] == r["new_sent_pkts"] and r["new_bytes"] == r["new_sent_bytes"] for r in calm), len(calm)))
print("  runs still with windows outside the bounds (calm):",
      [(r["execution_id"][:14], r["new_checked"] - r["new_inside"]) for r in calm if r["new_inside"] < r["new_checked"]])
print("  wall_ms max over the reruns: old %.0f -> new %.0f; medians of the run medians %.0f -> %.0f" % (
    max(r["old_wall_max"] for r in rows), max(r["new_wall_max"] for r in rows),
    st.median(r["old_wall_med"] for r in rows), st.median(r["new_wall_med"] for r in rows)))
print("  windows whose dormant buckets were all read/probed: old %d / %d -> new %d / %d" % (
    sum(r["old_dormant_all_covered"] for r in rows), sum(r["old_dormant_windows"] for r in rows),
    sum(r["new_dormant_all_covered"] for r in rows), sum(r["new_dormant_windows"] for r in rows)))
print("  overloaded runs (old -> new overload / overrun windows, switch/sent pkts):")
for r in rows:
    if r["old_overload"] or r["new_overload"]:
        print("    %-16s %2d/%2d -> %2d/%2d   %6d/%6d -> %6d/%6d   max wall %5.0f -> %5.0f ms  (%s)" % (
            r["execution_id"][:16], r["old_overload"], r["old_overrun"], r["new_overload"], r["new_overrun"],
            r["old_pkts"], r["old_sent_pkts"], r["new_pkts"], r["new_sent_pkts"], r["old_wall_max"], r["new_wall_max"],
            r["new_dir"]))

base = list(csv.DictReader(open(R / "replay_rows_v2.csv")))
out = [new_rows.get(r["execution_id"], r) for r in base]
with open(R / "replay_rows_v3.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(base[0]))
    w.writeheader()
    w.writerows(out)
print("replay_rows_v3.csv: %d rows, %d from the probe reruns" % (len(out), sum(r["execution_id"] in new_rows for r in base)))
