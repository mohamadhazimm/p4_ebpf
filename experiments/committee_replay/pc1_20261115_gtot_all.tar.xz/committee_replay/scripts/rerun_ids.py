#!/usr/bin/env python3
"""Rerun chosen Part 4 captures with the current collector (same commands as run_part4.py) into OUTDIR/<id>[_rN]
and append their rows to OUTDIR/rows.csv. Captures from cohort/ or, for the extras, cohort-extra.tar.gz extracted
into tmpfs one at a time; sha256 checked against the manifest. A failed run is recorded and not retried.

    python3 rerun_ids.py ASROOT OUTDIR REPS ID [ID ...] [-- COLLECTOR OPTIONS]   (ID "@FILE": the ids listed in FILE)
"""
import csv
import hashlib
import json
import subprocess
import sys
import time
from pathlib import Path

REPO = Path("/home/admin/Desktop/hAZIM/p4_ebpf")
RELEASE = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection")
CAPS = REPO / "live_test" / "captures"
SHM = Path("/dev/shm/hz_rerun")


def manifests():
    out = {}
    for r in csv.DictReader(open(CAPS / "cohort" / "manifest.csv")):
        out[r["execution_id"]] = dict(r, where="cohort")
    members = {}
    for line in subprocess.run(["tar", "tvzf", str(CAPS / "cohort-extra.tar.gz")], check=True, capture_output=True,
                               text=True).stdout.splitlines():
        parts = line.split()
        members[Path(parts[-1]).name] = int(parts[2])
    for r in csv.DictReader(open(CAPS / "cohort-extra" / "manifest.csv")):
        out[r["execution_id"]] = dict(r, where="extra", size_bytes=members.get(r["capture"], 0))
    return out


def mem_available():
    for line in open("/proc/meminfo"):
        if line.startswith("MemAvailable:"):
            return int(line.split()[1]) * 1024
    return 0


def wait_for_room(m, eid, log, wait_s=600):
    """An extra is extracted into tmpfs and the replayer holds every frame: MemAvailable must cover twice the capture
    plus 450 MB, and the disk the run's outputs; wait up to wait_s, else record the capture as skipped."""
    import shutil
    size = (CAPS / "cohort" / m["capture"]).stat().st_size if m["where"] == "cohort" else int(m.get("size_bytes") or 0)
    need_mem = size * (2 if m["where"] == "extra" else 1) + (450 << 20)
    need_disk = size // 8 + (150 << 20)
    deadline = time.time() + wait_s
    while mem_available() < need_mem or shutil.disk_usage("/").free < need_disk:
        if time.time() > deadline:
            msg = "%s %s SKIPPED: MemAvailable %d MB (need %d), free disk %d MB (need %d)" % (
                time.strftime("%H:%M:%S"), eid, mem_available() >> 20, need_mem >> 20,
                shutil.disk_usage("/").free >> 20, need_disk >> 20)
            print(msg, flush=True)
            log.write(msg + "\n")
            log.flush()
            return False
        time.sleep(15)
    return True


def main():
    argv, extra = sys.argv[1:], []
    if "--" in argv:
        argv, extra = argv[:argv.index("--")], argv[argv.index("--") + 1:]
    asroot, outdir, reps = argv[0], Path(argv[1]), int(argv[2])
    ids = []
    for a in argv[3:]:
        ids += Path(a[1:]).read_text().split() if a.startswith("@") else [a]
    outdir.mkdir(parents=True, exist_ok=True)
    man = manifests()
    log = open(outdir / "rerun.log", "a")
    for n, eid in enumerate(ids, 1):
        m = man[eid]
        if not wait_for_room(m, eid, log):
            continue
        if m["where"] == "cohort":
            cap = CAPS / "cohort" / m["capture"]
        else:
            SHM.mkdir(exist_ok=True)
            subprocess.run(["tar", "xzf", str(CAPS / "cohort-extra.tar.gz"), "-C", str(SHM), "--occurrence=1",
                            "cohort-extra/" + m["capture"]], check=True)
            cap = SHM / "cohort-extra" / m["capture"]
        try:
            if hashlib.sha256(cap.read_bytes()).hexdigest() != m["sha256"]:
                raise RuntimeError("sha256 mismatch")
            for rep in range(1, reps + 1):
                run = outdir / (eid if reps == 1 else "%s_r%d" % (eid, rep))
                t = time.time()
                p = subprocess.run([asroot, "python3", str(REPO / "live_test" / "replay_capture.py"), str(cap),
                                    "--out", str(run), "--profile", "dataset", "--anchor-offset", m["anchor_offset_s"],
                                    "--align-window", "4"] + (["--"] + extra if extra else []),
                                   cwd=str(REPO), capture_output=True, text=True)
                lines = [l for l in (p.stdout + p.stderr).splitlines() if l.startswith("[replay]") and "self-check" in l]
                d = subprocess.run([sys.executable, str(REPO / "live_test" / "dataset_row.py"), str(run / "windows.csv"),
                                    "--execution-id", eid, "--category", m["category"], "--label", m["label"],
                                    "--skip-windows", "4", "--release", str(RELEASE), "--out", str(outdir / "rows.csv")],
                                   cwd=str(REPO), capture_output=True, text=True)
                tx = run / "tx.pcap"
                if tx.exists():
                    subprocess.run(["gzip", "-6", str(tx)])
                status = "done" if p.returncode == 0 and d.returncode == 0 else "failed"
                msg = "%s [%d/%d] %s rep %d: %s, %.0f s; %s" % (time.strftime("%H:%M:%S"), n, len(ids), eid, rep, status,
                                                              time.time() - t, " ".join(lines) or (p.stdout + p.stderr)[-300:])
                print(msg, flush=True)
                log.write(msg + "\n")
                log.flush()
                time.sleep(2)
        except Exception as error:  # recorded, not retried
            msg = "%s %s FAILED: %r" % (time.strftime("%H:%M:%S"), eid, error)
            print(msg, flush=True)
            log.write(msg + "\n")
        finally:
            if m["where"] == "extra" and cap.exists():
                cap.unlink()
    for d in (SHM / "cohort-extra", SHM):
        if d.exists():
            d.rmdir()


if __name__ == "__main__":
    main()
