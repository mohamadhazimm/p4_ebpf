"""PC1.md part 4e, after patch_totals_first.py (+ its follow-up: TOTALS_CLOCK_KEYS, the pb2 skips): the totals in a
request of their own right after the window boundary, before the reports are taken (--totals-cut boundary, the
default; "read" = in the window's read, first; "snapshot" = part 4d's cut); the replay self-check takes the totals'
read as the cut of a window whose totals came from them, and checks its overloaded windows too."""
from pathlib import Path

ROOT = Path("/home/admin/Desktop/hAZIM/p4_ebpf")


def patch(path, edits):
    p = ROOT / path
    raw = p.read_bytes().decode()
    crlf = "\r\n" in raw
    if crlf:
        assert raw.count("\n") == raw.count("\r\n"), "mixed line endings in %s" % path
    text = raw.replace("\r\n", "\n")
    for old, new in edits:
        n = text.count(old)
        assert n == 1, "%s: %d matches for %r" % (path, n, old[:90])
        text = text.replace(old, new)
    p.write_bytes((text.replace("\n", "\r\n") if crlf else text).encode())
    print("patched", path, len(edits), "edits")


COLLECTOR = [
('''    totals_cut: str = "first",
    max_windows: int = 0,''',
 '''    totals_cut: str = "boundary",
    max_windows: int = 0,'''),
('''    totals from their differences. totals_cut "first": the reader reads them
    from hardware before the flow registers' sync, ~1 ms after the boundary
    (PC1.md part 4e); "snapshot": synced with the flow registers, last in the
    ~31 ms sync (part 4d), so a window's first ~30 ms counted in the one before.''',
 '''    totals from their differences. totals_cut "boundary": a request of their
    own right after the boundary, before the reports are taken and the read is
    planned (the reader reads them from hardware, no sync: their cut ~2 ms after
    the boundary, PC1.md part 4e); if it fails, the window's read takes them.
    "read": in the window's read, from hardware before the flow registers'
    sync (cut after the reports' processing: ~2 ms calm, ~35 ms under a flood).
    "snapshot": synced with the flow registers, last in the ~31 ms sync (part
    4d), so a window's first ~30 ms or more counted in the window before.'''),
('''        t_iter_start = clk.time()

        reports = collector.take(win_start_abs, win_end_abs)''',
 '''        t_iter_start = clk.time()

        boundary_totals: Optional[Dict[str, Any]] = None
        boundary_timing: Dict[str, Any] = {}
        if global_totals and totals_cut == "boundary":
            # The totals' cut right after the boundary (PC1.md part 4e): a totals-only request, before the reports
            # are taken. No retry: a failure leaves them to the window's read.
            try:
                if read_fn is None:
                    bp = read_p4_with_retries(reader_path, [], w, retries=0, timeout=read_timeout,
                                              switch_ssh=switch_ssh, snapshot=snapshot, clear_if_unchanged={},
                                              dst_indexes=[], totals=True)
                else:
                    bp = read_fn([], w, snapshot=snapshot, clear_if_unchanged={}, dst_indexes=[], totals=True)
                if isinstance(bp.get("totals"), dict) and all(bp["totals"].get(k) is not None for k in GTOT_KEYS):
                    boundary_totals = bp["totals"]
                    boundary_timing = {k: v for k, v in (bp.get("timing") or {}).items() if k in TOTALS_CLOCK_KEYS}
                else:
                    print(f"[WARN] window {w}: the boundary totals read returned no totals "
                          f"({bp.get('errors')}); the window's read takes them")
            except Exception as error:
                print(f"[WARN] window {w}: the boundary totals read failed ({describe_failure(error)}); "
                      f"the window's read takes them")

        reports = collector.take(win_start_abs, win_end_abs)'''),
('''        if global_totals:
            extra["totals"] = "snapshot" if totals_cut == "snapshot" else True''',
 '''        if global_totals and boundary_totals is None:
            extra["totals"] = "snapshot" if totals_cut == "snapshot" else True'''),
('''        read_end = clk.time()
        resumed_now = sorted(safe_int(i) for i in (payload.get("resumed") or []))''',
 '''        read_end = clk.time()
        if boundary_totals is not None and isinstance(payload.get("timing"), dict):
            payload["timing"].update(boundary_timing)     # the totals' cut, for the timing log
        resumed_now = sorted(safe_int(i) for i in (payload.get("resumed") or []))'''),
('''            "totals": payload.get("totals") if global_totals else None,''',
 '''            "totals": (boundary_totals if boundary_totals is not None else payload.get("totals"))
                      if global_totals else None,
            "totals_cut": (("boundary" if boundary_totals is not None else
                            ("snapshot" if totals_cut == "snapshot" else "read")) if global_totals else None),'''),
('''    ap.add_argument("--totals-cut", default="first", choices=["first", "snapshot"],
                    help="with --global-totals 1: 'first' reads the totals from hardware before the flow registers' "
                         "sync (cut ~1 ms after the window boundary, PC1.md part 4e); 'snapshot' syncs them with the "
                         "flow registers, last in the ~31 ms sync (part 4d)")''',
 '''    ap.add_argument("--totals-cut", default="boundary", choices=["boundary", "read", "snapshot"],
                    help="with --global-totals 1: 'boundary' reads the totals in a request of their own right after "
                         "the window boundary (cut ~2 ms after it, PC1.md part 4e); 'read' in the window's read, "
                         "before the flow registers' sync (after the reports' processing); 'snapshot' synced with "
                         "the flow registers, last in the ~31 ms sync (part 4d)")'''),
]

REPLAY = [
('''    snaps = {}
    for r in records:
        c = r.get("clock") or {}
        if theta is not None and "reader_t_sync_start" in c and "reader_t_sync_end" in c:
            snaps[r["window"]] = (c["reader_t_sync_start"] - theta - u, c["reader_t_sync_end"] - theta + u)
    windows, checked, inside = [], 0, 0
    prev_hi = t0
    for k in sorted(rows):
        r = rows[k]
        b_k, b_next = t0 + k * window_sec, t0 + (k + 1) * window_sec
        snap = snaps.get(k)''',
 '''    snaps, tots = {}, {}
    for r in records:
        c = r.get("clock") or {}
        if theta is not None and "reader_t_sync_start" in c and "reader_t_sync_end" in c:
            snaps[r["window"]] = (c["reader_t_sync_start"] - theta - u, c["reader_t_sync_end"] - theta + u)
        if theta is not None and "reader_t_totals_start" in c and "reader_t_totals_end" in c:
            tots[r["window"]] = (c["reader_t_totals_start"] - theta - u, c["reader_t_totals_end"] - theta + u)
    windows, checked, inside = [], 0, 0
    prev_hi = t0
    for k in sorted(rows):
        r = rows[k]
        b_k, b_next = t0 + k * window_sec, t0 + (k + 1) * window_sec
        # --global-totals (PC1.md part 4e): a window's totals came from the global totals, so they are cut where
        # those were read, whatever the buckets read; then an overloaded window is checked too
        gtot = int(float(r.get("net_gtot_used") or 0)) == 1 and k in tots
        snap = tots.get(k) if gtot else snaps.get(k)'''),
('''        w = {"window": k, "start": b_k, "snapshot": snap, "switch_pkts": sw_p, "switch_bytes": sw_b,
             "overload": int(float(r.get("net_overload") or 0))}''',
 '''        w = {"window": k, "start": b_k, "snapshot": snap, "switch_pkts": sw_p, "switch_bytes": sw_b,
             "overload": int(float(r.get("net_overload") or 0)), "cut": "totals" if gtot else "snapshot"}'''),
('''            if not w["overload"]:
                checked += 1''',
 '''            if not w["overload"] or gtot:
                checked += 1'''),
('''                             "snapshot_start_after_window_end_ms": None if not snaps else {
                                 "median": round(statistics.median((snaps[k][0] - (t0 + (k + 1) * window_sec)) * 1000.0
                                                                   for k in snaps), 2)}}''',
 '''                             "snapshot_start_after_window_end_ms": None if not snaps else {
                                 "median": round(statistics.median((snaps[k][0] - (t0 + (k + 1) * window_sec)) * 1000.0
                                                                   for k in snaps), 2)}}
    if tots:
        after = [(tots[k][1] - (t0 + (k + 1) * window_sec)) * 1000.0 for k in tots]
        summary["self_check"]["windows_cut_by_the_totals"] = sum(1 for w in windows if w["cut"] == "totals")
        summary["self_check"]["totals_read_end_after_window_end_ms"] = {
            "median": round(statistics.median(after), 2), "max": round(max(after), 2)}'''),
]

COLLECTOR_TESTS = [
('''    def test_the_collector_asks_for_the_totals_and_keeps_them(self):
        clock = FakeClock()
        calls = []

        def reader(indexes, w, **kw):
            calls.append(kw)
            return {"rows": [mkrow(i, 10 * (w + 1)) for i in indexes], "dst_rows": [], "cleared": [], "errors": [],
                    "timing": {"sync_ms": 1.0, "read_ms": 1.0, "clear_ms": 0.0}, "totals": totals(10 * (w + 1), 0)}

        t0 = clock.time()
        windows = hc.collect_windows_live(FakeCollector({0: [1]}, t0, 0.5), NeverEndingProc(), 0.5, 0.0, t0, "r.py",
                                          active_ttl_windows=3, clear_idle_windows=0, read_fn=reader, clock=clock,
                                          max_windows=3, global_totals=True)
        self.assertTrue(all(c.get("totals") is True for c in calls[:3]))
        self.assertEqual([w["totals"]["pkts"] for w in windows], [10, 20, 30])
        calls[:] = []
        hc.collect_windows_live(FakeCollector({0: [1]}, clock.time(), 0.5), NeverEndingProc(), 0.5, 0.0, clock.time(),
                                "r.py", active_ttl_windows=3, clear_idle_windows=0, read_fn=reader, clock=clock,
                                max_windows=2, global_totals=True, totals_cut="snapshot")
        self.assertTrue(calls and all(c.get("totals") == "snapshot" for c in calls))''',
 '''    def test_the_collector_asks_for_the_totals_and_keeps_them(self):
        clock = FakeClock()
        calls = []

        def reader(indexes, w, **kw):
            calls.append((list(indexes), kw))
            return {"rows": [mkrow(i, 10 * (w + 1)) for i in indexes], "dst_rows": [], "cleared": [], "errors": [],
                    "timing": {"sync_ms": 1.0, "read_ms": 1.0, "clear_ms": 0.0,
                               "reader_t_totals_start": 7.0 + w, "reader_t_totals_end": 7.5 + w},
                    "totals": totals(10 * (w + 1), 0) if kw.get("totals") else None}

        def run(n, **kw):
            calls[:] = []
            return hc.collect_windows_live(FakeCollector({0: [1]}, clock.time(), 0.5), NeverEndingProc(), 0.5, 0.0,
                                           clock.time(), "r.py", active_ttl_windows=3, clear_idle_windows=0,
                                           read_fn=reader, clock=clock, max_windows=n, global_totals=True, **kw)

        # default "boundary": a totals-only request first, then the window's read without them
        windows = run(3)
        self.assertEqual([(i, k.get("totals")) for i, k in calls],
                         [([], True), ([1], None), ([], True), ([1], None), ([], True), ([1], None)])
        self.assertEqual([w["totals"]["pkts"] for w in windows], [10, 20, 30])
        self.assertEqual({w["totals_cut"] for w in windows}, {"boundary"})
        windows = run(2, totals_cut="read")
        self.assertEqual([k.get("totals") for _i, k in calls], [True, True])
        self.assertEqual({w["totals_cut"] for w in windows}, {"read"})
        run(2, totals_cut="snapshot")
        self.assertEqual([k.get("totals") for _i, k in calls], ["snapshot", "snapshot"])

    def test_a_failed_boundary_read_leaves_the_totals_to_the_windows_read(self):
        clock = FakeClock()
        calls = []

        def reader(indexes, w, **kw):
            calls.append((list(indexes), kw.get("totals")))
            if not indexes and kw.get("totals"):
                raise RuntimeError("batched reader: no reply")
            return {"rows": [mkrow(i, 10 * (w + 1)) for i in indexes], "dst_rows": [], "cleared": [], "errors": [],
                    "timing": {"sync_ms": 1.0, "read_ms": 1.0, "clear_ms": 0.0}, "totals": totals(10 * (w + 1), 0)}

        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            windows = hc.collect_windows_live(FakeCollector({0: [1]}, clock.time(), 0.5), NeverEndingProc(), 0.5, 0.0,
                                              clock.time(), "r.py", active_ttl_windows=3, clear_idle_windows=0,
                                              read_fn=reader, clock=clock, max_windows=2, global_totals=True)
        self.assertEqual(calls, [([], True), ([1], True), ([], True), ([1], True)])
        self.assertEqual([w["totals"]["pkts"] for w in windows], [10, 20])
        self.assertEqual({w["totals_cut"] for w in windows}, {"read"})
        self.assertIn("the boundary totals read failed", out.getvalue())'''),
('''        self.assertEqual((args.global_totals, args.totals_cut), (1, "first"))''',
 '''        self.assertEqual((args.global_totals, args.totals_cut), (1, "boundary"))'''),
]

REPLAY_TESTS = [
('''@unittest.skipUnless((RELEASE / "features" / "summary.py").exists(), "release repository not next to p4_ebpf")
class DatasetRowSkip(unittest.TestCase):''',
 '''class SelfCheckTotalsCut(unittest.TestCase):
    """PC1.md part 4e: with --global-totals a window's totals are cut where the global totals were read, not at the
    flow registers' snapshot, and an overloaded window's totals do not depend on the buckets read."""

    def setUp(self):
        self.rc = load("replay_capture", REPO / "live_test" / "replay_capture.py")

    def test_the_totals_read_is_the_cut_and_overloaded_windows_are_checked(self):
        t0, window = 1000.0, 0.5
        # one packet 3 ms after the boundary of windows 0/1: after the totals' read (1.5-2.5 ms after it), so in
        # window 1, though before the end of the flow registers' snapshot (40 ms)
        sent = [(1000.10, tcp_frame(1001)), (1000.503, tcp_frame(1002)), (1000.70, tcp_frame(1003))]
        with tempfile.TemporaryDirectory() as d:
            out = Path(d)
            write_pcap(out / "cap.pcap", [(t - 990.0, f) for t, f in sent])
            write_pcap(out / "tx.pcap", sent)
            with open(out / "timing.jsonl", "w") as f:
                for k in (0, 1):
                    end = t0 + (k + 1) * window
                    clock = {"collector_t_sent": end + 0.001, "reader_t_recv": end + 0.0012,
                             "reader_t_send": end + 0.0418, "collector_t_reply": end + 0.042,
                             "reader_t_totals_start": end + 0.0015, "reader_t_totals_end": end + 0.0025,
                             "reader_t_sync_start": end + 0.010, "reader_t_sync_end": end + 0.040}
                    f.write(json.dumps({"window": k, "t_window_end": end, "clock": clock}) + "\\n")

            def windows(pkts, gtot):
                with open(out / "windows.csv", "w", newline="") as f:
                    w = csv.DictWriter(f, fieldnames=["net_window_id", "net_pkts_total_delta", "net_bytes_total_delta",
                                                      "net_overload", "net_gtot_used"])
                    w.writeheader()
                    for k, n in enumerate(pkts):
                        w.writerow({"net_window_id": k, "net_pkts_total_delta": n, "net_bytes_total_delta": 54 * n,
                                    "net_overload": 1, "net_gtot_used": gtot})
                return self.rc.analyse(out, out / "cap.pcap", 0.0, 0, None, 0.0, window, header_bytes=14)

            totals = windows([1, 2], 1)["self_check"]
            spilled = windows([2, 1], 1)["self_check"]
            buckets = windows([1, 2], 0)["self_check"]
        self.assertEqual((totals["windows_checked"], totals["windows_inside_bounds"]), (2, 2))
        self.assertEqual(totals["windows_cut_by_the_totals"], 2)
        self.assertAlmostEqual(totals["totals_read_end_after_window_end_ms"]["median"], 2.5, delta=0.5)
        self.assertEqual(spilled["windows_inside_bounds"], 0, "a packet 3 ms in counted before a cut at 2.5 ms")
        self.assertEqual(buckets["windows_checked"], 0, "bucket totals of overloaded windows are not checked")


@unittest.skipUnless((RELEASE / "features" / "summary.py").exists(), "release repository not next to p4_ebpf")
class DatasetRowSkip(unittest.TestCase):'''),
]

patch("hybrid_collector.py", COLLECTOR)
patch("live_test/replay_capture.py", REPLAY)
patch("thesis-hybrid-ebpf-p4/python/tests/test_dataset_profile.py", COLLECTOR_TESTS)
patch("thesis-hybrid-ebpf-p4/python/tests/test_replay_profiles.py", REPLAY_TESTS)
