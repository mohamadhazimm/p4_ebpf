"""PC1.md part 4e: read the gtot build's seven totals from hardware before the flow registers' sync (their cut moves
from the end of the ~31 ms sync to ~1 ms after the window boundary); --totals-cut snapshot keeps part 4d's cut."""
from pathlib import Path

ROOT = Path("/home/admin/Desktop/hAZIM/p4_ebpf")


def patch(path, edits, crlf):
    p = ROOT / path
    raw = p.read_bytes().decode()
    if crlf:
        assert raw.count("\n") == raw.count("\r\n"), "mixed line endings in %s" % path
        text = raw.replace("\r\n", "\n")
    else:
        assert "\r\n" not in raw, "CRLF in %s" % path
        text = raw
    for old, new in edits:
        n = text.count(old)
        assert n == 1, "%s: %d matches for %r" % (path, n, old[:90])
        text = text.replace(old, new)
    p.write_bytes((text.replace("\n", "\r\n") if crlf else text).encode())
    print("patched", path, len(edits), "edits")


READER = [
# docstring of read_window
('''        totals: also sync and read the seven one-entry global totals of the test
        build perf/variants/gtot, in the same snapshot, through the client's own
        parser (seven entities); payload "totals" = {pkts, bytes, pkts_ab,
        bytes_ab, syn, ack, rst}, each summed over the pipes (None if a read
        failed), or an error when the program has no totals."""''',
 '''        totals: also read the seven one-entry global totals of the test build
        perf/variants/gtot; payload "totals" = {pkts, bytes, pkts_ab, bytes_ab,
        syn, ack, rst}, each summed over the pipes (None if a read failed), or an
        error when the program has no totals. True: from hardware, before the
        flow registers' sync (one request of seven entities), so the window's
        totals are cut ~1 ms after its boundary (PC1.md part 4e). "snapshot":
        synced with the flow registers and read after them (part 4d): the batched
        sync takes ~31 ms and the totals came last in it, so the packets of a
        window's first ~30 ms counted in the window before. Under snapshot=
        "shadow" (benchmarks) the totals come from the shadow, as "snapshot"."""'''),
# the cut, before the sync
('''        if totals and self.global_tables:
            sync_tables.extend(self.global_tables.values())
        if snapshot == "sync" and not indexes and not dst_indexes and not probe and not totals:
            sync_s = 0.0          # nothing to read: a clear needs no snapshot''',
 '''        totals_cut = None
        totals_out = None
        if totals:
            totals_cut = "snapshot" if (totals == "snapshot" or snapshot == "shadow") else "first"
            timing["totals_cut"] = totals_cut
            if not self.global_tables:
                errors.append("global totals are not in this program (perf/variants/gtot)")
            elif totals_cut == "first":
                totals_out = self._read_totals(True, timing, errors)
            else:
                sync_tables.extend(self.global_tables.values())
        if snapshot == "sync" and not indexes and not dst_indexes and not probe and totals_cut != "snapshot":
            sync_s = 0.0          # nothing to read: a clear needs no snapshot'''),
# the old read after the flow registers
('''        totals_out = None
        if totals:
            if not self.global_tables:
                errors.append("global totals are not in this program (perf/variants/gtot)")
            else:
                t_tot = time.time()
                totals_out = OrderedDict()
                for name, t in self.global_tables.items():
                    try:
                        v = self._read_safe(t, [0], from_hw, timing).get(0)
                    except Exception as error:
                        errors.append("%s: %s" % (name, error))
                        v = None
                    totals_out[name[len("reg_g_"):]] = sum(v) if v is not None else None
                timing["totals_ms"] = round((time.time() - t_tot) * 1000.0, 3)
        read_s = round(time.time() - t_start, 4)''',
 '''        if totals_cut == "snapshot" and self.global_tables:
            totals_out = self._read_totals(from_hw, timing, errors)
        read_s = round(time.time() - t_start, 4)'''),
# the helpers, before _read_safe
('''    def _read_safe(self, t, indexes, from_hw, timing):
        gc = self.gc''',
 '''    def _read_totals(self, from_hw, timing, errors):
        """The seven one-entry totals, each summed over the pipes (None where a read failed). On the fast and raw
        routes one ReadRequest of seven entities (checked once against the client's parser, as _read_table checks
        a route), else one entry_get per register. reader_t_totals_start/end: this host's clock around the read
        that gave them, i.e. the totals' cut."""
        t0 = time.time()
        timing["reader_t_totals_start"] = t0
        got = None
        if self.totals_one_request is not False and (self.fast or self.raw):
            try:
                got = self._read_totals_one_request(from_hw, timing)
            except Exception as error:
                log("the totals in one request failed (%s): one entry_get per register from now on" % error)
                self.totals_one_request = False
        timing["reader_t_totals_end"] = time.time()
        if got is not None and self.totals_one_request is None:
            probe = dict(read_rpcs=0, read_entities=0)
            want = dict((name, self._read_safe(t, [0], from_hw, probe).get(0))
                        for name, t in self.global_tables.items())
            again = self._read_totals_one_request(from_hw, probe)
            # counters only grow: the parsers agree if the client's values lie between the two requests'
            ok = all(got.get(n) is not None and again.get(n) is not None and want[n] is not None
                     and len(got[n]) == len(want[n]) == len(again[n])
                     and all(a <= b <= c for a, b, c in zip(got[n], want[n], again[n])) for n in want)
            if not ok:
                log("the totals in one request disagree with the client's parser (%r, %r, %r): not using it"
                    % (got, want, again))
                got = None
            self.totals_one_request = ok
        timing["totals_route"] = "one request" if got is not None else "entry_get"
        out = OrderedDict()
        for name, t in self.global_tables.items():
            v = got.get(name) if got is not None else None
            if v is None:
                try:
                    v = self._read_safe(t, [0], from_hw, timing).get(0)
                except Exception as error:
                    errors.append("%s: %s" % (name, error))
                    v = None
            out[name[len("reg_g_"):]] = sum(v) if v is not None else None
        if got is None:
            timing["reader_t_totals_end"] = time.time()
        timing["totals_ms"] = round((timing["reader_t_totals_end"] - t0) * 1000.0, 3)
        return out

    def _read_totals_one_request(self, from_hw, timing):
        """name -> per-pipe values of the seven one-entry totals, from one ReadRequest."""
        req = self.pb2.ReadRequest()
        self._fill_target(req)
        by_id = {}
        for name, t in self.global_tables.items():
            te = req.entities.add().table_entry
            te.table_id = t.table_id
            te.table_flags.from_hw = bool(from_hw)
            kf = te.key.fields.add()
            kf.field_id = t.key_id
            kf.exact.value = int_to_bytes(0, t.key_size)
            by_id[t.table_id] = (name, t)
        timing["read_rpcs"] += 1
        got = {}
        for rsp in self.rw._read(req):
            for ent in rsp.entities:
                te = ent.table_entry
                if te.table_id not in by_id:
                    continue
                name, t = by_id[te.table_id]
                vals = []
                for f in te.data.fields:
                    if f.field_id != t.data_id:
                        continue
                    if f.HasField("stream"):
                        vals.append(bytes_to_int(f.stream))
                    elif f.HasField("int_arr_val"):
                        vals.extend(int(x) for x in f.int_arr_val.val)
                if vals:
                    got[name] = vals
                    timing["read_entities"] += 1
        return got

    def _read_safe(self, t, indexes, from_hw, timing):
        gc = self.gc'''),
# state: the one-request route for the totals, decided on the first read
('''        self.flow_tables = [t for t in self.tables.values() if t is not None]
        self.clear_tables =''',
 '''        # None: not checked yet; True/False after the first totals read (_read_totals)
        self.totals_one_request = None if all(t.ids_ok for t in self.global_tables.values()) else False
        self.flow_tables = [t for t in self.tables.values() if t is not None]
        self.clear_tables ='''),
# serve: pass "snapshot" through
('''                                         totals=bool(req.get("totals")))''',
 '''                                         totals=req.get("totals") or False)'''),
]

COLLECTOR = [
('''             probe_max_full: Optional[int] = None, totals: bool = False) -> Dict[str, Any]:
        if self._proc is None or self._proc.poll() is not None:''',
 '''             probe_max_full: Optional[int] = None, totals: Any = False) -> Dict[str, Any]:
        if self._proc is None or self._proc.poll() is not None:'''),
('''            request["totals"] = True    # the gtot build's one-entry totals (batched_reader.read_window)''',
 '''            # the gtot build's one-entry totals (batched_reader.read_window): from hardware before the flow
            # registers' sync, or "snapshot": synced with them (PC1.md part 4d's cut)
            request["totals"] = "snapshot" if totals == "snapshot" else True'''),
('''CLOCK_KEYS = ("collector_t_sent", "collector_t_reply", "reader_t_recv", "reader_t_sync_start",
              "reader_t_sync_end", "reader_t_send")''',
 '''CLOCK_KEYS = ("collector_t_sent", "collector_t_reply", "reader_t_recv", "reader_t_sync_start",
              "reader_t_sync_end", "reader_t_send", "reader_t_totals_start", "reader_t_totals_end")'''),
('''    global_totals: bool = False,
    max_windows: int = 0,''',
 '''    global_totals: bool = False,
    totals_cut: str = "first",
    max_windows: int = 0,'''),
('''    every read also returns the seven one-entry totals from the same snapshot
    (window["totals"]); NetSummarizer(global_totals=True) takes the window's
    packet, byte and flag totals from their differences.''',
 '''    every read also returns the seven one-entry totals (window["totals"]);
    NetSummarizer(global_totals=True) takes the window's packet, byte and flag
    totals from their differences. totals_cut "first": the reader reads them
    from hardware before the flow registers' sync, ~1 ms after the boundary
    (PC1.md part 4e); "snapshot": synced with the flow registers, last in the
    ~31 ms sync (part 4d), so a window's first ~30 ms counted in the one before.'''),
('''        if global_totals:
            extra["totals"] = True''',
 '''        if global_totals:
            extra["totals"] = "snapshot" if totals_cut == "snapshot" else True'''),
('''                         "an overloaded read does not shrink them (PC1.md part 4d); adds net_gtot_* check columns")''',
 '''                         "an overloaded read does not shrink them (PC1.md part 4d); adds net_gtot_* check columns")
    ap.add_argument("--totals-cut", default="first", choices=["first", "snapshot"],
                    help="with --global-totals 1: 'first' reads the totals from hardware before the flow registers' "
                         "sync (cut ~1 ms after the window boundary, PC1.md part 4e); 'snapshot' syncs them with the "
                         "flow registers, last in the ~31 ms sync (part 4d)")'''),
('''            global_totals=bool(args.global_totals),
            max_windows=args.windows,''',
 '''            global_totals=bool(args.global_totals),
            totals_cut=args.totals_cut,
            max_windows=args.windows,'''),
]

READER_TESTS = [
('''    """read_window(totals=True) on the test build perf/variants/gtot (PC1.md part 4d): the seven one-entry totals,
    synced with the flow registers, summed over the pipes."""''',
 '''    """read_window(totals=True) on the test build perf/variants/gtot (PC1.md parts 4d, 4e): the seven one-entry
    totals, summed over the pipes; read from hardware before the flow registers' sync, or (totals="snapshot")
    synced with them."""'''),
('''    def test_the_totals_come_from_the_windows_snapshot(self):
        sw = self.gtot_switch()
        reader = make_batched(sw)
        first = reader.read_window([], totals=True)
        self.assertGreater(first["timing"]["sync_rpcs"], 0, "totals alone still take the snapshot")
        sw.packet(11, 0, 70, 1011, 80, 6, 0x10, 2000)          # after it: only in hardware
        self.assertEqual(reader.read_window([], snapshot="shadow", totals=True)["totals"]["pkts"], first["totals"]["pkts"])
        self.assertEqual(reader.read_window([], totals=True)["totals"]["pkts"], first["totals"]["pkts"] + 1)''',
 '''    def test_snapshot_cut_the_totals_come_from_the_windows_snapshot(self):
        sw = self.gtot_switch()
        reader = make_batched(sw)
        first = reader.read_window([], totals="snapshot")
        self.assertGreater(first["timing"]["sync_rpcs"], 0, "totals alone still take the snapshot")
        self.assertEqual(first["timing"]["totals_cut"], "snapshot")
        sw.packet(11, 0, 70, 1011, 80, 6, 0x10, 2000)          # after it: only in hardware
        self.assertEqual(reader.read_window([], snapshot="shadow", totals=True)["totals"]["pkts"], first["totals"]["pkts"])
        self.assertEqual(reader.read_window([], totals="snapshot")["totals"]["pkts"], first["totals"]["pkts"] + 1)

    def test_the_totals_are_read_from_hardware_before_the_sync(self):
        sw = self.gtot_switch()
        reader = make_batched(sw)
        events = []
        sync_all, read_totals = reader._sync_all, reader._read_totals
        reader._sync_all = lambda tables, timing: (events.append("sync"), sync_all(tables, timing))[1]
        reader._read_totals = lambda *a: (events.append("totals"), read_totals(*a))[1]
        alone = reader.read_window([], totals=True)
        self.assertEqual((alone["timing"]["sync_rpcs"], alone["timing"]["totals_cut"]), (0, "first"),
                         "totals alone need no sync")
        self.assertEqual(alone["totals"]["pkts"], 103)
        self.assertEqual(alone["timing"]["totals_route"], "one request")
        sw.packet(11, 0, 70, 1011, 80, 6, 0x10, 2000)          # in hardware, not in the shadow
        self.assertEqual(reader.read_window([], totals=True)["totals"]["pkts"], 104)
        events[:] = []
        both = reader.read_window([11, KNOWN_IDX], totals=True)
        self.assertEqual(events, ["totals", "sync"])
        self.assertEqual(both["timing"]["sync_rpcs"], len(batched_reader.REG_NAMES), "the totals are not synced")
        self.assertEqual(both["totals"]["pkts"], sum(r["pkts"] for r in both["rows"]))
        self.assertLessEqual(both["timing"]["reader_t_totals_end"], both["timing"]["reader_t_sync_start"])

    def test_the_one_request_route_falls_back_to_one_read_per_register(self):
        sw = self.gtot_switch()
        reader = make_batched(sw)

        def broken(from_hw, timing):
            raise RuntimeError("one table per request")
        reader._read_totals_one_request = broken
        with contextlib.redirect_stderr(io.StringIO()) as err:
            first = reader.read_window([], totals=True)
        self.assertIn("one entry_get per register from now on", err.getvalue())
        self.assertEqual((first["totals"]["pkts"], first["timing"]["totals_route"]), (103, "entry_get"))
        self.assertIs(reader.totals_one_request, False)
        self.assertEqual(first["errors"], [])

    def test_the_one_request_route_is_dropped_when_the_parsers_disagree(self):
        sw = self.gtot_switch()
        reader = make_batched(sw)
        real = reader._read_totals_one_request
        reader._read_totals_one_request = (lambda f: lambda from_hw, timing: dict(
            (k, [0] * len(v)) if k == "reg_g_bytes" else (k, v) for k, v in f(from_hw, timing).items()))(real)
        with contextlib.redirect_stderr(io.StringIO()) as err:
            first = reader.read_window([], totals=True)
        self.assertIn("disagree with the client's parser", err.getvalue())
        self.assertIs(reader.totals_one_request, False)
        self.assertEqual(first["timing"]["totals_route"], "entry_get")
        rows = make_batched(self.gtot_switch(), addr="mock:g2").read_window([11, KNOWN_IDX])["rows"]
        self.assertEqual(first["totals"]["bytes"], sum(r["bytes"] for r in rows))'''),
('''                self.assertEqual(proc.read([], totals=True, timeout=30)["totals"]["pkts"], 103)''',
 '''                self.assertEqual(proc.read([], totals=True, timeout=30)["totals"]["pkts"], 103)
                snap = proc.read([], totals="snapshot", timeout=30)
                self.assertEqual((snap["totals"]["pkts"], snap["timing"]["totals_cut"]), (103, "snapshot"))'''),
]

COLLECTOR_TESTS = [
('''        self.assertTrue(all(c.get("totals") is True for c in calls[:3]))
        self.assertEqual([w["totals"]["pkts"] for w in windows], [10, 20, 30])''',
 '''        self.assertTrue(all(c.get("totals") is True for c in calls[:3]))
        self.assertEqual([w["totals"]["pkts"] for w in windows], [10, 20, 30])
        calls[:] = []
        hc.collect_windows_live(FakeCollector({0: [1]}, clock.time(), 0.5), NeverEndingProc(), 0.5, 0.0, clock.time(),
                                "r.py", active_ttl_windows=3, clear_idle_windows=0, read_fn=reader, clock=clock,
                                max_windows=2, global_totals=True, totals_cut="snapshot")
        self.assertTrue(calls and all(c.get("totals") == "snapshot" for c in calls))'''),
('''        self.assertEqual(args.global_totals, 1)
        self.assertEqual(hc.build_arg_parser().parse_args(ProfileTests.BASE).global_totals, 0)''',
 '''        self.assertEqual((args.global_totals, args.totals_cut), (1, "first"))
        self.assertEqual(hc.build_arg_parser().parse_args(ProfileTests.BASE).global_totals, 0)
        self.assertEqual(hc.build_arg_parser().parse_args(ProfileTests.BASE + ["--totals-cut", "snapshot"]).totals_cut,
                         "snapshot")'''),
]

patch("thesis-hybrid-ebpf-p4/python/batched_reader.py", READER, crlf=False)
patch("hybrid_collector.py", COLLECTOR, crlf=True)
patch("thesis-hybrid-ebpf-p4/python/tests/test_batched_reader.py", READER_TESTS, crlf=False)
patch("thesis-hybrid-ebpf-p4/python/tests/test_dataset_profile.py", COLLECTOR_TESTS,
      crlf=b"\r\n" in (ROOT / "thesis-hybrid-ebpf-p4/python/tests/test_dataset_profile.py").read_bytes())
