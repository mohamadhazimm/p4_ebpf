#!/usr/bin/env python3
"""Part 4e: all 109 captures on the gtot build with --global-totals 1, twice: with part 4d's cut (the totals synced
with the flow registers, runs_gtot_all/) and with the totals read at the window boundary (--totals-cut boundary,
runs_gtot_boundary/), against the basic_fix rows of replay_rows_v3.csv and the published rows (dataset/features.csv).
The basic_fix run behind each v3 row is found by row equality (runs_probe2, runs_probe, runs_probe_trial, runs_fix,
then part 4's runs/). Per capture and build: packets seen in the 40 dataset windows against packets sent,
overloaded/overrun windows, the longest read, the self-check, and the agreement with the published row in the 95
total-based columns, the 50 per-flow columns and all 145. Writes gtot_all_compare.csv and replay_rows_gtot.csv
(the boundary run's rows in replay_rows_v3.csv's row order); prints a summary by group."""
import csv
import json
import statistics as st
import sys
from pathlib import Path

R = Path(__file__).resolve().parent.parent
DATASET = Path("/home/admin/Desktop/hAZIM/p4-ebpf-malware-detection/dataset/features.csv")
TOTAL_FEATURES = ["net_pkts_total_delta", "net_bytes_total_delta", "net_pkts_ab_delta", "net_bytes_ab_delta",
                  "net_pkts_ba_delta", "net_bytes_ba_delta", "net_avg_pkt_size_delta", "net_avg_pkt_size_ab_delta",
                  "net_avg_pkt_size_ba_delta", "net_bytes_per_sec_delta", "net_pkts_per_sec_delta",
                  "net_down_up_ratio_delta", "net_ab_ratio_pkt_delta", "net_ba_ratio_pkt_delta",
                  "net_ab_ratio_byte_delta", "net_ba_ratio_byte_delta", "net_syn_delta", "net_ack_delta", "net_rst_delta"]
AGGS = ["mean", "max", "sum", "std", "active_windows"]
TOTAL_COLS = ["%s__%s" % (f, a) for f in TOTAL_FEATURES for a in AGGS]
BUILDS = [("bf", None), ("snap", "runs_gtot_all"), ("bound", "runs_gtot_boundary")]

published = {r["execution_id"]: r for r in csv.DictReader(open(DATASET))}
v3_list = list(csv.DictReader(open(R / "replay_rows_v3.csv")))
v3 = {r["execution_id"]: r for r in v3_list}
NET_COLS = [c for c in v3_list[0] if c.startswith("net_")]
FLOW_COLS = [c for c in NET_COLS if c not in TOTAL_COLS]
assert len(NET_COLS) == 145 and len(TOTAL_COLS) == 95 and len(FLOW_COLS) == 50
rows = {"bf": v3}
for b, d in BUILDS[1:]:
    rows[b] = {r["execution_id"]: r for r in csv.DictReader(open(R / d / "rows.csv"))}
    assert set(rows[b]) == set(v3), "%s: its rows and the v3 rows differ in their captures" % d

SOURCES = [(d, {r["execution_id"]: r for r in csv.DictReader(open(R / d / "rows.csv"))})
           for d in ("runs_probe2", "runs_probe", "runs_probe_trial", "runs_fix")]
SOURCES.append(("runs", {r["execution_id"]: r for r in csv.DictReader(open(R / "replay_rows.csv"))}))


def basic_fix_dir(eid):
    for d, rs in SOURCES:
        if eid in rs and all(rs[eid][c] == v3[eid][c] for c in NET_COLS):
            return R / d / eid
    raise SystemExit("no basic_fix run matches the v3 row of %s" % eid)


def run_stats(run):
    s = json.loads((run / "summary.json").read_text())
    sc = s["self_check"]
    w = list(csv.DictReader(open(run / "windows.csv")))[4:44]
    recs = [r for r in map(json.loads, open(run / "timing.jsonl")) if "window" in r and r.get("wall_ms") is not None]
    f = lambda r, k: int(float(r.get(k) or 0))
    return dict(pkts=sum(f(r, "net_pkts_total_delta") for r in w), sent=sc["sent_pkts_total"],
                overload=sum(f(r, "net_overload") for r in w), overrun=sum(f(r, "net_read_overrun") for r in w),
                wall_max=max(r["wall_ms"] for r in recs), checked=sc["windows_checked"],
                inside=sc["windows_inside_bounds"], run_exact=int(sc["switch_pkts_total"] == sc["sent_pkts_total"]
                                                                and sc["switch_bytes_total"] == sc["sent_bytes_total"]),
                cut_ms=(sc.get("totals_read_end_after_window_end_ms") or {}).get("median"))


def agreement(row, ref, cols):
    exact, errs = 0, []
    for c in cols:
        a, b = float(row[c]), float(ref[c])
        exact += abs(a - b) <= 1e-9 * max(1.0, abs(a), abs(b))
        errs.append(abs(a - b) / max(abs(b), 1e-9) if b else (0.0 if a == 0 else 1.0))
    return exact, st.median(errs)


out = []
for eid in [r["execution_id"] for r in v3_list]:
    dirs = {"bf": basic_fix_dir(eid), "snap": R / "runs_gtot_all" / eid, "bound": R / "runs_gtot_boundary" / eid}
    row = dict(execution_id=eid, basic_fix_run=dirs["bf"].parent.name)
    for b, _d in BUILDS:
        s = run_stats(dirs[b])
        row["sent"] = s["sent"]
        for k in ("pkts", "overload", "overrun", "wall_max", "checked", "inside", "run_exact", "cut_ms"):
            row["%s_%s" % (k, b)] = s[k]
        for name, cols in (("95", TOTAL_COLS), ("50", FLOW_COLS), ("145", NET_COLS)):
            e, m = agreement(rows[b][eid], published[eid], cols)
            row["exact%s_%s" % (name, b)], row["mrel%s_%s" % (name, b)] = e, round(m, 6)
    out.append(row)

with open(R / "gtot_all_compare.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(out[0]))
    wr.writeheader()
    wr.writerows(out)
with open(R / "replay_rows_gtot.csv", "w", newline="") as fh:
    wr = csv.DictWriter(fh, fieldnames=list(v3_list[0]))
    wr.writeheader()
    wr.writerows(rows["bound"][r["execution_id"]] for r in v3_list)
print("wrote gtot_all_compare.csv and replay_rows_gtot.csv (%d rows)" % len(out))

bulkup = [r for r in out if r["execution_id"].startswith("bulkup")]
ovl = [r for r in out if r["overload_bf"] > 0]
calm = [r for r in out if r not in bulkup and r not in ovl]
for name, grp in (("calm (no overloaded window on basic_fix)", calm), ("bulkup_200/400 (incomplete)", bulkup),
                  ("overloaded on basic_fix", ovl)):
    print("\n== %s: %d captures, %d packets sent" % (name, len(grp), sum(r["sent"] for r in grp)))
    print("%-34s %12s %12s %12s" % ("", "basic_fix", "gtot snap", "gtot bound"))
    line = lambda label, fn, fmt="%12s": print("%-34s" % label + "".join(fmt % fn(b) for b, _ in BUILDS))
    line("packets in the 40 windows", lambda b: sum(r["pkts_" + b] for r in grp))
    line("captures with all of them", lambda b: sum(r["pkts_" + b] == r["sent"] for r in grp))
    line("runs exact over 44 windows", lambda b: sum(r["run_exact_" + b] for r in grp))
    line("self-check windows inside/checked", lambda b: "%d/%d" % (sum(r["inside_" + b] for r in grp),
                                                                     sum(r["checked_" + b] for r in grp)))
    for n in ("95", "50", "145"):
        line("%s cols exact: median" % n, lambda b: st.median(r["exact%s_%s" % (n, b)] for r in grp))
        line("%s cols exact: mean" % n, lambda b: "%.1f" % st.mean(r["exact%s_%s" % (n, b)] for r in grp))
        line("%s cols: rows all equal" % n, lambda b: sum(r["exact%s_%s" % (n, b)] == int(n) for r in grp))
        line("%s cols median rel err: median" % n, lambda b: "%.4f" % st.median(r["mrel%s_%s" % (n, b)] for r in grp))
    line("overloaded windows", lambda b: sum(r["overload_" + b] for r in grp))
    line("overrun windows", lambda b: sum(r["overrun_" + b] for r in grp))
    line("longest read (ms)", lambda b: "%.0f" % max(r["wall_max_" + b] for r in grp))
    cuts = [r["cut_ms_bound"] for r in grp if r["cut_ms_bound"] is not None]
    if cuts:
        print("%-34s %38s" % ("totals' cut after boundary (bound)", "median of runs %.2f ms, max %.2f ms"
                              % (st.median(cuts), max(cuts))))

if "-v" in sys.argv:
    print()
    for r in ovl + bulkup:
        print("%-16s sent %7d | seen %6d %6d %6d | 95 exact %2d %2d %2d | mrel %.3f %.3f %.3f | 50 exact %2d %2d %2d"
              % (r["execution_id"][:16], r["sent"], r["pkts_bf"], r["pkts_snap"], r["pkts_bound"],
                 r["exact95_bf"], r["exact95_snap"], r["exact95_bound"], r["mrel95_bf"], r["mrel95_snap"],
                 r["mrel95_bound"], r["exact50_bf"], r["exact50_snap"], r["exact50_bound"]))
